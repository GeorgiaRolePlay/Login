-- phpMyAdmin SQL Dump
-- version 4.6.6deb4+deb9u2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 24, 2022 at 08:15 PM
-- Server version: 10.1.48-MariaDB-0+deb9u2
-- PHP Version: 7.0.33-0+deb9u12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gs7559`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `pID` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(32) COLLATE cp1251_bin NOT NULL,
  `pKey` varchar(32) COLLATE cp1251_bin NOT NULL,
  `pLevel` int(11) NOT NULL,
  `pForma` int(11) NOT NULL,
  `pAdmin` int(11) NOT NULL,
  `pTechSupport` int(11) NOT NULL,
  `pReporter` int(11) NOT NULL,
  `pPasport` int(11) NOT NULL,
  `pReptool` int(11) NOT NULL,
  `pIp` varchar(127) COLLATE cp1251_bin NOT NULL,
  `pvIp` varchar(128) COLLATE cp1251_bin NOT NULL,
  `pIpReg` varchar(128) COLLATE cp1251_bin NOT NULL,
  `pHousecash` int(11) NOT NULL,
  `pCheckip` int(11) NOT NULL,
  `pText` int(11) NOT NULL,
  `pKeyip` varchar(32) COLLATE cp1251_bin NOT NULL,
  `pProcents` int(11) NOT NULL,
  `pHP` int(11) NOT NULL,
  `pCar` int(11) NOT NULL,
  `pDonateRank` int(11) NOT NULL,
  `pMats` int(11) NOT NULL,
  `pSex` int(11) NOT NULL,
  `pMuted` int(11) NOT NULL,
  `pColor31` int(11) NOT NULL,
  `pColor32` int(11) NOT NULL,
  `pExp` int(11) NOT NULL,
  `pCash` int(11) NOT NULL,
  `pSilk` int(11) NOT NULL,
  `pPayCheck` int(11) NOT NULL,
  `pJailed` int(11) NOT NULL,
  `pJailTime` int(11) NOT NULL,
  `pProcents2` int(11) NOT NULL,
  `pDrugs` int(11) NOT NULL,
  `pLeader` int(11) NOT NULL,
  `pMember` int(11) NOT NULL,
  `pRank` int(11) NOT NULL,
  `pChar` int(11) NOT NULL,
  `pJob` int(11) NOT NULL,
  `pModel` int(11) NOT NULL,
  `pPnumber` int(11) NOT NULL,
  `pCarLic` int(11) NOT NULL,
  `pProcents1` int(11) NOT NULL,
  `pFlyLic` int(11) NOT NULL,
  `pBoatLic` int(11) NOT NULL,
  `pFishLic` int(11) NOT NULL,
  `pGunLic` int(11) NOT NULL,
  `pBizLic` int(11) NOT NULL,
  `pPhousekey` int(11) NOT NULL,
  `pPbiskey` int(11) NOT NULL,
  `pHotelKey` int(11) NOT NULL,
  `pZakonp` int(11) NOT NULL,
  `pAddiction` int(11) NOT NULL,
  `pVig` int(11) NOT NULL,
  `pMarried` int(11) NOT NULL,
  `pMarriedTo` varchar(128) COLLATE cp1251_bin NOT NULL,
  `pMuteTime` int(11) NOT NULL,
  `pBank` int(11) NOT NULL,
  `pBanMounth` int(11) NOT NULL,
  `pMobile` int(11) NOT NULL,
  `pDostup` varchar(32) COLLATE cp1251_bin NOT NULL,
  `pLocked` int(11) NOT NULL,
  `pWantedLevel` int(11) NOT NULL,
  `ptaxiexp` int(11) NOT NULL,
  `ptaxilvl` int(11) NOT NULL,
  `pBoxstyle` int(11) NOT NULL,
  `pKstyle` int(11) NOT NULL,
  `pKickstyle` int(11) NOT NULL,
  `pBoxSkill` int(11) NOT NULL,
  `pKongfuSkill` int(11) NOT NULL,
  `pKickboxSkill` int(11) NOT NULL,
  `pWheels` int(11) NOT NULL,
  `pPaintJob` int(11) NOT NULL,
  `pSpoiler` int(11) NOT NULL,
  `pBumper1` int(11) NOT NULL,
  `pBumper2` int(11) NOT NULL,
  `pColor1` int(11) NOT NULL,
  `pColor2` int(11) NOT NULL,
  `pColor21` int(11) NOT NULL,
  `pColor22` int(11) NOT NULL,
  `pNitro` int(11) NOT NULL,
  `pHydrawlic` int(11) NOT NULL,
  `pOnline` varchar(128) COLLATE cp1251_bin NOT NULL,
  `pChar1` int(11) NOT NULL,
  `pCigarettes` int(11) NOT NULL,
  `pChar2` int(11) NOT NULL,
  `pViborChar` int(11) NOT NULL,
  `pOnlineLid` varchar(32) COLLATE cp1251_bin NOT NULL,
  `pLogin` int(11) NOT NULL,
  `pQira` int(11) NOT NULL,
  `pNeon` int(11) NOT NULL,
  `pVipTime` int(11) NOT NULL,
  `pWheels1` int(11) NOT NULL,
  `pPaintJob1` int(11) NOT NULL,
  `pSpoiler1` int(11) NOT NULL,
  `pNeon1` int(11) NOT NULL,
  `pNitro1` int(11) NOT NULL,
  `pHydrawlic1` int(11) NOT NULL,
  `pCar1` int(11) NOT NULL,
  `pBonus` int(11) NOT NULL,
  `pCar2` int(11) NOT NULL,
  `pHealme` int(11) NOT NULL,
  `pQuest` int(11) NOT NULL,
  `pQuestis` int(11) NOT NULL,
  `pWheels2` int(11) NOT NULL,
  `pPaintJob2` int(11) NOT NULL,
  `pSpoiler2` int(11) NOT NULL,
  `pNitro2` int(11) NOT NULL,
  `pHydrawlic2` int(11) NOT NULL,
  `pNeon2` int(11) NOT NULL,
  `pPhonePlayer` int(11) NOT NULL,
  `pBoomBox` int(11) NOT NULL,
  `pBumper11` int(11) NOT NULL,
  `pBumper21` int(11) NOT NULL,
  `pBumper31` int(11) NOT NULL,
  `pBumper32` int(11) NOT NULL,
  `pArmyBilet` int(11) NOT NULL,
  `pArmyTime` int(11) NOT NULL,
  `pCar3` int(11) NOT NULL,
  `pWheels3` int(11) NOT NULL,
  `pSpoiler3` int(11) NOT NULL,
  `pNeon3` int(11) NOT NULL,
  `pNitro3` int(11) NOT NULL,
  `pHydrawlic3` int(11) NOT NULL,
  `pBumper41` int(11) NOT NULL,
  `pBumper42` int(11) NOT NULL,
  `pColor41` int(11) NOT NULL,
  `pColor42` int(11) NOT NULL,
  `pProcents3` int(11) NOT NULL,
  `pSlotItem1` int(11) NOT NULL,
  `pSlotItem2` int(11) NOT NULL,
  `pSlotItem3` int(11) NOT NULL,
  `pSlotItem4` int(11) NOT NULL,
  `pSlotItem5` int(11) NOT NULL,
  `pSlotItem6` int(11) NOT NULL,
  `pSlotItem7` int(11) NOT NULL,
  `pSlotItem8` int(11) NOT NULL,
  `pJackpot` int(11) NOT NULL,
  `pDonateman` int(11) NOT NULL,
  `pDjetx` int(11) NOT NULL,
  `pPromoUse` int(11) NOT NULL,
  `pRoofAir1` int(11) NOT NULL,
  `pRoofAir2` int(11) NOT NULL,
  `pRoofAir3` int(11) NOT NULL,
  `pRoofAir4` int(11) NOT NULL,
  `pGrushiteli1` int(11) NOT NULL,
  `pGrushiteli2` int(11) NOT NULL,
  `pGrushiteli3` int(11) NOT NULL,
  `pGrushiteli4` int(11) NOT NULL,
  `pLowerAir1` int(11) NOT NULL,
  `pLowerAir2` int(11) NOT NULL,
  `pLowerAir3` int(11) NOT NULL,
  `pLowerAir4` int(11) NOT NULL,
  `pFish` int(11) NOT NULL,
  `pQashayi` int(11) NOT NULL,
  `pOraguli` int(11) NOT NULL,
  `pKalmaxi` int(11) NOT NULL,
  `pTut` int(11) NOT NULL,
  `pDataReg` int(11) NOT NULL,
  `pDonatemoney` int(11) NOT NULL,
  `pDrug` int(11) NOT NULL,
  `pBanDay` int(11) NOT NULL,
  `Online_status` int(11) NOT NULL,
  `pTecAdmin` int(11) NOT NULL,
  `pInventory1` int(11) NOT NULL,
  `pInventory2` int(11) NOT NULL,
  `pInventory3` int(11) NOT NULL,
  `pInventory4` int(11) NOT NULL,
  `pInventory5` int(11) NOT NULL,
  `pInventory6` int(11) NOT NULL,
  `pBankomat` int(11) NOT NULL,
  `pKills` int(11) NOT NULL,
  `pDeaths` int(11) NOT NULL,
  `pAdminWarning` int(11) NOT NULL,
  `pElections` int(11) NOT NULL,
  `pCar4` int(11) NOT NULL,
  `pBumper51` int(11) NOT NULL,
  `pBumper52` int(11) NOT NULL,
  `pColor51` int(11) NOT NULL,
  `pColor52` int(11) NOT NULL,
  `pSpoiler4` int(11) NOT NULL,
  `pProcents4` int(11) NOT NULL,
  `pHydrawlic4` int(11) NOT NULL,
  `pPaintJob4` int(11) NOT NULL,
  `pWheels4` int(11) NOT NULL,
  `pNeon4` int(11) NOT NULL,
  `pRoofAir5` int(11) NOT NULL,
  `pGrushiteli5` int(11) NOT NULL,
  `pLowerAir5` int(11) NOT NULL,
  `pCarSlot` int(11) NOT NULL,
  `pBonuscar` int(11) NOT NULL,
  `pWarns` int(11) NOT NULL,
  `punWarns` int(11) NOT NULL,
  `punWarnstime` int(11) NOT NULL,
  `pMusiclic` int(11) NOT NULL,
  `pMagida` int(11) NOT NULL,
  `pAngel` int(11) NOT NULL,
  `pDeath` int(11) NOT NULL,
  `pPubgSkin` int(11) NOT NULL,
  `pSparta` int(11) NOT NULL,
  `pGhostRider` int(11) NOT NULL,
  `pDemon` int(11) NOT NULL,
  `pAxaliskini` int(11) NOT NULL,
  `pPirbade` int(11) NOT NULL,
  `pDancec` int(11) NOT NULL,
  `pDaeswroPaydays` int(11) NOT NULL,
  `pGangKills` int(11) NOT NULL,
  `pPaintJob3` int(11) NOT NULL,
  `pLocal` int(11) NOT NULL,
  `pInt` int(11) NOT NULL,
  `pSpawnloc` int(11) NOT NULL,
  `pNitro4` int(11) NOT NULL,
  `pDartWaider` int(11) NOT NULL,
  `pSpawnChange` int(11) NOT NULL DEFAULT '0',
  `pFamilyMember` int(11) NOT NULL,
  `pFamilyRank` int(11) NOT NULL,
  `pCarPos` int(11) NOT NULL,
  `pCarPos1` int(11) NOT NULL,
  `pCarPos2` int(11) NOT NULL,
  `pCarPos3` int(11) NOT NULL,
  `pSatiety` int(11) NOT NULL,
  `pHtune` int(11) NOT NULL,
  `pKiborg` int(11) NOT NULL,
  `pObjikt` int(11) NOT NULL,
  `pTrunckStatus` int(11) NOT NULL,
  `pBoat` int(11) NOT NULL,
  `pBoatPos1` int(11) NOT NULL,
  `pBoatPos2` int(11) NOT NULL,
  `pBoatPos3` int(11) NOT NULL,
  `pBoatPos4` int(11) NOT NULL,
  `pCarStatus` int(11) NOT NULL,
  `pCarPenalty1` int(11) NOT NULL,
  `pCarPenalty2` int(11) NOT NULL,
  `pCarPenalty3` int(11) NOT NULL,
  `pCarPenalty4` int(11) NOT NULL,
  `pCarPenalty5` int(11) NOT NULL,
  `pSpawnType` int(11) NOT NULL,
  `pBronzeRoulette` int(11) NOT NULL,
  `pSilverRoulette` int(11) NOT NULL,
  `pGoldRoulette` int(11) NOT NULL,
  `pRouletteMoney` int(11) NOT NULL,
  `pAnswerYes` int(11) NOT NULL,
  `pAnswerNo` int(11) NOT NULL,
  `pVehicleNumberOne` varchar(30) CHARACTER SET utf8 NOT NULL,
  `pVehicleNumberTwo` varchar(30) CHARACTER SET utf8 NOT NULL,
  `pVehicleNumberThree` varchar(30) CHARACTER SET utf8 NOT NULL,
  `pVehicleNumberFour` varchar(30) CHARACTER SET utf8 NOT NULL,
  `pVehicleNumberFive` varchar(30) CHARACTER SET utf8 NOT NULL,
  `pPlayerPos1` float NOT NULL,
  `pPlayerPos2` float NOT NULL,
  `pPlayerPos3` float NOT NULL,
  `pPlayerPos4` float NOT NULL,
  `pPlayerPoss1` int(11) NOT NULL,
  `pPlayerPoss2` int(11) NOT NULL,
  `pAccessories1` int(11) NOT NULL,
  `pAccessories2` int(11) NOT NULL,
  `pAccessories3` int(11) NOT NULL,
  `pAccessories4` int(11) NOT NULL,
  `pAccessories5` int(11) NOT NULL,
  `pAccessories6` int(11) NOT NULL,
  `pAccessories7` int(11) NOT NULL,
  `pAccessories8` int(11) NOT NULL,
  `pAccessories9` int(11) NOT NULL,
  `pAccessories10` int(11) NOT NULL,
  `pAccessories11` int(11) NOT NULL,
  `pAccessories12` int(11) NOT NULL,
  `pAccessories13` int(11) NOT NULL,
  `pAccessories14` int(11) NOT NULL,
  `pAccessories15` int(11) NOT NULL,
  `pAccessories16` int(11) NOT NULL,
  `pAccessories17` int(11) NOT NULL,
  `pAccessories18` int(11) NOT NULL,
  `pAccessories19` int(11) NOT NULL,
  `pAccessories20` int(11) NOT NULL,
  `pGEL` int(11) NOT NULL,
  `LastPosX` float NOT NULL,
  `LastPosY` float NOT NULL,
  `LastPosZ` float NOT NULL,
  `LastPosA` float NOT NULL,
  `LastVirtual` int(11) NOT NULL,
  `LastInterior` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 COLLATE=cp1251_bin;


--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`pID`, `Name`, `pKey`, `pLevel`, `pForma`, `pAdmin`, `pTechSupport`, `pReporter`, `pPasport`, `pReptool`, `pIp`, `pvIp`, `pIpReg`, `pHousecash`, `pCheckip`, `pText`, `pKeyip`, `pProcents`, `pHP`, `pCar`, `pDonateRank`, `pMats`, `pSex`, `pMuted`, `pColor31`, `pColor32`, `pExp`, `pCash`, `pSilk`, `pPayCheck`, `pJailed`, `pJailTime`, `pProcents2`, `pDrugs`, `pLeader`, `pMember`, `pRank`, `pChar`, `pJob`, `pModel`, `pPnumber`, `pCarLic`, `pProcents1`, `pFlyLic`, `pBoatLic`, `pFishLic`, `pGunLic`, `pBizLic`, `pPhousekey`, `pPbiskey`, `pHotelKey`, `pZakonp`, `pAddiction`, `pVig`, `pMarried`, `pMarriedTo`, `pMuteTime`, `pBank`, `pBanMounth`, `pMobile`, `pDostup`, `pLocked`, `pWantedLevel`, `ptaxiexp`, `ptaxilvl`, `pBoxstyle`, `pKstyle`, `pKickstyle`, `pBoxSkill`, `pKongfuSkill`, `pKickboxSkill`, `pWheels`, `pPaintJob`, `pSpoiler`, `pBumper1`, `pBumper2`, `pColor1`, `pColor2`, `pColor21`, `pColor22`, `pNitro`, `pHydrawlic`, `pOnline`, `pChar1`, `pCigarettes`, `pChar2`, `pViborChar`, `pOnlineLid`, `pLogin`, `pQira`, `pNeon`, `pVipTime`, `pWheels1`, `pPaintJob1`, `pSpoiler1`, `pNeon1`, `pNitro1`, `pHydrawlic1`, `pCar1`, `pBonus`, `pCar2`, `pHealme`, `pQuest`, `pQuestis`, `pWheels2`, `pPaintJob2`, `pSpoiler2`, `pNitro2`, `pHydrawlic2`, `pNeon2`, `pPhonePlayer`, `pBoomBox`, `pBumper11`, `pBumper21`, `pBumper31`, `pBumper32`, `pArmyBilet`, `pArmyTime`, `pCar3`, `pWheels3`, `pSpoiler3`, `pNeon3`, `pNitro3`, `pHydrawlic3`, `pBumper41`, `pBumper42`, `pColor41`, `pColor42`, `pProcents3`, `pSlotItem1`, `pSlotItem2`, `pSlotItem3`, `pSlotItem4`, `pSlotItem5`, `pSlotItem6`, `pSlotItem7`, `pSlotItem8`, `pJackpot`, `pDonateman`, `pDjetx`, `pPromoUse`, `pRoofAir1`, `pRoofAir2`, `pRoofAir3`, `pRoofAir4`, `pGrushiteli1`, `pGrushiteli2`, `pGrushiteli3`, `pGrushiteli4`, `pLowerAir1`, `pLowerAir2`, `pLowerAir3`, `pLowerAir4`, `pFish`, `pQashayi`, `pOraguli`, `pKalmaxi`, `pTut`, `pDataReg`, `pDonatemoney`, `pDrug`, `pBanDay`, `Online_status`, `pTecAdmin`, `pInventory1`, `pInventory2`, `pInventory3`, `pInventory4`, `pInventory5`, `pInventory6`, `pBankomat`, `pKills`, `pDeaths`, `pAdminWarning`, `pElections`, `pCar4`, `pBumper51`, `pBumper52`, `pColor51`, `pColor52`, `pSpoiler4`, `pProcents4`, `pHydrawlic4`, `pPaintJob4`, `pWheels4`, `pNeon4`, `pRoofAir5`, `pGrushiteli5`, `pLowerAir5`, `pCarSlot`, `pBonuscar`, `pWarns`, `punWarns`, `punWarnstime`, `pMusiclic`, `pMagida`, `pAngel`, `pDeath`, `pPubgSkin`, `pSparta`, `pGhostRider`, `pDemon`, `pAxaliskini`, `pPirbade`, `pDancec`, `pDaeswroPaydays`, `pGangKills`, `pPaintJob3`, `pLocal`, `pInt`, `pSpawnloc`, `pNitro4`, `pDartWaider`, `pSpawnChange`, `pFamilyMember`, `pFamilyRank`, `pCarPos`, `pCarPos1`, `pCarPos2`, `pCarPos3`, `pSatiety`, `pHtune`, `pKiborg`, `pObjikt`, `pTrunckStatus`, `pBoat`, `pBoatPos1`, `pBoatPos2`, `pBoatPos3`, `pBoatPos4`, `pCarStatus`, `pCarPenalty1`, `pCarPenalty2`, `pCarPenalty3`, `pCarPenalty4`, `pCarPenalty5`, `pSpawnType`, `pBronzeRoulette`, `pSilverRoulette`, `pGoldRoulette`, `pRouletteMoney`, `pAnswerYes`, `pAnswerNo`, `pVehicleNumberOne`, `pVehicleNumberTwo`, `pVehicleNumberThree`, `pVehicleNumberFour`, `pVehicleNumberFive`, `pAccessories1`, `pAccessories2`, `pAccessories3`, `pAccessories4`, `pAccessories5`, `pAccessories6`, `pAccessories7`, `pAccessories8`, `pAccessories9`, `pAccessories10`, `pAccessories11`, `pAccessories12`, `pAccessories13`, `pAccessories14`, `pAccessories15`, `pAccessories16`, `pAccessories17`, `pAccessories18`, `pAccessories19`, `pAccessories20`, `pGEL`) VALUES
(1, 'Xuco_Kalashnikovi', 'xucomoxuco30', 13, 27, 0, 1, 0, 1, 0, '85.238.42.99', '85.238.42.99', '85.238.42.99', 2000000, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 3, 13747707, 9, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 165, 595181, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 6856660, 0, 700, '!ucomoxuco30', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 16:1', 165, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 7, 0, 0, 0, 0, 0, 2, 6, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(3, 'Giorgi_Kings', 'giorgi', 27, 37, 6, 0, 0, 1, 0, '95.137.130.246', '95.137.130.246', '92.54.237.157', 2000000, 0, 1, '', 300, 0, 542, 2, 300, 1, 0, 0, 0, 4, 37054678, 6, 0, 0, 0, 300, 0, 37, 37, 10, 230, 0, 295, 713148, 1, 150, 1, 1, 0, 1, 1, 30, 255, 0, 0, 0, 0, 0, '-', 0, 21343001, 0, 0, 'giorgi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1083, 255, 0, 0, 0, 27, 27, 26, 26, 1010, 1087, '9/3/2022, 19:29', 25, 0, 230, 1, '', 1, 999, 18649, 80, 1083, 255, 0, 18651, 1010, 1087, 451, 0, 494, 0, 0, 0, 1083, 255, 0, 1010, 0, 18648, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 255, 30, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 2, 'XX-XXX-XXX', 'XX-XXX-XX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(4, 'Luka_Paul', 'lukakuka', 15, 12, 0, 0, 0, 1, 0, '85.117.63.100', '85.117.63.100', '91.184.107.202', 0, 0, 0, '', 100, 0, 462, 0, 140, 1, 0, 0, 0, 1, 298500, 0, 0, 0, 0, 100, 0, 12, 12, 10, 230, 0, 104, 857349, 1, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!uka...', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 17:55', 103, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(5, 'Kaxa_Leshka', 'winewood', 1, 0, 0, 0, 0, 0, 0, '31.146.222.236', '31.146.222.236', '31.146.222.236', 0, 0, 0, '', 100, 0, 462, 0, 0, 2, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 157, 0, 0, 550827, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2/3/2022, 14:24', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(6, 'Anibal_Cortes', 'brobrfo', 1, 0, 0, 0, 0, 0, 0, '95.137.170.25', '95.137.170.25', '95.137.170.25', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 165112, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2/3/2022, 15:44', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(7, 'Frank_Jufren', 'ferokiller', 1, 0, 0, 0, 0, 0, 0, '91.151.136.122', '91.151.136.122', '91.151.136.122', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 568143, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2/3/2022, 16:26', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(9, 'Luka_Sinaurize', 'lukaluka', 1, 0, 0, 0, 0, 0, 0, '185.115.5.38', '185.115.5.38', '185.115.5.38', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 179397, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2/3/2022, 18:36', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(10, 'Ace_Drifer', 'goga13', 1, 0, 0, 0, 0, 0, 0, '188.227.193.50', '188.227.193.50', '188.227.193.50', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 772677, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 17:51', 104, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(22, 'Young_Todu', 'RICHNIGGA', 73, 17, 0, 0, 0, 1, 0, '212.58.103.216', '212.58.103.216', '212.58.103.216', 0, 0, 0, '', 300, 0, 411, 3, 300, 1, 0, 0, 0, 24, 95558599, 28, 0, 0, 0, 300, 0, 0, 27, 5, 230, 0, 19, 221595, 1, 300, 1, 1, 0, 1, 1, 495, 19, 0, 0, 0, 0, 0, '-', 0, 208838, 0, 0, '12345', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1079, 255, 0, 0, 0, 0, 0, 0, 0, 1010, 0, '7/3/2022, 22:53', 294, 0, 230, 1, '', 0, 999, 18647, 97, 1080, 255, 0, 18647, 1010, 0, 494, 0, 495, 1, 9, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 1, 1, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 255, 495, 0, 0, 0, 0, 0, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(11, 'Lixx_Shelby', 'Lixxlixx', 16, 12, 0, 0, 0, 1, 0, '82.211.180.136', '82.211.180.136', '82.211.180.136', 2000000, 0, 1, '', 100, 0, 506, 3, 0, 1, 0, 0, 0, 1, 400107594, 0, 0, 0, 0, 300, 0, 12, 12, 10, 230, 0, 104, 409015, 1, 300, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!ikanika', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 1, 1, 0, 0, 0, 0, '6/3/2022, 21:43', 102, 0, 230, 1, '', 0, 999, 0, 80, 0, 255, 0, 0, 0, 0, 411, 0, 477, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(12, 'Test_Ge', 'test123', 1, 0, 0, 0, 0, 0, 0, '213.200.15.37', '213.200.15.37', '213.200.15.37', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 452446, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2/3/2022, 23:56', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(13, 'JaCk_MiLLeR', 'aleksan1', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 760523, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 12:27', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(15, 'Stive_Oldschool', 'stive123', 23, 15, 0, 0, 0, 0, 0, '185.70.52.15', '185.70.52.15', '185.115.5.79', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 5, 3000400, 23, 0, 0, 0, 100, 0, 15, 15, 10, 230, 0, 270, 980554, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 18000, 0, 0, 'stive123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:14', 116, 0, 116, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(16, 'Akush_Bagrationi', 'gucchitechi', 119, 37, 0, 0, 0, 0, 0, '5.152.110.75', '5.152.110.75', '5.152.110.75', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 3, 500500, 4, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 295, 706355, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 160000, 0, 0, 'tyvnaizera13', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 19:4', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(38, 'ToMmy_Miller', 'Dip123321', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '212.58.102.115', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 590375, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 13:1', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(18, 'Manasa_Oldschool', 'etametam1', 1, 0, 0, 0, 0, 0, 0, '37.232.0.121', '37.232.0.121', '37.232.0.121', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 908508, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 13:10', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(19, 'Petter_Fischer', 'andria123', 1, 0, 0, 0, 0, 0, 0, '37.232.39.102', '37.232.39.102', '37.232.39.102', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 306277, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 13:26', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(24, 'Andria_Tabatadze', 'dagasxigela12', 13, 0, 0, 0, 0, 1, 0, '78.40.106.96', '78.40.106.96', '78.40.106.61', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 999500, 0, 0, 0, 0, 100, 0, 0, 18, 9, 230, 0, 175, 825826, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!abata12', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 18:49', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(20, 'Bidzina_Hardy', 'bidzina', 6, 0, 0, 0, 0, 1, 0, '213.200.31.244', '213.200.31.244', '91.184.106.243', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 946000, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 846057, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 960, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:14', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(21, 'Tommy_Millerii', 'Dip123321', 1, 0, 0, 0, 0, 0, 0, '212.58.102.115', '212.58.102.115', '212.58.102.115', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 298506, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 14:2', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(26, 'Gilberto_Smith', 'dzmebi1012', 6, 12, 0, 0, 0, 0, 0, '78.40.106.75', '78.40.106.75', '78.40.106.36', 0, 0, 0, '', 100, 0, 462, 0, 480, 1, 0, 0, 0, 1, 934300, 0, 0, 0, 0, 100, 0, 12, 12, 10, 230, 0, 104, 567322, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 13:8', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(25, 'Brian_Grate', 'nodeksa', 1, 0, 0, 0, 0, 0, 0, '37.232.78.152', '37.232.78.152', '37.232.78.152', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 386500, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 13:48', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(33, 'Kavala_Nightrideri', 'Giorgi2007', 21, 2, 0, 0, 0, 1, 0, '109.172.209.50', '109.172.209.50', '109.172.209.50', 0, 0, 0, '', 298, 0, 562, 1, 0, 1, 0, 0, 0, 1, 2187597, 0, 0, 0, 0, 300, 0, 0, 0, 0, 230, 0, 166, 370436, 1, 300, 1, 1, 0, 1, 1, 476, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 2960, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1079, 2, 0, 1172, 1149, 0, 0, 26, 26, 1010, 0, '9/3/2022, 17:37', 102, 0, 230, 1, '', 0, 999, 0, 75, 0, 255, 0, 0, 1010, 0, 402, 0, 495, 5, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 494, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 542, 0, 0, 0, 0, 0, 300, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 476, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(28, 'Guga_Gruzinski', 'guga123', 31, 37, 0, 0, 0, 1, 0, '62.212.55.185', '62.212.55.185', '95.137.159.140', 0, 0, 0, '', 300, 0, 495, 1, 0, 1, 0, 0, 0, 10, 1763978, 38, 0, 0, 0, 100, 0, 37, 37, 10, 19, 0, 294, 625745, 1, 300, 1, 1, 0, 1, 1, 201, 255, 0, 0, 0, 0, 0, '-', 0, 92001, 0, 1600, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 1, 1, 1010, 0, '9/3/2022, 18:8', 230, 0, 230, 0, '', 0, 999, 0, 80, 0, 255, 0, 0, 0, 0, 402, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 429, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 201, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'WW-794-VV', 'WV-448-VW', 'XX-XXX-XX', 'XX-XXX-XX', 'KN-190-NK', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(27, 'Bob_Anderson', 'admin123', 1, 17, 0, 0, 0, 0, 0, '31.192.37.229', '31.192.37.229', '31.192.37.229', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 292, 876044, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'admin123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '5/3/2022, 16:56', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(29, 'Luis_Olmo', 'semi123', 1, 0, 0, 0, 0, 0, 0, '185.115.7.84', '185.115.7.84', '185.115.5.99', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 710490, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'semi123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 11:35', 102, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(30, 'Jimsher_Ryvera', 'LukaLuka', 15, 14, 0, 0, 0, 1, 0, '212.58.102.115', '212.58.102.115', '212.58.103.4', 2000000, 0, 1, '', 261, 0, 411, 3, 0, 1, 0, 0, 0, 3, 1929820964, 4, 0, 0, 0, 100, 0, 0, 0, 10, 230, 0, 126, 947013, 1, 100, 1, 1, 0, 1, 1, 91, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1080, 255, 0, 0, 0, 3, 3, 0, 0, 1010, 1087, '5/3/2022, 15:29', 242, 0, 230, 1, '', 0, 999, 18647, 93, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 91, 7, 0, 0, 1, 0, 1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '12-TRAKI-21', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(31, 'Jax_Miller', 'anonymous', 1, 0, 0, 0, 0, 0, 0, '91.239.206.184', '91.239.206.184', '91.239.206.184', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 269265, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 22:56', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(32, 'Anonimali_Oky', 'paroli', 1, 0, 0, 0, 0, 0, 0, '91.239.206.184', '91.239.206.184', '91.239.206.184', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 950246, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 23:3', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(35, 'Legion_Time', 'paroli', 1, 0, 0, 0, 0, 0, 0, '91.239.206.139', '91.239.206.139', '91.239.206.139', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 372578, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 23:32', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(39, 'Anonymous_3Legion', 'hacked', 1, 0, 0, 0, 0, 0, 0, '92.54.237.157', '92.54.237.157', '92.54.237.157', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 783900, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3/3/2022, 23:49', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(36, 'Young_Nikka', 'nika1234', 23, 1, 0, 0, 0, 1, 0, '212.58.103.216', '212.58.103.216', '212.58.103.216', 0, 0, 0, '', 300, 0, 400, 1, 302, 1, 0, 1, 1, 12, 2103263, 32, 0, 0, 0, 300, 0, 0, 0, 15, 230, 0, 283, 482633, 1, 300, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 1021, 1167072, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 1, 1, 0, 0, '7/3/2022, 19:56', 115, 0, 230, 1, '', 0, 495, 0, 77, 0, 255, 0, 0, 1010, 0, 587, 0, 551, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 507, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 495, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XX', 'XX-XXX-XX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(40, 'Jack_Miller', 'aleksan1', 777, 1, 10, 0, 0, 1, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 1, 0, 'karenaylea', 300, 0, 522, 0, 0, 1, 0, 0, 0, 8, 788945, 44, 0, 0, 0, 300, 0, 0, 0, 15, 230, 0, 283, 185544, 1, 300, 1, 1, 0, 1, 1, 371, 22, 0, 0, 0, 0, 0, '-', 0, 751110, 0, 1000, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 19:44', 74, 0, 230, 1, '', 1, 999, 0, 0, 0, 255, 0, 0, 0, 0, 579, 0, 411, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 562, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 571, 0, 0, 0, 0, 0, 300, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 255, 371, 7, 0, 0, 1, 0, 1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 34, 3, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(41, 'Andrew_Henderson', 'ukanweria', 1, 12, 0, 0, 0, 0, 0, '37.232.7.89', '37.232.7.89', '37.232.7.89', 0, 0, 0, '', 300, 0, 522, 0, 0, 1, 0, 0, 0, 1, 1500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 104, 797296, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'ako2008', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 12:6', 230, 0, 102, 2, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 562, 0, 0, 0, 0, 0, 0, 0, 0, 0, 300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(42, 'Old_Mekkube', 'mekkube', 1, 0, 0, 0, 0, 0, 0, '178.134.98.99', '178.134.98.99', '178.134.98.99', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 332245, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 13:33', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(43, 'Zuriko_Giorgadze', 'zuriko123', 6, 0, 0, 0, 0, 1, 0, '185.115.6.118', '185.115.6.118', '185.115.5.57', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 8500, 0, 0, 0, 0, 100, 0, 0, 15, 9, 230, 0, 107, 685246, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 15:49', 115, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(44, 'Jack_MillerN1', 'banmedeba', 1, 0, 0, 0, 0, 0, 0, '178.134.72.181', '178.134.72.181', '178.134.72.181', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 323954, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 11:52', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(45, 'Nikusha_Miller', 'nikusha', 14, 2, 0, 0, 0, 1, 0, '178.134.72.181', '178.134.72.181', '178.134.72.181', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 6500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 166, 433773, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 980, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '5/3/2022, 17:32', 102, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(47, 'Soso_Somana', 'GioGio25', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 808051, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '205511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 12:15', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(46, 'Lukee_Giorgadze', 'Lukke123', 15, 12, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 104, 633397, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '205511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 12:13', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(63, 'Levan_Shelby', 'g1g2g3g4g5g6', 6, 13, 0, 0, 0, 0, 0, '212.58.103.209', '212.58.103.209', '212.58.103.183', 0, 0, 0, '', 100, 0, 462, 0, 300, 1, 0, 0, 0, 1, 997500, 0, 0, 0, 0, 100, 0, 13, 13, 10, 257, 0, 110, 164958, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 960, '!1g2g3g4g5g6', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:5', 253, 0, 154, 2, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(48, 'Lazer_Masson', 'agetpass', 1, 0, 0, 0, 0, 1, 0, '213.200.15.37', '213.200.15.37', '213.200.15.37', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 997889649, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 742041, 0, 100, 0, 0, 0, 0, 0, 225, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '205511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 12:27', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0);
INSERT INTO `accounts` (`pID`, `Name`, `pKey`, `pLevel`, `pForma`, `pAdmin`, `pTechSupport`, `pReporter`, `pPasport`, `pReptool`, `pIp`, `pvIp`, `pIpReg`, `pHousecash`, `pCheckip`, `pText`, `pKeyip`, `pProcents`, `pHP`, `pCar`, `pDonateRank`, `pMats`, `pSex`, `pMuted`, `pColor31`, `pColor32`, `pExp`, `pCash`, `pSilk`, `pPayCheck`, `pJailed`, `pJailTime`, `pProcents2`, `pDrugs`, `pLeader`, `pMember`, `pRank`, `pChar`, `pJob`, `pModel`, `pPnumber`, `pCarLic`, `pProcents1`, `pFlyLic`, `pBoatLic`, `pFishLic`, `pGunLic`, `pBizLic`, `pPhousekey`, `pPbiskey`, `pHotelKey`, `pZakonp`, `pAddiction`, `pVig`, `pMarried`, `pMarriedTo`, `pMuteTime`, `pBank`, `pBanMounth`, `pMobile`, `pDostup`, `pLocked`, `pWantedLevel`, `ptaxiexp`, `ptaxilvl`, `pBoxstyle`, `pKstyle`, `pKickstyle`, `pBoxSkill`, `pKongfuSkill`, `pKickboxSkill`, `pWheels`, `pPaintJob`, `pSpoiler`, `pBumper1`, `pBumper2`, `pColor1`, `pColor2`, `pColor21`, `pColor22`, `pNitro`, `pHydrawlic`, `pOnline`, `pChar1`, `pCigarettes`, `pChar2`, `pViborChar`, `pOnlineLid`, `pLogin`, `pQira`, `pNeon`, `pVipTime`, `pWheels1`, `pPaintJob1`, `pSpoiler1`, `pNeon1`, `pNitro1`, `pHydrawlic1`, `pCar1`, `pBonus`, `pCar2`, `pHealme`, `pQuest`, `pQuestis`, `pWheels2`, `pPaintJob2`, `pSpoiler2`, `pNitro2`, `pHydrawlic2`, `pNeon2`, `pPhonePlayer`, `pBoomBox`, `pBumper11`, `pBumper21`, `pBumper31`, `pBumper32`, `pArmyBilet`, `pArmyTime`, `pCar3`, `pWheels3`, `pSpoiler3`, `pNeon3`, `pNitro3`, `pHydrawlic3`, `pBumper41`, `pBumper42`, `pColor41`, `pColor42`, `pProcents3`, `pSlotItem1`, `pSlotItem2`, `pSlotItem3`, `pSlotItem4`, `pSlotItem5`, `pSlotItem6`, `pSlotItem7`, `pSlotItem8`, `pJackpot`, `pDonateman`, `pDjetx`, `pPromoUse`, `pRoofAir1`, `pRoofAir2`, `pRoofAir3`, `pRoofAir4`, `pGrushiteli1`, `pGrushiteli2`, `pGrushiteli3`, `pGrushiteli4`, `pLowerAir1`, `pLowerAir2`, `pLowerAir3`, `pLowerAir4`, `pFish`, `pQashayi`, `pOraguli`, `pKalmaxi`, `pTut`, `pDataReg`, `pDonatemoney`, `pDrug`, `pBanDay`, `Online_status`, `pTecAdmin`, `pInventory1`, `pInventory2`, `pInventory3`, `pInventory4`, `pInventory5`, `pInventory6`, `pBankomat`, `pKills`, `pDeaths`, `pAdminWarning`, `pElections`, `pCar4`, `pBumper51`, `pBumper52`, `pColor51`, `pColor52`, `pSpoiler4`, `pProcents4`, `pHydrawlic4`, `pPaintJob4`, `pWheels4`, `pNeon4`, `pRoofAir5`, `pGrushiteli5`, `pLowerAir5`, `pCarSlot`, `pBonuscar`, `pWarns`, `punWarns`, `punWarnstime`, `pMusiclic`, `pMagida`, `pAngel`, `pDeath`, `pPubgSkin`, `pSparta`, `pGhostRider`, `pDemon`, `pAxaliskini`, `pPirbade`, `pDancec`, `pDaeswroPaydays`, `pGangKills`, `pPaintJob3`, `pLocal`, `pInt`, `pSpawnloc`, `pNitro4`, `pDartWaider`, `pSpawnChange`, `pFamilyMember`, `pFamilyRank`, `pCarPos`, `pCarPos1`, `pCarPos2`, `pCarPos3`, `pSatiety`, `pHtune`, `pKiborg`, `pObjikt`, `pTrunckStatus`, `pBoat`, `pBoatPos1`, `pBoatPos2`, `pBoatPos3`, `pBoatPos4`, `pCarStatus`, `pCarPenalty1`, `pCarPenalty2`, `pCarPenalty3`, `pCarPenalty4`, `pCarPenalty5`, `pSpawnType`, `pBronzeRoulette`, `pSilverRoulette`, `pGoldRoulette`, `pRouletteMoney`, `pAnswerYes`, `pAnswerNo`, `pVehicleNumberOne`, `pVehicleNumberTwo`, `pVehicleNumberThree`, `pVehicleNumberFour`, `pVehicleNumberFive`, `pAccessories1`, `pAccessories2`, `pAccessories3`, `pAccessories4`, `pAccessories5`, `pAccessories6`, `pAccessories7`, `pAccessories8`, `pAccessories9`, `pAccessories10`, `pAccessories11`, `pAccessories12`, `pAccessories13`, `pAccessories14`, `pAccessories15`, `pAccessories16`, `pAccessories17`, `pAccessories18`, `pAccessories19`, `pAccessories20`, `pGEL`) VALUES
(49, 'Nika_Afci', 'nika123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 274909, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 12:47', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(51, 'Tommy_Miller', 'Dip123321', 5, 14, 10, 0, 0, 1, 0, '212.58.120.157', '212.58.120.157', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 3, 0, 1, 0, 0, 0, 2, 516014318, 2, 0, 0, 0, 100, 0, 0, 0, 10, 230, 0, 126, 657146, 1, 100, 1, 1, 0, 1, 1, 999, 4, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '5/3/2022, 22:50', 243, 0, 230, 1, '', 0, 999, 0, 93, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 255, 255, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 1345304316),
(50, 'Tommy_MilIer', 'Sabayle', 1, 0, 0, 0, 0, 0, 0, '82.211.180.136', '82.211.180.136', '82.211.180.136', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 970516, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 12:58', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(52, 'Leona_Shelby', 'jaja123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 726113, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 13:0', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(73, 'Wiliam_Masson', 'giusah12', 1, 37, 0, 0, 0, 0, 0, '188.169.221.180', '188.169.221.180', '188.169.221.180', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 2, 100500, 2, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 295, 295511, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'giusha12', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 19:40', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(53, 'Young_Nigga', 'saba1234', 6, 37, 0, 0, 0, 1, 0, '212.58.103.216', '212.58.103.216', '212.58.103.216', 0, 0, 0, '', 76, 0, 506, 0, 100, 1, 0, 0, 0, 9, 3325834, 21, 0, 0, 0, 100, 0, 0, 0, 10, 230, 0, 295, 389866, 1, 100, 1, 1, 0, 0, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 231047, 0, 860, '!2345', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 1, 1, 0, 0, 1010, 1087, '7/3/2022, 15:9', 115, 20, 230, 1, '', 0, 495, 18652, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 495, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(54, 'Luka_Lixx', 'lukaxuco', 1, 0, 0, 0, 0, 0, 0, '93.177.161.225', '93.177.161.225', '93.177.161.225', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 699709, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 15:27', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(55, 'young_Nikka', 'nika1234', 1, 0, 0, 0, 0, 0, 0, '212.58.103.216', '212.58.103.216', '212.58.103.216', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 368042, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 16:9', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(56, 'Giorgi_Naciradze', 'giorgi123', 1, 0, 0, 0, 0, 0, 0, '213.200.31.244', '213.200.31.244', '213.200.31.244', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 369688, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 16:12', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(57, 'Zura_Sinauridze', 'zuka1234', 1, 0, 0, 0, 0, 0, 0, '185.115.4.38', '185.115.4.38', '185.115.4.38', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 610963, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 17:20', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(58, 'Luka_Tsarielashvili', 'paroliarvici', 10, 0, 0, 0, 0, 1, 0, '85.114.238.3', '85.114.238.3', '85.114.238.3', 2000000, 0, 0, '', 300, 0, 563, 3, 0, 1, 0, 0, 0, 2, 302982000, 2, 0, 0, 0, 100, 0, 0, 0, 1, 230, 0, 125, 877416, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4/3/2022, 19:15', 230, 0, 230, 0, '', 0, 999, 0, 93, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 71, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(59, 'Sandro_Sichinava', 'ylexar', 5, 0, 0, 0, 0, 0, 0, '91.151.136.222', '91.151.136.222', '91.151.136.222', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 399515, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 171582, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 68, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '5/3/2022, 15:30', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 64, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(74, 'Ray_Hopper', 'Gio123', 6, 0, 0, 0, 0, 0, 0, '94.43.237.97', '94.43.237.97', '94.43.237.97', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 899500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 862940, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 15:43', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(60, 'Goga_Masson', 'goga13', 1, 0, 0, 0, 0, 0, 0, '188.227.193.50', '188.227.193.50', '188.227.193.50', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 417397, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '5/3/2022, 16:58', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(100, 'Luffy_Zoroshvili', 'luffyking', 9, 18, 0, 0, 0, 1, 0, '185.115.4.204', '185.115.4.204', '185.115.4.204', 0, 0, 0, '', 300, 0, 587, 2, 543, 1, 0, 0, 0, 5, 7452609, 8, 0, 0, 0, 100, 0, 18, 18, 10, 230, 0, 174, 579919, 1, 100, 1, 1, 0, 1, 1, 249, 255, 0, 0, 0, 0, 0, '-', 0, 40000, 0, 1000, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1080, 255, 0, 0, 0, 1, 1, 0, 0, 1010, 1087, '9/3/2022, 19:44', 102, 20, 230, 1, '', 1, 999, 18651, 77, 0, 255, 0, 0, 0, 0, 462, 0, 462, 4, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(62, 'Luk_Miller', 'sabagiorgi', 6, 15, 0, 0, 0, 1, 0, '31.146.73.141', '31.146.73.141', '31.146.73.141', 0, 0, 0, '', 100, 0, 462, 0, 200, 1, 0, 0, 0, 3, 857500, 4, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 271, 356650, 1, 100, 1, 1, 0, 0, 1, 20, 255, 0, 0, 0, 0, 0, '-', 0, 20000, 0, 940, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 12:47', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 3, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 20, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(64, 'Slayes_Revaza', 'revaza', 9, 4, 0, 0, 0, 1, 0, '212.58.120.77', '212.58.120.77', '91.184.107.154', 0, 0, 0, '', 300, 0, 402, 1, 600, 1, 0, 0, 0, 6, 4244713, 15, 0, 0, 0, 100, 0, 0, 27, 8, 230, 0, 46, 761045, 1, 100, 1, 1, 0, 0, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 482399, 0, 420, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 16:13', 116, 0, 230, 1, '', 0, 30, 0, 75, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 5, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 30, 7, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(75, 'Buchqi_Legend', 'buchq1', 14, 15, 0, 0, 0, 0, 0, '193.176.214.22', '193.176.214.22', '193.176.214.22', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 1000500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 270, 813133, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'buchq1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 18:58', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(65, 'Vipstar_Geo', 'vipstargeo', 16, 0, 0, 0, 0, 1, 0, '188.169.212.169', '188.169.212.169', '188.169.212.169', 2000000, 0, 1, '', 300, 0, 402, 0, 0, 1, 0, 0, 0, 1, 7809000, 0, 0, 0, 0, 100, 0, 0, 1, 14, 230, 0, 283, 943355, 1, 300, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 1000, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1076, 255, 0, 0, 0, 76, 76, 0, 0, 1010, 0, '6/3/2022, 21:17', 115, 0, 230, 1, '', 0, 999, 18651, 0, 0, 255, 0, 0, 0, 0, 503, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 25, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(68, 'Tato_Papasky', 'tatotato999', 6, 0, 0, 0, 0, 0, 0, '78.40.106.61', '78.40.106.61', '78.40.106.61', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 997500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 932460, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 1000, '205511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 13:20', 230, 0, 230, 0, '', 1, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(66, 'Nika_Pxakadze', 'nikanika123', 7, 5, 0, 0, 0, 1, 0, '213.200.31.167', '213.200.31.167', '213.200.31.167', 0, 0, 0, '', 100, 0, 462, 1, 250, 1, 0, 0, 0, 7, 3659752, 4, 0, 0, 0, 100, 0, 5, 5, 10, 230, 0, 113, 682007, 1, 100, 1, 1, 0, 1, 1, 4, 255, 0, 0, 0, 0, 0, '-', 0, 30000, 0, 1358, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 19:43', 230, 0, 230, 0, '', 0, 999, 0, 74, 0, 255, 0, 0, 0, 0, 462, 0, 462, 5, 4, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 507, 0, 0, 122, 122, 0, 300, 0, 255, 1073, 18648, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 4, 7, 0, 1010, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(67, 'Gigi_Andersoni', 'dzmebi1012', 1, 0, 0, 0, 0, 0, 0, '213.200.15.159', '213.200.15.159', '213.200.15.159', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 229308, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 14:10', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(71, 'Tato_Beraia', 'tatotato999', 6, 12, 0, 0, 0, 1, 0, '78.40.106.106', '78.40.106.106', '78.40.106.61', 0, 0, 0, '', 100, 0, 462, 0, 93, 1, 0, 0, 0, 1, 3900498, 0, 0, 0, 0, 100, 40, 0, 5, 7, 230, 0, 124, 800391, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 780, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 16:2', 102, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(69, 'Carlito_Invisibles', 'sabasaba212', 1, 0, 0, 0, 0, 0, 0, '178.134.156.164', '178.134.156.164', '178.134.156.164', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 615590, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 13:26', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(70, 'Luka_Alasania', 'lukitopukito', 6, 0, 0, 0, 0, 0, 0, '176.221.181.235', '176.221.181.235', '176.221.181.235', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 1000500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 593807, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '205511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 13:25', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(113, 'Nasha_Giga', 'ana123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 936915, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 11:42', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(99, 'Soxumski_Baza', 'bazabaza2010', 1, 0, 0, 0, 0, 0, 0, '212.58.120.124', '212.58.120.124', '212.58.120.124', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 555796, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 23:55', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(72, 'Tommy_Brown', 'sabuka09', 1, 19, 4, 0, 0, 1, 0, '46.49.50.24', '46.49.50.24', '188.121.192.34', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 2094500, 0, 0, 0, 0, 100, 0, 19, 19, 10, 230, 0, 21, 521113, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 18:59', 230, 0, 230, 0, '', 1, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(76, 'Giorgi_Berdexelia', 'whadi12', 20, 1, 0, 0, 0, 1, 0, '212.58.114.136', '212.58.114.136', '212.58.114.136', 0, 1, 0, '123123', 100, 0, 462, 0, 200, 1, 0, 0, 0, 2, 990750, 7, 0, 0, 0, 100, 0, 0, 17, 1, 230, 0, 114, 252804, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 90000, 0, 1980, '!ikushagiorgi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 14:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(77, 'Giorgi_Berdexel', 'whadi12', 1, 0, 0, 0, 0, 0, 0, '212.58.114.136', '212.58.114.136', '212.58.114.136', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 497497, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 18:7', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(78, 'Onisee_Niqabadze', 'onise2006', 1, 0, 0, 0, 0, 0, 0, '213.200.15.204', '213.200.15.204', '213.200.15.204', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 475672, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 18:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(79, 'Mari_Nikabadze', 'mariam', 1, 0, 0, 0, 0, 1, 0, '213.200.15.204', '213.200.15.204', '213.200.15.204', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 99000, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 448157, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 18:23', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(80, 'Luka_Kamladze', 'lukaluka', 6, 3, 0, 0, 0, 0, 0, '212.58.120.171', '212.58.120.171', '212.58.120.171', 0, 0, 4, '', 100, 0, 462, 0, 200, 1, 0, 0, 0, 1, 922250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 61, 986091, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 19:28', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(81, 'Nikoloz_Qitiashvili', 'nkoloz', 1, 0, 0, 0, 0, 0, 0, '193.176.214.64', '193.176.214.64', '193.176.214.64', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 860823, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '205511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 20:44', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(87, 'George_William', 'Danamesrole123', 1, 0, 0, 0, 0, 0, 0, '5.152.18.100', '5.152.18.100', '5.152.18.100', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 106444, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 1:2', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(82, 'Nikoloz_Qitiashvil', 'nikoloz', 1, 0, 0, 0, 0, 0, 0, '193.176.214.45', '193.176.214.45', '193.176.214.64', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 500145, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 70, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 11:45', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 66, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(98, 'Samuel_Terranova', 'zauri123', 69, 0, 0, 0, 0, 0, 0, '212.58.102.119', '212.58.102.119', '212.58.102.119', 0, 0, 0, '', 300, 0, 424, 3, 0, 1, 0, 0, 0, 1, 290731604, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 340397, 1, 100, 1, 1, 0, 1, 1, 31, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 22:15', 230, 0, 230, 0, '', 0, 999, 0, 96, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 3, 6, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 49980),
(83, 'Saba_Nasyidashvili', 'g1g2g3g4g5', 1, 0, 0, 0, 0, 0, 0, '212.58.102.42', '212.58.102.42', '212.58.102.42', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 149696, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 1702, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 21:7', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(121, 'Samo_Gelashvili', 'samo123', 13, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 641488, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:6', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(84, 'Data_Girdala', 'DAta2007', 1, 0, 0, 0, 0, 0, 0, '212.58.121.4', '212.58.121.4', '212.58.121.4', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 559446, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '6/3/2022, 22:5', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(85, 'Jack_Miler', 'vashligamer', 1, 0, 0, 0, 0, 0, 0, '193.176.214.45', '193.176.214.45', '193.176.214.64', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 546107, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 70, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 15:21', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 66, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(86, 'Gega_Pxakadze', 'gega123', 6, 0, 0, 0, 0, 1, 0, '213.200.31.167', '213.200.31.167', '213.200.31.167', 0, 0, 0, '', 100, 0, 462, 0, 400, 1, 0, 0, 0, 1, 482000, 0, 0, 0, 0, 100, 0, 0, 5, 6, 230, 0, 124, 820136, 1, 100, 1, 1, 0, 0, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:17', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0);
INSERT INTO `accounts` (`pID`, `Name`, `pKey`, `pLevel`, `pForma`, `pAdmin`, `pTechSupport`, `pReporter`, `pPasport`, `pReptool`, `pIp`, `pvIp`, `pIpReg`, `pHousecash`, `pCheckip`, `pText`, `pKeyip`, `pProcents`, `pHP`, `pCar`, `pDonateRank`, `pMats`, `pSex`, `pMuted`, `pColor31`, `pColor32`, `pExp`, `pCash`, `pSilk`, `pPayCheck`, `pJailed`, `pJailTime`, `pProcents2`, `pDrugs`, `pLeader`, `pMember`, `pRank`, `pChar`, `pJob`, `pModel`, `pPnumber`, `pCarLic`, `pProcents1`, `pFlyLic`, `pBoatLic`, `pFishLic`, `pGunLic`, `pBizLic`, `pPhousekey`, `pPbiskey`, `pHotelKey`, `pZakonp`, `pAddiction`, `pVig`, `pMarried`, `pMarriedTo`, `pMuteTime`, `pBank`, `pBanMounth`, `pMobile`, `pDostup`, `pLocked`, `pWantedLevel`, `ptaxiexp`, `ptaxilvl`, `pBoxstyle`, `pKstyle`, `pKickstyle`, `pBoxSkill`, `pKongfuSkill`, `pKickboxSkill`, `pWheels`, `pPaintJob`, `pSpoiler`, `pBumper1`, `pBumper2`, `pColor1`, `pColor2`, `pColor21`, `pColor22`, `pNitro`, `pHydrawlic`, `pOnline`, `pChar1`, `pCigarettes`, `pChar2`, `pViborChar`, `pOnlineLid`, `pLogin`, `pQira`, `pNeon`, `pVipTime`, `pWheels1`, `pPaintJob1`, `pSpoiler1`, `pNeon1`, `pNitro1`, `pHydrawlic1`, `pCar1`, `pBonus`, `pCar2`, `pHealme`, `pQuest`, `pQuestis`, `pWheels2`, `pPaintJob2`, `pSpoiler2`, `pNitro2`, `pHydrawlic2`, `pNeon2`, `pPhonePlayer`, `pBoomBox`, `pBumper11`, `pBumper21`, `pBumper31`, `pBumper32`, `pArmyBilet`, `pArmyTime`, `pCar3`, `pWheels3`, `pSpoiler3`, `pNeon3`, `pNitro3`, `pHydrawlic3`, `pBumper41`, `pBumper42`, `pColor41`, `pColor42`, `pProcents3`, `pSlotItem1`, `pSlotItem2`, `pSlotItem3`, `pSlotItem4`, `pSlotItem5`, `pSlotItem6`, `pSlotItem7`, `pSlotItem8`, `pJackpot`, `pDonateman`, `pDjetx`, `pPromoUse`, `pRoofAir1`, `pRoofAir2`, `pRoofAir3`, `pRoofAir4`, `pGrushiteli1`, `pGrushiteli2`, `pGrushiteli3`, `pGrushiteli4`, `pLowerAir1`, `pLowerAir2`, `pLowerAir3`, `pLowerAir4`, `pFish`, `pQashayi`, `pOraguli`, `pKalmaxi`, `pTut`, `pDataReg`, `pDonatemoney`, `pDrug`, `pBanDay`, `Online_status`, `pTecAdmin`, `pInventory1`, `pInventory2`, `pInventory3`, `pInventory4`, `pInventory5`, `pInventory6`, `pBankomat`, `pKills`, `pDeaths`, `pAdminWarning`, `pElections`, `pCar4`, `pBumper51`, `pBumper52`, `pColor51`, `pColor52`, `pSpoiler4`, `pProcents4`, `pHydrawlic4`, `pPaintJob4`, `pWheels4`, `pNeon4`, `pRoofAir5`, `pGrushiteli5`, `pLowerAir5`, `pCarSlot`, `pBonuscar`, `pWarns`, `punWarns`, `punWarnstime`, `pMusiclic`, `pMagida`, `pAngel`, `pDeath`, `pPubgSkin`, `pSparta`, `pGhostRider`, `pDemon`, `pAxaliskini`, `pPirbade`, `pDancec`, `pDaeswroPaydays`, `pGangKills`, `pPaintJob3`, `pLocal`, `pInt`, `pSpawnloc`, `pNitro4`, `pDartWaider`, `pSpawnChange`, `pFamilyMember`, `pFamilyRank`, `pCarPos`, `pCarPos1`, `pCarPos2`, `pCarPos3`, `pSatiety`, `pHtune`, `pKiborg`, `pObjikt`, `pTrunckStatus`, `pBoat`, `pBoatPos1`, `pBoatPos2`, `pBoatPos3`, `pBoatPos4`, `pCarStatus`, `pCarPenalty1`, `pCarPenalty2`, `pCarPenalty3`, `pCarPenalty4`, `pCarPenalty5`, `pSpawnType`, `pBronzeRoulette`, `pSilverRoulette`, `pGoldRoulette`, `pRouletteMoney`, `pAnswerYes`, `pAnswerNo`, `pVehicleNumberOne`, `pVehicleNumberTwo`, `pVehicleNumberThree`, `pVehicleNumberFour`, `pVehicleNumberFive`, `pAccessories1`, `pAccessories2`, `pAccessories3`, `pAccessories4`, `pAccessories5`, `pAccessories6`, `pAccessories7`, `pAccessories8`, `pAccessories9`, `pAccessories10`, `pAccessories11`, `pAccessories12`, `pAccessories13`, `pAccessories14`, `pAccessories15`, `pAccessories16`, `pAccessories17`, `pAccessories18`, `pAccessories19`, `pAccessories20`, `pGEL`) VALUES
(88, 'Treyz_Wiliam', 'mekkube', 1, 0, 0, 0, 0, 0, 0, '178.134.98.99', '178.134.98.99', '178.134.98.99', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 20, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 305392, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 1:1', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 1, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(91, 'Nika_Motana', 'ferokiller', 1, 15, 0, 0, 0, 0, 0, '91.151.136.170', '91.151.136.170', '91.151.136.170', 0, 0, 4, '', 100, 0, 462, 0, 400, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 270, 371193, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 17:2', 32, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(89, 'Goga_Egutidze', 'VACHEGOGA', 6, 0, 0, 0, 0, 1, 0, '95.137.206.137', '95.137.206.137', '176.74.80.78', 700000, 0, 1, '', 100, 0, 436, 0, 200, 1, 0, 0, 0, 1, 2745, 0, 0, 0, 0, 100, 0, 0, 5, 9, 230, 0, 124, 437578, 1, 100, 1, 1, 0, 0, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 1, 1, 0, 0, 0, 0, '8/3/2022, 10:26', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'XX-XXX-XX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(117, 'Old_Skrezz', 'mekkube', 1, 2, 0, 0, 0, 0, 0, '178.134.98.99', '178.134.98.99', '62.168.184.139', 0, 0, 4, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 294, 826150, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'mekkube', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 16:39', 115, 0, 230, 1, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(102, 'Jack_Ximenez', 'elenna', 1, 0, 0, 0, 0, 0, 0, '31.146.220.68', '31.146.220.68', '31.146.220.68', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 704311, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 14:40', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(90, 'Car_Parking', 'nikoloz', 1, 14, 0, 0, 0, 0, 0, '193.176.214.45', '193.176.214.45', '193.176.214.45', 0, 0, 4, '', 100, 0, 462, 0, 600, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 126, 592254, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 19:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(92, 'Luka_Gelashvili', 'ferokiller', 1, 0, 0, 0, 0, 0, 0, '91.151.136.170', '91.151.136.170', '91.151.136.170', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 224761, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 16:36', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(93, 'Nika_Machaladze', 'nikanika', 1, 0, 0, 0, 0, 0, 0, '213.200.31.248', '213.200.31.248', '213.200.31.248', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 793188, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 17:46', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(95, 'Dufi_korleone', 'sabsusa', 1, 0, 0, 0, 0, 0, 0, '212.58.120.77', '212.58.120.77', '212.58.120.77', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 920060, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 20:53', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(94, 'Bidzina_Hardadze', 'nikoloz', 1, 0, 0, 0, 0, 0, 0, '193.176.214.45', '193.176.214.45', '193.176.214.45', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 683794, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7/3/2022, 21:58', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(96, 'Deufy_Korleone', 'sabsusa', 6, 0, 0, 0, 0, 1, 0, '212.58.120.77', '212.58.120.77', '212.58.120.77', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 1397500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 447773, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 10:33', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 7, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(101, 'Gigson_Allvione', 'aseamxela', 1, 0, 0, 0, 0, 0, 0, '5.178.233.213', '5.178.233.213', '5.178.233.213', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 214825, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 10:56', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(103, 'Jack_Black', 'kkk123', 1, 0, 0, 0, 0, 0, 0, '212.58.120.221', '212.58.120.221', '212.58.120.221', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 893252, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 15:2', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(104, 'Sefo_yoler', 'nikoloz', 1, 0, 0, 0, 0, 0, 0, '193.176.214.91', '193.176.214.91', '193.176.214.91', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 936192, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 15:2', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(105, 'Nika_Abruzi', 'nika123', 1, 0, 0, 0, 0, 0, 0, '212.58.103.57', '212.58.103.57', '212.58.103.57', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 568596, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 15:39', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(107, 'Dadsky_Mamasheni', 'nikusha', 1, 0, 0, 0, 0, 0, 0, '178.134.72.181', '178.134.72.181', '178.134.72.181', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 707509, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '8/3/2022, 21:5', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(106, 'Saben_Diablo', 'sabasaba12', 1, 0, 0, 0, 0, 0, 0, '212.58.103.194', '212.58.103.194', '109.172.209.50', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 523650, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:28', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(114, 'Jeronimo_Brian', 'nikoloz', 6, 5, 0, 0, 0, 1, 0, '193.176.214.82', '193.176.214.82', '193.176.214.82', 0, 0, 4, '', 100, 0, 462, 0, 600, 1, 0, 0, 0, 1, 1444750, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 113, 616872, 1, 100, 1, 1, 0, 0, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 3960, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 16:9', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(108, 'Saba_Montana', 'Saba_MOnt', 1, 0, 0, 0, 0, 0, 0, '45.143.109.78', '45.143.109.78', '45.143.109.78', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 304984, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 10:9', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(109, 'Falcon_Montana', 'aseamxela', 6, 12, 0, 0, 0, 1, 0, '5.178.233.213', '5.178.233.213', '5.178.233.213', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 1, 1, 1, 2249753, 0, 0, 0, 0, 100, 0, 0, 0, 10, 48, 0, 104, 989031, 1, 100, 0, 0, 0, 0, 0, 207, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!2345', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:48', 230, 0, 116, 2, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 565, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 558, 1083, 1023, 18648, 1010, 1087, 1166, 1168, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1091, 0, 0, 0, 1089, 0, 0, 0, 1095, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 255, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XX', 'XX-XXX-XX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(110, 'Rick_Korleone', 'revaza', 6, 14, 0, 0, 0, 1, 0, '212.58.120.77', '212.58.120.77', '212.58.120.77', 0, 0, 0, '', 100, 0, 462, 0, 600, 1, 0, 0, 0, 3, 943750, 4, 0, 0, 0, 100, 0, 0, 1, 12, 143, 0, 280, 816091, 1, 100, 1, 1, 0, 0, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:9', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(112, 'Dufy_Korleone', 'sabsusa', 1, 0, 0, 0, 0, 0, 0, '212.58.120.77', '212.58.120.77', '212.58.120.77', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 258676, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 10:48', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(111, 'Nikoloz_Qitiashvilii', 'nkoloz', 1, 0, 0, 0, 0, 0, 0, '193.176.214.82', '193.176.214.82', '193.176.214.82', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 549351, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 10:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(116, 'Tatex_Martiajs', 'aleksan1', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 839928, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 13:7', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(115, 'Flunix_Resoft', 'aloin123', 1, 18, 6, 0, 0, 0, 0, '212.58.120.170', '212.58.120.170', '212.58.120.170', 0, 0, 0, '', 100, 0, 462, 0, 200, 1, 0, 0, 0, 3, 20250, 4, 0, 0, 0, 100, 0, 18, 18, 10, 230, 0, 273, 388801, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 20000, 0, 0, 'aloin123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:25', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 2, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(126, 'lucy_Senpai', 'sabasaba12', 1, 0, 0, 0, 0, 0, 0, '212.58.103.194', '212.58.103.194', '212.58.103.194', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 229836, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:48', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(119, 'Saba_Shariqadze', 'Saba123', 12, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 338323, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 13:57', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(118, 'Lucky_White', 'Lucky123', 14, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 505098, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 13:56', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(120, 'Aleksandre_Notorius', 'aleksan1', 13, 12, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 12, 12, 10, 230, 0, 104, 276278, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:0', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(122, 'Lukson_Black', 'Luak123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 850695, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 72, 0, '!05511', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:17', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 68, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(123, 'Tonny_Monatnioko', 'tonny123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 898589, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(124, 'Tatela_Papasky', 'tatto123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 136114, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(125, 'Luka_Narimanidze', 'Luka123', 1, 0, 0, 0, 0, 0, 0, '109.172.142.245', '109.172.142.245', '109.172.142.245', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 494000, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 14:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(127, 'Duzo_Williams', 'gagavar', 6, 6, 0, 0, 0, 1, 0, '188.169.37.175', '188.169.37.175', '94.43.58.84', 0, 0, 0, '', 100, 0, 462, 0, 600, 1, 0, 0, 0, 1, 514550, 0, 0, 0, 0, 100, 0, 6, 6, 10, 230, 0, 120, 298322, 1, 100, 1, 1, 0, 1, 1, 267, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'duzovar', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 19:36', 230, 0, 230, 0, '', 1, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 267, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(128, 'George_Oldschool', 'giorga', 1, 15, 0, 0, 0, 0, 0, '212.58.121.64', '212.58.121.64', '212.58.121.64', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 2, 500, 2, 0, 0, 0, 100, 0, 15, 15, 10, 230, 0, 270, 884339, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 10000, 0, 0, 'giorga', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:5', 230, 0, 271, 2, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(129, 'Saba_Tokishvili', 'vashligamer', 1, 0, 0, 0, 0, 0, 0, '193.176.214.82', '193.176.214.82', '193.176.214.82', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 119283, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 16:22', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(136, 'Black_Yaula', 'NIKA123', 1, 0, 0, 0, 0, 1, 0, '178.134.239.98', '178.134.239.98', '212.58.102.106', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 49250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 48, 0, 0, 576191, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 18:41', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(130, 'Eric_Oldschool', 'otooto12', 14, 15, 0, 0, 0, 1, 0, '212.58.120.150', '212.58.120.150', '212.58.120.150', 0, 0, 0, '', 100, 0, 462, 0, 400, 1, 0, 0, 0, 1, 100, 0, 0, 0, 0, 100, 0, 15, 15, 10, 230, 0, 270, 558544, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:18', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(132, 'Tyler_Posey', 'astademon', 1, 0, 0, 0, 0, 0, 0, '213.200.31.244', '213.200.31.244', '213.200.31.244', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 277763, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:19', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(131, 'Uyuness_Resoft', 'uyunesn1', 1, 15, 4, 0, 0, 0, 0, '78.40.106.94', '78.40.106.94', '78.40.106.94', 0, 0, 0, '', 100, 0, 462, 0, 600, 1, 0, 0, 0, 1, 76500, 0, 0, 0, 0, 100, 0, 15, 15, 10, 230, 0, 107, 205084, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'uyunesn1', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:27', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 5, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(133, 'Jack_Sorrow', 'login123', 1, 0, 0, 0, 0, 0, 0, '95.137.170.25', '95.137.170.25', '95.137.170.25', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 595099, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:20', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(134, 'Nika_Abruzzzi', 'nukri123', 1, 0, 0, 0, 0, 0, 0, '212.58.103.57', '212.58.103.57', '212.58.103.57', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 980378, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:22', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0);
INSERT INTO `accounts` (`pID`, `Name`, `pKey`, `pLevel`, `pForma`, `pAdmin`, `pTechSupport`, `pReporter`, `pPasport`, `pReptool`, `pIp`, `pvIp`, `pIpReg`, `pHousecash`, `pCheckip`, `pText`, `pKeyip`, `pProcents`, `pHP`, `pCar`, `pDonateRank`, `pMats`, `pSex`, `pMuted`, `pColor31`, `pColor32`, `pExp`, `pCash`, `pSilk`, `pPayCheck`, `pJailed`, `pJailTime`, `pProcents2`, `pDrugs`, `pLeader`, `pMember`, `pRank`, `pChar`, `pJob`, `pModel`, `pPnumber`, `pCarLic`, `pProcents1`, `pFlyLic`, `pBoatLic`, `pFishLic`, `pGunLic`, `pBizLic`, `pPhousekey`, `pPbiskey`, `pHotelKey`, `pZakonp`, `pAddiction`, `pVig`, `pMarried`, `pMarriedTo`, `pMuteTime`, `pBank`, `pBanMounth`, `pMobile`, `pDostup`, `pLocked`, `pWantedLevel`, `ptaxiexp`, `ptaxilvl`, `pBoxstyle`, `pKstyle`, `pKickstyle`, `pBoxSkill`, `pKongfuSkill`, `pKickboxSkill`, `pWheels`, `pPaintJob`, `pSpoiler`, `pBumper1`, `pBumper2`, `pColor1`, `pColor2`, `pColor21`, `pColor22`, `pNitro`, `pHydrawlic`, `pOnline`, `pChar1`, `pCigarettes`, `pChar2`, `pViborChar`, `pOnlineLid`, `pLogin`, `pQira`, `pNeon`, `pVipTime`, `pWheels1`, `pPaintJob1`, `pSpoiler1`, `pNeon1`, `pNitro1`, `pHydrawlic1`, `pCar1`, `pBonus`, `pCar2`, `pHealme`, `pQuest`, `pQuestis`, `pWheels2`, `pPaintJob2`, `pSpoiler2`, `pNitro2`, `pHydrawlic2`, `pNeon2`, `pPhonePlayer`, `pBoomBox`, `pBumper11`, `pBumper21`, `pBumper31`, `pBumper32`, `pArmyBilet`, `pArmyTime`, `pCar3`, `pWheels3`, `pSpoiler3`, `pNeon3`, `pNitro3`, `pHydrawlic3`, `pBumper41`, `pBumper42`, `pColor41`, `pColor42`, `pProcents3`, `pSlotItem1`, `pSlotItem2`, `pSlotItem3`, `pSlotItem4`, `pSlotItem5`, `pSlotItem6`, `pSlotItem7`, `pSlotItem8`, `pJackpot`, `pDonateman`, `pDjetx`, `pPromoUse`, `pRoofAir1`, `pRoofAir2`, `pRoofAir3`, `pRoofAir4`, `pGrushiteli1`, `pGrushiteli2`, `pGrushiteli3`, `pGrushiteli4`, `pLowerAir1`, `pLowerAir2`, `pLowerAir3`, `pLowerAir4`, `pFish`, `pQashayi`, `pOraguli`, `pKalmaxi`, `pTut`, `pDataReg`, `pDonatemoney`, `pDrug`, `pBanDay`, `Online_status`, `pTecAdmin`, `pInventory1`, `pInventory2`, `pInventory3`, `pInventory4`, `pInventory5`, `pInventory6`, `pBankomat`, `pKills`, `pDeaths`, `pAdminWarning`, `pElections`, `pCar4`, `pBumper51`, `pBumper52`, `pColor51`, `pColor52`, `pSpoiler4`, `pProcents4`, `pHydrawlic4`, `pPaintJob4`, `pWheels4`, `pNeon4`, `pRoofAir5`, `pGrushiteli5`, `pLowerAir5`, `pCarSlot`, `pBonuscar`, `pWarns`, `punWarns`, `punWarnstime`, `pMusiclic`, `pMagida`, `pAngel`, `pDeath`, `pPubgSkin`, `pSparta`, `pGhostRider`, `pDemon`, `pAxaliskini`, `pPirbade`, `pDancec`, `pDaeswroPaydays`, `pGangKills`, `pPaintJob3`, `pLocal`, `pInt`, `pSpawnloc`, `pNitro4`, `pDartWaider`, `pSpawnChange`, `pFamilyMember`, `pFamilyRank`, `pCarPos`, `pCarPos1`, `pCarPos2`, `pCarPos3`, `pSatiety`, `pHtune`, `pKiborg`, `pObjikt`, `pTrunckStatus`, `pBoat`, `pBoatPos1`, `pBoatPos2`, `pBoatPos3`, `pBoatPos4`, `pCarStatus`, `pCarPenalty1`, `pCarPenalty2`, `pCarPenalty3`, `pCarPenalty4`, `pCarPenalty5`, `pSpawnType`, `pBronzeRoulette`, `pSilverRoulette`, `pGoldRoulette`, `pRouletteMoney`, `pAnswerYes`, `pAnswerNo`, `pVehicleNumberOne`, `pVehicleNumberTwo`, `pVehicleNumberThree`, `pVehicleNumberFour`, `pVehicleNumberFive`, `pAccessories1`, `pAccessories2`, `pAccessories3`, `pAccessories4`, `pAccessories5`, `pAccessories6`, `pAccessories7`, `pAccessories8`, `pAccessories9`, `pAccessories10`, `pAccessories11`, `pAccessories12`, `pAccessories13`, `pAccessories14`, `pAccessories15`, `pAccessories16`, `pAccessories17`, `pAccessories18`, `pAccessories19`, `pAccessories20`, `pGEL`) VALUES
(135, 'Nika_Abruzzi', 'nika123', 6, 37, 7, 0, 0, 0, 0, '212.58.103.57', '212.58.103.57', '212.58.103.57', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 97500, 0, 0, 0, 0, 100, 0, 37, 37, 10, 230, 0, 295, 628577, 1, 100, 1, 1, 0, 1, 1, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 980, 'nika123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 19:38', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(137, 'Salome_Dadiani', 'sabasaba12', 6, 0, 0, 0, 0, 0, 0, '212.58.103.194', '212.58.103.194', '212.58.103.194', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 1027250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 620797, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:57', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(138, 'FIona_Diablo', 'Giorgi2007', 6, 0, 0, 0, 0, 0, 0, '109.172.209.50', '109.172.209.50', '109.172.209.50', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 995250, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 426494, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 17:56', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(139, 'Luka_Kudukashvili', 'lukaluka111', 1, 0, 0, 0, 0, 0, 0, '188.169.128.215', '188.169.128.215', '188.169.128.215', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 532052, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, '!05511', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 19:0', 230, 0, 230, 0, '', 0, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0),
(140, 'Giorgi_Sologa', 'giorgi12345', 1, 0, 2, 0, 0, 1, 0, '212.58.120.56', '212.58.120.56', '212.58.120.56', 0, 0, 0, '', 100, 0, 462, 0, 0, 1, 0, 0, 0, 1, 400500, 0, 0, 0, 0, 100, 0, 0, 0, 0, 230, 0, 0, 441672, 0, 100, 0, 0, 0, 0, 0, 999, 255, 0, 0, 0, 0, 0, '-', 0, 0, 0, 0, 'gio123', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9/3/2022, 19:32', 230, 0, 230, 0, '', 1, 999, 0, 0, 0, 255, 0, 0, 0, 0, 462, 0, 462, 0, 0, 0, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 9, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 462, 0, 0, 0, 0, 0, 100, 0, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 'XX-XXX-XXX', 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 19475, 0);

-- --------------------------------------------------------

--
-- Table structure for table `anticheat_settings`
--

CREATE TABLE `anticheat_settings` (
  `ac_code` int(2) NOT NULL,
  `ac_code_trigger_type` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `anticheat_settings`
--

INSERT INTO `anticheat_settings` (`ac_code`, `ac_code_trigger_type`) VALUES
(0, 1),
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 0),
(8, 0),
(9, 1),
(10, 1),
(11, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(18, 0),
(19, 0),
(20, 0),
(21, 0),
(22, 0),
(23, 0),
(24, 0),
(25, 0),
(26, 1),
(27, 0),
(28, 0),
(29, 0),
(30, 0),
(31, 0),
(32, 0),
(33, 0),
(34, 0),
(35, 0),
(36, 0),
(37, 0),
(38, 0),
(39, 0),
(40, 0),
(41, 0),
(42, 0),
(43, 0),
(44, 0),
(45, 0),
(46, 0),
(47, 0),
(48, 1),
(49, 1),
(50, 0),
(51, 0),
(52, 0);

-- --------------------------------------------------------

--
-- Table structure for table `AutoSalon`
--

CREATE TABLE `AutoSalon` (
  `ID` int(11) NOT NULL,
  `CarPosX` float NOT NULL,
  `CarPosY` float NOT NULL,
  `CarPosZ` float NOT NULL,
  `CarPosC` float NOT NULL,
  `CarOwner` varchar(32) NOT NULL,
  `CarID` int(11) NOT NULL,
  `CarPrice` int(11) NOT NULL,
  `CarStatus` int(11) NOT NULL,
  `CarSlot` int(11) NOT NULL,
  `CarTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `banip`
--

CREATE TABLE `banip` (
  `ID` int(11) NOT NULL,
  `IP` varchar(128) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL,
  `Dge` int(11) NOT NULL,
  `Admin` varchar(128) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL,
  `Tarigi` varchar(128) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Table structure for table `banlog`
--

CREATE TABLE `banlog` (
  `ID` int(11) NOT NULL,
  `Text` varchar(255) NOT NULL,
  `Name` varchar(128) NOT NULL,
  `NameAdmin` varchar(128) NOT NULL,
  `Date` varchar(128) NOT NULL,
  `Day` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Table structure for table `bizz`
--

CREATE TABLE `bizz` (
  `bID` int(11) NOT NULL,
  `bOwned` int(11) NOT NULL,
  `bOwner` varchar(32) NOT NULL,
  `bMessage` varchar(64) NOT NULL,
  `bEntranceX` float NOT NULL,
  `bEntranceY` float NOT NULL,
  `bEntranceZ` float NOT NULL,
  `bExitX` float NOT NULL,
  `bExitY` float NOT NULL,
  `bExitZ` float NOT NULL,
  `bBuyPrice` int(11) NOT NULL,
  `bEntranceCost` int(11) NOT NULL,
  `bTill` int(11) NOT NULL,
  `bInterior` int(11) NOT NULL,
  `bProducts` int(11) NOT NULL,
  `bPrice` int(11) NOT NULL,
  `bBarX` float NOT NULL,
  `bBarY` float NOT NULL,
  `bBarZ` float NOT NULL,
  `bMafia` int(11) NOT NULL,
  `bType` int(11) NOT NULL,
  `bVirtualWorld` int(11) NOT NULL,
  `bEnterPosX` float NOT NULL,
  `bEnterPosY` float NOT NULL,
  `bEnterPosZ` float NOT NULL,
  `bExitPosX` float NOT NULL,
  `bExitPosY` float NOT NULL,
  `bExitPosZ` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bizz`
--

INSERT INTO `bizz` (`bID`, `bOwned`, `bOwner`, `bMessage`, `bEntranceX`, `bEntranceY`, `bEntranceZ`, `bExitX`, `bExitY`, `bExitZ`, `bBuyPrice`, `bEntranceCost`, `bTill`, `bInterior`, `bProducts`, `bPrice`, `bBarX`, `bBarY`, `bBarZ`, `bMafia`, `bType`, `bVirtualWorld`, `bEnterPosX`, `bEnterPosY`, `bEnterPosZ`, `bExitPosX`, `bExitPosY`, `bExitPosZ`) VALUES
(1, 1, 'Xuco_Kalashnikovi', 'Alhambra', 1836.51, -1682.58, 13.345, 493.487, -24.9609, 1000.67, 15000000, 1000, 1000, 17, 20000, 1000, 499.97, -20.7076, 1000.68, 27, 1, 1, 1834.31, -1682.79, 13.4367, 492.998, -22.1078, 1000.68),
(2, 1, 'Orton_Destroy', 'PigPen', 2421.59, -1219.51, 25.5444, 1204.67, -13.8521, 1000.92, 15000000, 1000, 23000, 2, 19646, 1000, 1215.29, -13.2987, 1000.92, 11, 1, 2, 2421.25, -1221.78, 25.3987, 1205.03, -11.4166, 1000.92),
(3, 1, 'Luka_Makharoblidze', 'Misty Market', 1030.29, 1847.8, 11.4683, -2240.47, 137.06, 1035.41, 20000000, 1000, 2200, 6, 19801, 1000, -2236.11, 130.158, 1035.41, 11, 3, 3, 1030.29, 1847.8, 11.4683, -2240.47, 137.06, 1035.41),
(4, 1, 'Tommy_Miller', 'Casino Adjara', 2019.6, 1007.8, 10.8203, 1133, -15.3091, 1000.68, 1000000000, 1000, 255019360, 12, 10000, 1000, 1139.72, -4.90998, 1000.67, 27, 2, 4, 2021.64, 1007.76, 10.8203, 1133.09, -12.6875, 1000.68),
(5, 1, 'Alex_Xucidze', 'Grove Street Bar', 2309.95, -1643.42, 14.8269, 501.903, -67.563, 998.758, 10000000, 1000, 5000, 11, 19916, 1000, 497.353, -76.0409, 998.758, 11, 1, 5, 2309.99, -1645.96, 14.827, 501.739, -69.8445, 998.758),
(6, 1, 'Roy_Wallker', 'Sobrino de Botin', 1531.56, 2703.87, 10.8125, -2240.47, 137.06, 1035.41, 10000000, 1000, 2100, 6, 19672, 1000, -2236.11, 130.158, 1035.41, 11, 3, 6, 1531.59, 2705.88, 10.8125, -2238.59, 136.443, 1035.41),
(7, 1, 'Darshon_Foster', 'Idelwood 24/7', 1928.6, -1776.17, 13.5468, -2240.47, 137.06, 1035.41, 20000000, 1000, 4100, 6, 3955, 1000, -2236.11, 130.158, 1035.41, 27, 3, 12, 1930.81, -1776.1, 13.5469, -2239.64, 134.628, 1035.41),
(8, 1, 'Giorgi_Woworia', 'MiniMarket', 1833.78, -1842.6, 13.5781, -2240.47, 137.06, 1035.41, 20000000, 100, 35623200, 6, 16117, 100, -2236.11, 130.158, 1035.41, 20, 3, 14, 1830.92, -1842.62, 13.5781, -2238.47, 136.996, 1035.41),
(9, 1, 'Jon_Konor', 'Mullholand 24/7', 1000.59, -919.911, 42.328, -2240.47, 137.06, 1035.41, 20000000, 1000, 400, 6, 19974, 1000, -2236.11, 130.158, 1035.41, 11, 3, 15, 997.831, -919.912, 42.1797, -2238.12, 136.471, 1035.41),
(10, 1, 'Yuri_Boyka', 'Jizzy', -2624.49, 1411.88, 7.0938, -2636.61, 1404.99, 906.461, 10000000, 1000, 15000, 3, 19934, 1000, -2654.02, 1407.91, 906.277, 27, 1, 16, -2623.64, 1409, 7.1016, -2639.81, 1405.72, 906.461),
(11, 1, 'Nodo_Smith', 'Redsands West 24/7', 1599.12, 2221.87, 11.0625, -2240.47, 137.06, 1035.41, 20000000, 1000, 15300, 6, 19804, 100, -2236.11, 130.158, 1035.41, 20, 3, 17, 1600.29, 2220.33, 11.0625, -2237.77, 137.028, 1035.41),
(12, 1, 'Thomas_Anderson', 'Smart', 2481.59, -1758.02, 13.5469, -2240.47, 137.06, 1035.41, 20000000, 1000, 1800, 6, 9950, 1000, -2236.11, 130.158, 1035.41, 11, 3, 18, 2482.02, -1755.31, 13.5469, -2237.77, 136.906, 1035.41),
(13, 1, 'Maik_Jonson', 'Night Market', 2502.58, 1622.59, 10.8203, -2240.47, 137.06, 1035.41, 20000000, 1000, 8100, 6, 19940, 1000, -2236.11, 130.158, 1035.41, 27, 3, 19, 2502.35, 1620.36, 10.8203, -2237.63, 136.591, 1035.41),
(14, 1, 'Jack_Miller', 'Idelwood Gas', 1940.93, -1772.94, 13.6406, 0, 0, 0, 10000000, 0, 14700698, 0, 14980, 1000, 0, 0, 0, 20, 4, 20, 0, 0, 0, 0, 0, 0),
(15, 1, 'Nick_Zetas', 'Mullholand Gas', 1003.76, -936.11, 42.3281, 0, 0, 0, 10000000, 0, 37946000, 0, 19000, 1000, 0, 0, 0, 11, 4, 21, 0, 0, 0, 0, 0, 0),
(16, 1, 'Jack_Miller', 'Nikora', 1352.35, -1759.25, 13.5078, -2240.47, 137.06, 1035.41, 20000000, 100, 171551199, 6, 9254, 1000, -2236.11, 130.158, 1035.41, 27, 3, 22, 1352.67, -1757.1, 13.5078, -2238.27, 136.885, 1035.41),
(17, 1, 'Little_Sphynx', 'Cerry Market', 2007.42, 1167.46, 10.8203, -2240.47, 137.06, 1035.41, 20000000, 1000, 7700, 6, 17339, 1000, -2236.11, 130.158, 1035.41, 11, 3, 24, 2009.87, 1167.22, 10.8203, -2238.16, 137.334, 1035.41),
(18, 1, 'Merab_Gelashvili', 'Grey Market', -1606.77, -2714.39, 48.7951, 0, 0, 0, 20000000, 1000, 6900, 0, 20000, 100, 0, 0, 0, 11, 4, 30, 0, 0, 0, 0, 0, 0),
(19, 1, 'Young_Todu', 'LS Bank', 1461.09, -1010.46, 26.8438, 304.781, 1329.32, 2023.84, 50000000, 1000, 599615, 1, 25000, 1000, 0, 0, 0, 27, 5, 15, 1461.86, -1013.85, 26.7938, 1319.33, 12.4075, 2068.51),
(20, 1, 'Luka_Kantela', 'Bandidos 24/7', 495.593, -1915.61, 7.0422, -2240.47, 137.06, 1035.41, 10000000, 500, 2718, 6, 16910, 1000, -2236.11, 130.158, 1035.41, 11, 3, 25, 1930.81, -1776.1, 13.5469, -2239.64, 134.628, 1035.41),
(21, 1, 'Yung_Kaxasha', 'GunShop', 1368.99, -1279.7, 13.5469, 315.783, -143.665, 999.602, 10000000, 1000, 168150800, 7, 10000, 200, -2236.11, 130.158, 1035.41, 11, 5, 0, 1930.81, -1776.1, 13.5469, -2239.64, 134.628, 1035.41),
(22, 0, 'Jack_Miller', 'SkinShop', 461.711, -1500.84, 31.0448, 207.031, -140.376, 1003.51, 10000000, 1000, 203648000, 3, 10000, 1000, 0, 0, 0, 27, 5, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `carkeys`
--

CREATE TABLE `carkeys` (
  `ID` int(11) NOT NULL,
  `Owner` varchar(28) NOT NULL,
  `Player` varchar(28) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cj_skin`
--

CREATE TABLE `cj_skin` (
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `CMDLog`
--

CREATE TABLE `CMDLog` (
  `ID` int(11) NOT NULL,
  `CMD` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Admin` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Name` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Data` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Time` varchar(32) CHARACTER SET cp1251 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `cmds`
--

CREATE TABLE `cmds` (
  `Name` varchar(45) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL,
  `CMD` varchar(45) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cmds`
--

INSERT INTO `cmds` (`Name`, `CMD`) VALUES
('Giorgi_Kings', 'mafialeader'),
('Flunix_Resoft', 'gangleader'),
('Nika_Abruzzi', 'otherleader'),
('Bob_Anderson', 'techsupport');

-- --------------------------------------------------------

--
-- Table structure for table `Family`
--

CREATE TABLE `Family` (
  `FamilyID` int(11) NOT NULL,
  `FamilyName` varchar(20) NOT NULL,
  `FamilyLeader` varchar(32) NOT NULL,
  `FamilyCoLeader` varchar(32) NOT NULL,
  `FamilyType` int(11) NOT NULL,
  `FamilyColor` int(11) NOT NULL,
  `FamilyHouseID` int(11) NOT NULL,
  `FamilySkinID` int(11) NOT NULL,
  `FamilyMaterials` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `FracBank`
--

CREATE TABLE `FracBank` (
  `BallasBank` int(11) NOT NULL,
  `VagosBank` int(11) NOT NULL,
  `GroveBank` int(11) NOT NULL,
  `AztecaBank` int(11) NOT NULL,
  `RifaBank` int(11) NOT NULL,
  `YakuzaBank` int(11) NOT NULL,
  `LCNBank` int(11) NOT NULL,
  `RMBank` int(11) NOT NULL,
  `LSNewsBank` int(11) NOT NULL,
  `CityHallBank` int(11) NOT NULL,
  `healpric` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `FracBank`
--

INSERT INTO `FracBank` (`BallasBank`, `VagosBank`, `GroveBank`, `AztecaBank`, `RifaBank`, `YakuzaBank`, `LCNBank`, `RMBank`, `LSNewsBank`, `CityHallBank`, `healpric`) VALUES
(0, 39250, 0, 12034, 0, 117000, 297000, 248999, 3126730, 23768219, 50);

-- --------------------------------------------------------

--
-- Table structure for table `FracWH`
--

CREATE TABLE `FracWH` (
  `BallasMat` int(11) NOT NULL,
  `VagosMat` int(11) NOT NULL,
  `GroveMat` int(11) NOT NULL,
  `AztecaMat` int(11) NOT NULL,
  `RifaMat` int(11) NOT NULL,
  `BallasDrugs` int(11) NOT NULL,
  `VagosDrugs` int(11) NOT NULL,
  `GroveDrugs` int(11) NOT NULL,
  `AztecaDrugs` int(11) NOT NULL,
  `RifaDrugs` int(11) NOT NULL,
  `YakuzaMat` int(11) NOT NULL,
  `LCNMat` int(11) NOT NULL,
  `RMMat` int(11) NOT NULL,
  `NewfracDrugs` int(11) NOT NULL,
  `healpric` int(11) NOT NULL,
  `TotalNumbers` int(11) NOT NULL,
  `BandidosMat` int(11) NOT NULL,
  `GGFMat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `FracWH`
--

INSERT INTO `FracWH` (`BallasMat`, `VagosMat`, `GroveMat`, `AztecaMat`, `RifaMat`, `BallasDrugs`, `VagosDrugs`, `GroveDrugs`, `AztecaDrugs`, `RifaDrugs`, `YakuzaMat`, `LCNMat`, `RMMat`, `NewfracDrugs`, `healpric`, `TotalNumbers`, `BandidosMat`, `GGFMat`) VALUES
(95807, 58820, 59138, 94900, 59028, 2078, 3741, 2370, 2955, 179, 96800, 84900, 95500, 4988, 25, 105, 84596, 100000);
-- --------------------------------------------------------

--
-- Table structure for table `GreenZone`
--

CREATE TABLE IF NOT EXISTS `GreenZone` (
`ZoneID` int(11) NOT NULL,
  `ZoneName` varchar(64) CHARACTER SET cp1251 NOT NULL,
  `ZonePosX` float NOT NULL,
  `ZonePosY` float NOT NULL,
  `ZonePosZ` float NOT NULL,
  `ZoneDistance` int(11) NOT NULL,
  `ZoneVirtualWorld` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `GreenZone`
--

INSERT INTO `GreenZone` (`ZoneID`, `ZoneName`, `ZonePosX`, `ZonePosY`, `ZonePosZ`, `ZoneDistance`, `ZoneVirtualWorld`) VALUES
(1, '50Niggaz', 1299.38, 1299.38, 1084.01, 0, 20),
(2, 'VorZakone', -825.065, -825.065, 3058.22, 0, 11),
(3, 'Gza', 1811.91, 1811.91, 13.5469, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

CREATE TABLE `house` (
  `hID` int(11) NOT NULL,
  `hEntrancex` float NOT NULL,
  `hEntrancey` float NOT NULL,
  `hEntrancez` float NOT NULL,
  `hExitx` float NOT NULL,
  `hExity` float NOT NULL,
  `hExitz` float NOT NULL,
  `hCarx` float NOT NULL,
  `hCary` float NOT NULL,
  `hCarz` float NOT NULL,
  `hCarc` float NOT NULL,
  `hOwner` varchar(40) NOT NULL,
  `hValue` int(11) NOT NULL,
  `hInt` int(11) NOT NULL,
  `hLock` int(11) NOT NULL,
  `hOwned` int(11) NOT NULL,
  `hDate` int(11) NOT NULL,
  `hKlass` int(11) NOT NULL,
  `hM1` varchar(40) NOT NULL,
  `hM2` varchar(40) NOT NULL,
  `hNarko` int(11) NOT NULL,
  `hDgl` int(11) NOT NULL,
  `hEm` int(11) NOT NULL,
  `hShot` int(11) NOT NULL,
  `hGarageStatus` int(11) NOT NULL,
  `hBalance` int(11) NOT NULL,
  `hTax` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 PACK_KEYS=0 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `house`
--

INSERT INTO `house` (`hID`, `hEntrancex`, `hEntrancey`, `hEntrancez`, `hExitx`, `hExity`, `hExitz`, `hCarx`, `hCary`, `hCarz`, `hCarc`, `hOwner`, `hValue`, `hInt`, `hLock`, `hOwned`, `hDate`, `hKlass`, `hM1`, `hM2`, `hNarko`, `hDgl`, `hEm`, `hShot`, `hGarageStatus`, `hBalance`, `hTax`) VALUES
(1, 2102.5, 2229.08, 11.0234, 225.705, 1021.86, 1084.02, 2103.24, 2215.61, 10.8203, 267.569, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(2, -321.222, 1124.98, 20.9399, 225.705, 1021.86, 1084.02, -317.375, 1133.71, 19.738, 54.217, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(3, -340.014, 1120.01, 325.587, 2308.8, -1212.84, 1049.02, 1678.93, -1616.82, 13.5469, 266.24, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(4, 2163.43, 2066.72, 10.8203, 225.705, 1021.86, 1084.02, 2155.1, 2063.38, 10.6719, 358.541, 'Nika_Pxakadze', 2000000, 7, 1, 1, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 96340, 1100),
(5, -1018.09, 1916.17, 423.811, 83.0589, 1322.55, 1083.87, 230.176, -1255.34, 68.5139, 140.086, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(6, -1016.89, 1911.98, 447.984, 83.0589, 1322.55, 1083.87, 1425.33, -1555.95, 13.5391, 177.114, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(7, 1498.44, -1580.84, 13.5498, 225.705, 1021.86, 1084.02, 1507.65, -1586.57, 13.5469, 88.8774, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(8, -2875.1, 2807.4, 251.645, 225.705, 1021.86, 1084.02, -2846.19, 2804.16, 243.485, 197.772, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(9, 485.139, -1114.2, 82.3594, 225.705, 1021.86, 1084.02, 500.419, -1083.82, 82.1506, 278.967, 'The State', 2000000, 7, 1, 0, 0, 4, 'Lack_Kapono', 'Lasha_Vashakidze', 0, 0, 0, 0, 0, 96900, 1100),
(10, -1020.44, 1912.45, 446.765, 83.0589, 1322.55, 1083.87, 1426.64, -1566.06, 13.3516, 175.931, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(11, -1031.95, 1918.65, 438.865, 2308.8, -1212.84, 1049.02, 1424.2, -1566.23, 13.5469, 345.895, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(12, 1976.21, -1634.03, 18.569, 225.705, 1021.86, 1084.02, 1967.61, -1638.44, 15.9688, 276.658, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 151100, 1100),
(13, -892.338, 1933.71, 476.24, 83.0589, 1322.55, 1083.87, 1425.18, -1626.79, 13.3828, 180.781, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(14, 1872.26, -1911.79, 15.2568, 83.0589, 1322.55, 1083.87, 1872.29, -1927.24, 13.5469, 83.8097, 'The State', 900000, 9, 1, 0, 0, 2, 'Luka_Cincadze', 'None', 0, 0, 0, 0, 0, 0, 700),
(15, 2163.47, 2056.96, 10.8203, 234.138, 1063.9, 1084.21, 2154.49, 2054.36, 10.6719, 357.772, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 150300, 900),
(16, -795.846, 2259.56, 59.4689, 2270.05, -1210.46, 1047.56, -787.999, 2256.3, 59.6565, 163.349, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(17, -910.92, 2686.23, 42.3703, 225.705, 1021.86, 1084.02, -908.714, 2696.8, 42.3672, 317.175, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 151100, 1100),
(18, 2017.67, 1905.59, 12.3269, 225.705, 1021.86, 1084.02, 2032.12, 1907.17, 12.2949, 184.34, 'The State', 2000000, 7, 1, 0, 0, 4, 'Giorgi_Flex', 'Giuseppe_Morello', 0, 0, 0, 0, 0, 0, 1100),
(19, 2523.27, -1679.37, 15.497, 225.705, 1021.86, 1084.02, 2516.63, -1674.33, 13.9783, 65.4051, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 180000, 1100),
(20, 2513.76, -1650.29, 14.3557, 234.138, 1063.9, 1084.21, 2506.09, -1664.88, 13.3952, 23.1169, 'Luk_Miller', 1000000, 6, 1, 1, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 123400, 900),
(21, 662.609, -1787.8, 12.4688, 234.138, 1063.9, 1084.21, 652.612, -1794.7, 11.9132, 179.538, 'The State', 1000000, 6, 1, 0, 0, 3, 'Anuki_Russel', 'None', 0, 0, 0, 0, 0, 0, 900),
(22, 2362.79, -1643.14, 14.3516, 225.705, 1021.86, 1084.02, 2375.87, -1640.87, 13.5016, 170.626, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tony_MarshalI', 'Louis_Walker', 0, 0, 0, 0, 0, 149700, 1100),
(23, 1774.5, -1964.33, 324.473, 83.0589, 1322.55, 1083.87, 1775.42, -1963.19, 343.987, 358.985, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(24, 653.596, -1713.91, 14.7648, 225.705, 1021.86, 1084.02, 643.514, -1705.68, 14.6065, 170.042, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(25, 1540.47, -851.399, 64.3361, 225.705, 1021.86, 1084.02, 1522.69, -843.211, 66.4665, 66.5838, 'The State', 2000000, 7, 1, 0, 0, 4, 'Santa_Klaus', 'None', 0, 0, 0, 0, 0, 0, 1100),
(26, 2322, -1796.27, 13.5469, 225.705, 1021.86, 1084.02, 2328.65, -1791.46, 13.5469, 356.468, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 1, 148000, 1100),
(27, 2309, -1714.33, 14.9801, 234.138, 1063.9, 1084.21, 2309.52, -1725.65, 13.5469, 307.636, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 87300, 900),
(28, 1658.42, -1343.29, 17.4378, 225.705, 1021.86, 1084.02, 1653.76, -1344.64, 17.4297, 69.6116, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 300, 300, 300, 0, 52800, 1100),
(29, -251.121, 1049.85, 20.9399, 83.0589, 1322.55, 1083.87, -254.501, 1056.92, 19.7485, 93.0756, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(30, 1451.64, -2287.04, 13.5469, 225.705, 1021.86, 1084.02, 1540.55, -923.618, 43.2264, 287.341, 'Giorgi_Kings', 2000000, 7, 0, 1, 0, 4, 'None', 'Slayes_Revaza', 0, 0, 0, 0, 1, 28600, 1100),
(31, 254.522, -1367.33, 53.1094, 225.705, 1021.86, 1084.02, 264.947, -1369.47, 53.1094, 355.623, 'Samuel_Terranova', 2000000, 7, 1, 1, 0, 4, 'Gabriel_Chachxo', 'Young_Todu', 0, 0, 0, 0, 0, 181100, 1100),
(32, 416.742, -1154.1, 76.6876, 83.0589, 1322.55, 1083.87, 383.604, -1153, 78.1287, 161.784, 'The State', 900000, 9, 1, 0, 0, 2, 'Gega_Londaridze', 'Kote_Kobeshavidze', 0, 0, 0, 0, 0, 0, 700),
(33, 992.497, -1817.6, 13.8942, 83.0589, 1322.55, 1083.87, 999.445, -1820.2, 13.8925, 341.883, 'The State', 900000, 9, 1, 0, 0, 2, 'Luka_Paul', 'Kevin_Makalyster', 0, 250, 315, 200, 0, 0, 700),
(34, 980.835, -1814.79, 13.889, 2270.05, -1210.46, 1047.56, 981.16, -1807.55, 14.2406, 10.7776, 'The State', 700000, 10, 1, 0, 0, 1, 'Iakob_Gogebashvili', 'None', 0, 0, 0, 0, 0, 68500, 500),
(35, 2067.05, -1731.63, 14.2066, 234.138, 1063.9, 1084.21, 2178.91, -1792.74, 13.3586, 131.558, 'The State', 1000000, 6, 1, 0, 0, 3, 'Swads_Winston', 'Angel_Skrezz', 0, 0, 0, 0, 0, 0, 900),
(36, 969.468, -1811.99, 13.8835, 234.138, 1063.9, 1084.21, 972.264, -1800.59, 14.0913, 252.933, 'The State', 1000000, 6, 1, 0, 0, 3, 'Luka_Ruardes', 'None', 0, 0, 0, 0, 0, 23400, 900),
(37, 2065.18, -1703.55, 14.1484, 225.705, 1021.86, 1084.02, 2056.53, -1694.86, 13.5547, 269.613, 'The State', 2000000, 7, 1, 0, 0, 4, 'Irakli_Kozanostra', 'Soso_Willson', 0, 0, 0, 0, 0, 0, 1100),
(38, 2066.74, -1656.42, 14.1328, 83.0589, 1322.55, 1083.87, 2073.54, -1655.37, 13.5469, 324.784, 'The State', 900000, 9, 1, 0, 0, 2, 'Nikusha_Machaidze', 'None', 0, 0, 0, 0, 0, 700, 700),
(39, 476.242, -1501.3, 20.5313, 225.705, 1021.86, 1084.02, 283.505, -1160.53, 80.9141, 225.486, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(40, 2067.7, -1628.8, 14.2066, 225.705, 1021.86, 1084.02, 2056.98, -1636.34, 13.5469, 271.356, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 95700, 1100),
(41, 958.158, -1809.19, 13.8812, 225.705, 1021.86, 1084.02, 958.079, -1800.35, 14.2762, 258.278, 'The State', 2000000, 7, 1, 0, 0, 4, 'Olajide_Olatunji', 'Vexo_Galaxvaridze', 0, 0, 0, 0, 0, 184800, 1100),
(42, 933.733, -1805.21, 13.8433, 225.705, 1021.86, 1084.02, 934.792, -1791.44, 13.6186, 258.526, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tom_Hollen', 'None', 0, 0, 0, 0, 0, 0, 1100),
(43, 512.187, -2055.59, 9.30966, 225.705, 1021.86, 1084.02, 552.647, -2035.5, 4.49443, 306.009, 'The State', 2000000, 7, 1, 0, 0, 4, 'Giorgi_Savshishvili', 'None', 0, 0, 0, 0, 0, 159200, 1100),
(44, 245.681, -1874.96, 405.972, 83.0589, 1322.55, 1083.87, 248.158, -1883.47, 1.30334, 93.4563, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(45, 922.006, -1803.89, 13.8377, 225.705, 1021.86, 1084.02, 940.601, -1807.78, 13.7155, 188.921, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Ana_Winvston', 0, 0, 0, 0, 0, 0, 1100),
(46, 2018.05, -1630.03, 14.0426, 225.705, 1021.86, 1084.02, 2011.89, -1630.63, 13.5469, 109.601, 'The State', 2000000, 7, 1, 0, 0, 4, 'Bacho_Gabit', 'None', 0, 0, 0, 0, 0, 0, 1100),
(47, 910.116, -1802.67, 13.7994, 225.705, 1021.86, 1084.02, 923.545, -1789.05, 13.3838, 256.719, 'The State', 2000000, 7, 1, 0, 0, 4, 'Pako_Zaqroshvili', 'Naruto_Uzumaki', 0, 0, 0, 0, 0, 1100, 1100),
(48, 1981.28, -1682.68, 17.0535, 225.705, 1021.86, 1084.02, 2000.29, -1673.45, 13.3828, 280.801, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Curse_Primeiro', 300, 250, 300, 0, 0, 126900, 1100),
(49, 1359.34, -339.612, 1474.17, 2308.8, -1212.84, 1049.02, 1368.51, -1089.51, 24.5795, 169.235, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(50, 790.926, -1661.14, 13.4847, 225.705, 1021.86, 1084.02, 785.002, -1666.5, 13.4519, 95.0052, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Marselin_Hyuga', 0, 0, 0, 0, 0, 101800, 1100),
(51, -2091.41, 2646.44, 157.402, 225.705, 1021.86, 1084.02, -2094.26, 2655.03, 159.766, 42.0364, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(52, 264.024, -1765.46, 4.75678, 225.705, 1021.86, 1084.02, 260.367, -1776.79, 4.17614, 228.629, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 152700, 1100),
(53, 192.869, -1769.39, 4.32859, 225.705, 1021.86, 1084.02, 192.519, -1774.79, 3.69431, 266.322, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tonny_Lanski', 'Guram_Svanidze', 0, 0, 0, 0, 0, 178100, 1100),
(54, 168.298, -1768.41, 4.48702, 2270.05, -1210.46, 1047.56, 1457.85, -1712.28, 13.3717, 355.695, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 500, 500),
(55, 1711.47, -2101.24, 14.021, 225.705, 1021.86, 1084.02, 1726.4, -2108.02, 13.3828, 256.059, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(56, 652.665, -1694.01, 14.5501, 2270.05, -1210.46, 1047.56, 645.746, -1690.84, 14.8935, 356.816, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 300, 300, 300, 0, 84000, 500),
(57, 1715.22, -2125.45, 14.0566, 225.705, 1021.86, 1084.02, 1717.02, -2118.45, 13.5469, 267.034, 'The State', 2000000, 7, 1, 0, 0, 4, 'Ikako_Akolashvili', 'George_Dumbadze', 0, 0, 0, 0, 0, 0, 1100),
(58, 883.144, -1800.39, 13.8014, 234.138, 1063.9, 1084.21, 893.194, -1794.84, 13.6317, 7.19538, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'Jeison_Stethemi', 0, 0, 0, 0, 0, 24300, 900),
(59, 866.56, -1798.93, 13.8157, 225.705, 1021.86, 1084.02, 833.415, -1797.33, 13.6592, 180.103, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(60, 802.697, -1795.76, 13.0234, 225.705, 1021.86, 1084.02, 809.203, -1791.38, 13.4296, 270.465, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 63, 0, 0, 0, 0, 0, 1100),
(61, 690.946, -583.28, 16.3281, 225.705, 1021.86, 1084.02, 686.766, -579.786, 16.3359, 359.305, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(62, 794.279, -1795.76, 13.0234, 225.705, 1021.86, 1084.02, 790.862, -1784.39, 13.1659, 356.664, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(63, -2016.35, 897.62, 45.4453, 225.705, 1021.86, 1084.02, -86.3939, -1572.51, 2.61719, 238.436, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(64, 561.47, -1504.88, 14.539, 225.705, 1021.86, 1084.02, 544.714, -1508.6, 14.3822, 180.155, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mari_Zdizdiguri', 'None', 0, 0, 0, 0, 0, 0, 1100),
(65, 1695.38, -2125.83, 13.8101, 225.705, 1021.86, 1084.02, 1692.22, -2120.92, 13.5469, 256.148, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 127600, 1100),
(66, 588.68, -2090.47, 11.5265, 83.0589, 1322.55, 1083.87, 584.669, -2058.43, 9.11989, 356.235, 'The State', 900000, 9, 1, 0, 0, 2, 'Erling_Haaland', 'None', 0, 0, 0, 0, 0, 16100, 700),
(67, 2148.93, -1484.8, 26.6242, 225.705, 1021.86, 1084.02, 2135.17, -1476.02, 23.9538, 14.0778, 'The State', 2000000, 7, 1, 0, 0, 4, 'Vasil_Gogebashvili', 'Dodo_Baratashvili', 0, 0, 0, 0, 0, 164500, 1100),
(68, 2149.86, -1433.8, 26.0703, 234.138, 1063.9, 1084.21, 2135.32, -1431.98, 23.9729, 355.56, 'The State', 1000000, 6, 1, 0, 0, 3, 'Giorgi_Bucxrikidze', 'Giorgi_Miqautadze', 0, 0, 0, 0, 0, 100300, 900),
(69, 989.904, -828.601, 95.4686, 234.138, 1063.9, 1084.21, 978.675, -829.448, 95.8339, 26.9987, 'The State', 1000000, 6, 1, 0, 0, 3, 'Kvinikadze_Giorgi', 'Saba_Jalalishvili', 0, 0, 0, 0, 0, 0, 900),
(70, 984.698, -1829.77, 13.3306, 225.705, 1021.86, 1084.02, 985.072, -1840.21, 12.6131, 93.9952, 'The State', 2000000, 7, 1, 0, 0, 4, 'Zeki_Korleoni', 'None', 0, 0, 0, 0, 0, 0, 1100),
(71, 1440.13, -926.062, 39.6477, 225.705, 1021.86, 1084.02, 1450.12, -929.315, 37.0928, 175.237, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(72, 315.809, -1769.43, 4.62176, 225.705, 1021.86, 1084.02, 322.435, -1765.9, 4.60523, 172.027, 'The State', 2000000, 7, 1, 0, 0, 4, 'Keira_Cassa', 'Lombardo_Leads', 0, 0, 0, 0, 0, 1100, 1100),
(73, 870.537, -24.9787, 63.9751, 225.705, 1021.86, 1084.02, 2176.84, -1803.01, 13.3701, 300.412, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mamuka_Senpai', 'None', 0, 0, 0, 0, 0, 141900, 1100),
(74, -1942.14, 2379.46, 49.7031, 2308.8, -1212.84, 1049.02, -1941.03, 2392.89, 49.4922, 286.753, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 20400, 300),
(75, 1172.31, -1129.81, 23.8773, 225.705, 1021.86, 1084.02, 1155.23, -1125.04, 24.054, 170.725, 'The State', 2000000, 7, 1, 0, 0, 4, 'Charld_Stiller', 'None', 0, 0, 0, 0, 0, 68600, 1100),
(76, 513.973, -2089.26, 9.30966, 225.705, 1021.86, 1084.02, 160.434, -1924.86, 3.77344, 181.08, 'The State', 2000000, 7, 1, 0, 0, 4, 'Giga_Morfina', 'None', 0, 0, 0, 0, 0, 162900, 1100),
(77, -307.932, 1538.85, 75.5625, 225.705, 1021.86, 1084.02, -333.381, 1513.53, 75.3594, 339.659, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(78, 761.359, -1564.38, 13.838, 225.705, 1021.86, 1084.02, 765.45, -1569.79, 13.5469, 269.792, 'The State', 2000000, 7, 1, 0, 0, 4, 'George_Brauni', 'None', 0, 0, 0, 0, 0, 0, 1100),
(79, 2448.4, -11.0301, 27.6835, 225.705, 1021.86, 1084.02, 2433.41, -11.4468, 26.4844, 180.782, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(80, 2015.35, -1732.62, 14.2344, 225.705, 1021.86, 1084.02, 2014.62, -1737.83, 13.5469, 94.4711, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(81, -911.387, 2672.85, 42.3703, 225.705, 1021.86, 1084.02, -900.502, 2685.85, 42.3703, 41.4013, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 151100, 1100),
(82, 1496.6, -688.318, 506.234, 2308.8, -1212.84, 1049.02, 1489.9, -696.65, 94.75, 226.474, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(83, -2322.48, -1617.69, 485.19, 83.0589, 1322.55, 1083.87, -2311.04, -1635.14, 483.703, 217.825, 'Wiliam_Masson', 900000, 9, 1, 1, 0, 2, 'Tsuki_Capone', 'None', 0, 0, 0, 0, 0, 70700, 700),
(84, -801.592, -821.579, 149.778, 225.705, 1021.86, 1084.02, -786.778, -843.042, 148.883, 172.821, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 137500, 1100),
(85, 618.818, -2084.33, 12.018, 225.705, 1021.86, 1084.02, 1307.28, -1548.66, 13.5469, 347.8, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 50, 250, 300, 0, 0, 67100, 1100),
(86, 2513.37, -28.4035, 28.4416, 234.138, 1063.9, 1084.21, 2521.42, -22.6621, 27.1763, 356.749, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(87, 2509.52, 11.763, 28.4416, 225.705, 1021.86, 1084.02, 2503.74, 5.97977, 27.1695, 177.468, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(88, 1332.08, -633.359, 109.135, 225.705, 1021.86, 1084.02, 1351.7, -619.263, 109.133, 19.7067, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(89, 2488.37, 11.7623, 28.4416, 225.705, 1021.86, 1084.02, 2494.07, 6.17088, 27.1983, 181.506, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(90, 1329.16, -984.636, 33.8966, 83.0589, 1322.55, 1083.87, 1346.44, -982.393, 29.6935, 193.064, 'The State', 900000, 9, 1, 0, 0, 2, 'James_Glik', 'None', 0, 0, 0, 0, 0, 117261, 700),
(91, 1411.16, -920.869, 38.4219, 225.705, 1021.86, 1084.02, 1423.1, -917.61, 36.0469, 170.109, 'Jimsher_Ryvera', 2000000, 7, 1, 1, 0, 4, 'None', 'Jaba_Shainidze', 0, 0, 0, 0, 1, 106700, 1100),
(92, 736.757, -556.781, 18.0129, 234.138, 1063.9, 1084.21, 750.099, -552.168, 17.277, 357.754, 'The State', 1000000, 6, 1, 0, 0, 3, 'Sam_Crow', 'None', 0, 0, 0, 0, 0, 0, 900),
(93, 743.162, -509.319, 18.0129, 83.0589, 1322.55, 1083.87, 752.158, -497.561, 17.3281, 179.337, 'The State', 900000, 9, 1, 0, 0, 2, 'Guga_Wiklauri', 'Ninjaz_Kumyha', 0, 0, 0, 0, 0, 0, 700),
(94, -2721.36, -320.947, -109.31, 83.0589, 1322.55, 1083.87, -2733.4, -310.563, 7.1875, 314.388, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(95, 776.737, -503.483, 18.0129, 225.705, 1021.86, 1084.02, 763.332, -507.01, 17.3432, 182.585, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nika_Giorbelidze', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(96, 795.144, -506.148, 18.0129, 225.705, 1021.86, 1084.02, 787.543, -516.82, 16.4983, 177.347, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(97, 818.485, -509.319, 18.0129, 225.705, 1021.86, 1084.02, 828.04, -496.142, 17.3281, 178.851, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Matthew_Casston', 0, 0, 0, 0, 0, 0, 1100),
(98, 766.579, -556.784, 18.0129, 225.705, 1021.86, 1084.02, 772.216, -551.615, 17.2339, 359.529, 'The State', 2000000, 7, 1, 0, 0, 4, 'Rick_Sanchezzz', 'None', 0, 0, 0, 0, 0, 0, 1100),
(99, 745.673, -591.072, 18.0129, 225.705, 1021.86, 1084.02, 734.015, -581.14, 16.4504, 91.5091, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(100, 2567.92, 1579.19, 13.4062, 225.705, 1021.86, 1084.02, 2560.89, 1509.71, 10.6719, 46.5912, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 144100, 1100),
(101, 767.56, -570.412, 18.0133, 225.705, 1021.86, 1084.02, 781.202, -582.598, 16.3359, 281.527, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(102, 742.312, -495.646, 18.0129, 225.705, 1021.86, 1084.02, 742.566, -486.753, 17.3359, 225.02, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 162140, 1100),
(103, 796.095, -492.402, 18.0133, 234.138, 1063.9, 1084.21, 786.183, -489.238, 17.3439, 179.27, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'Mariam_Jikidzee', 0, 0, 0, 0, 0, 122200, 900),
(104, -2037.83, 178.146, 28.8359, 2308.8, -1212.84, 1049.02, -2031.13, 173.95, 28.8359, 1.85593, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(105, 1103.4, -1092.67, 28.4688, 225.705, 1021.86, 1084.02, 1090.57, -1090.31, 25.8784, 1.15657, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Lukson_Astarovski', 0, 0, 0, 0, 0, 159500, 1100),
(106, 2187, 1113.51, 12.6538, 225.705, 1021.86, 1084.02, 2175.04, 1125.12, 12.5541, 153.64, 'The State', 2000000, 7, 1, 0, 0, 4, 'Dondurma_Nayina', 'Nini_Tsintsadze', 0, 0, 0, 0, 0, 0, 1100),
(107, 697.28, -1627.05, 3.74917, 225.705, 1021.86, 1084.02, 705.914, -1627.19, 3.4375, 3.39396, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nata_Morningstar', 'None', 0, 0, 0, 0, 0, 0, 1100),
(108, 1310.09, -1366.99, 13.5147, 225.705, 1021.86, 1084.02, 1315.6, -1378.14, 13.7079, 176.689, 'The State', 2000000, 7, 1, 0, 0, 4, 'Teslov_Ernesto', 'Otis_Capone', 0, 0, 0, 0, 0, 159500, 1100),
(109, 1286.56, -1350, 13.5698, 225.705, 1021.86, 1084.02, 1262.61, -1348.29, 13.2043, 179.011, 'The State', 2000000, 7, 1, 0, 0, 4, 'Braian_Anderson', 'Danny_Brasco', 0, 0, 0, 0, 1, 106700, 1100),
(110, 1671.58, -1330.29, 17.4591, 225.705, 1021.86, 1084.02, 1664.07, -1310.59, 14.5198, 91.7726, 'The State', 2000000, 7, 1, 0, 0, 4, 'Isabella_Black', 'James_Wildman', 0, 0, 0, 0, 0, 75522, 1100),
(111, -1431.66, -955.906, 202.558, 225.705, 1021.86, 1084.02, -1432.88, -942.142, 201.094, 267.45, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 159500, 1100),
(112, 2039.62, 2766.54, 10.8265, 234.138, 1063.9, 1084.21, 2026.95, 2751.43, 10.8203, 241.865, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(113, 487.14, -1639.36, 23.7031, 225.705, 1021.86, 1084.02, 480.174, -1653.7, 23.4647, 196.037, 'The State', 2000000, 7, 1, 0, 0, 4, 'Saba_Lion', 'None', 0, 0, 0, 0, 0, 17600, 1100),
(114, 2551.22, 57.1816, 27.6756, 225.705, 1021.86, 1084.02, 2550.42, 71.9627, 26.4766, 88.7029, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(115, 2440.56, -1057.34, 54.7387, 225.705, 1021.86, 1084.02, 2431.66, -1053.16, 54.3438, 0.65938, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sandro_Porcxidze', 'None', 0, 0, 0, 0, 0, 0, 1100),
(116, 2549.23, 25.1435, 27.6756, 225.705, 1021.86, 1084.02, 2552, 11.7704, 27.0244, 24.7752, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(117, 331.264, -40.2378, 2.22552, 234.138, 1063.9, 1084.21, 1063.51, -331.059, 73.9922, 233.765, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 900, 900),
(118, 2536.15, 128.982, 27.6835, 2308.8, -1212.84, 1049.02, 2528.4, 129.583, 26.4844, 183.242, 'The State', 500000, 6, 1, 0, 0, 0, 'Javakhishvili_Gigi', 'None', 0, 0, 0, 0, 0, 31100, 300),
(119, 2512.96, -1027.18, 70.0859, 225.705, 1021.86, 1084.02, 2505.64, -1024.18, 70.0859, 175.71, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(120, 1426.6, -968.486, 37.428, 225.705, 1021.86, 1084.02, 1422.66, -960.002, 36.3713, 258.519, 'The State', 2000000, 7, 1, 0, 0, 4, 'Malxaz_Metonidze', 'Kaizer_Soza', 54, 300, 300, 0, 0, 184600, 1100),
(121, 2480.63, 126.995, 27.6756, 225.705, 1021.86, 1084.02, 2494.28, 127.904, 27.0054, 183.857, 'The State', 2000000, 7, 1, 0, 0, 4, 'Giorgi_Laghaa', 'None', 0, 0, 0, 0, 0, 0, 1100),
(122, -1432.15, -947.519, 202.558, 225.705, 1021.86, 1084.02, -1415.32, -956.504, 201.094, 89.9132, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 128500, 1100),
(123, 2462.75, 134.78, 27.6756, 225.705, 1021.86, 1084.02, 2469.47, 129.45, 26.4766, 173.285, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(124, 852.261, -1423.16, 14.1425, 225.705, 1021.86, 1084.02, 844.606, -1419.95, 12.7701, 358.086, 'The State', 2000000, 7, 1, 0, 0, 4, 'Gelasha', 'Qviqs_Costello', 0, 0, 0, 0, 0, 139700, 1100),
(125, 1564.99, -1274.67, 17.4057, 225.705, 1021.86, 1084.02, 1570.16, -1287.11, 17.4524, 218.599, 'The State', 2000000, 7, 1, 0, 0, 4, 'Temo_Mindiashvili', 'Elena_Hudson', 0, 0, 0, 0, 0, 1100, 1100),
(126, 1330.02, -990.874, 33.8966, 225.705, 1021.86, 1084.02, 1350.18, -982.008, 30.132, 352.921, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nick_Arlovski', 'Revaz_Morgen', 0, 0, 0, 0, 0, 123600, 1100),
(127, 252.689, -92.3535, 3.53539, 225.705, 1021.86, 1084.02, 248.138, -86.5798, 2.43061, 92.7822, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 94040, 1100),
(128, 1566.49, 23.3716, 24.1641, 234.138, 1063.9, 1084.21, 1559.88, 25.6985, 24.1641, 121.15, 'The State', 1000000, 6, 1, 0, 0, 3, 'Anro_Rexviashvili', 'Guka_Gogiashvili', 0, 0, 0, 0, 0, 133800, 900),
(129, 1422.13, -885.777, 50.6699, 225.705, 1021.86, 1084.02, 1432.17, -877.814, 51.5239, 75.327, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Luke_Nelson', 0, 0, 0, 0, 0, 1100, 1100),
(130, 211.678, -1239.04, 78.3493, 225.705, 1021.86, 1084.02, 833.929, -2056.1, 12.8672, 281.584, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nika_Mukvani', 'None', 0, 0, 0, 0, 0, 134600, 1100),
(131, -2632.49, -164.914, 4.32812, 83.0589, 1322.55, 1083.87, -2656.45, -164.507, 4.00619, 188.589, 'The State', 900000, 9, 1, 0, 0, 2, 'Mamasha_Ardizzone', 'None', 0, 0, 0, 0, 0, 0, 700),
(132, -90.9547, -1557.95, 3.43307, 225.705, 1021.86, 1084.02, -67.1328, -1574, 2.61719, 13.4835, 'The State', 2000000, 7, 1, 0, 0, 4, 'Babak_Anderson', 'None', 0, 0, 0, 0, 0, 92300, 1100),
(133, 2013.56, -1656.4, 14.1363, 225.705, 1021.86, 1084.02, 2009.23, -1659.69, 13.5547, 20.8312, 'The State', 2000000, 7, 1, 0, 0, 4, 'Dato_Namikadze', 'None', 0, 0, 0, 0, 0, 61500, 1100),
(134, -64.3649, -2143.37, 1154.92, 83.0589, 1322.55, 1083.87, 144.054, -1949.38, 3.77344, 331.375, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(135, 160.049, -2452.43, 637.618, 83.0589, 1322.55, 1083.87, 1955.15, -1039.62, 24.2157, 232.795, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(136, 980.428, -677.298, 121.976, 225.705, 1021.86, 1084.02, 1003.97, -661.597, 121.148, 302.82, 'The State', 2000000, 7, 1, 0, 0, 4, 'Matt_Stonie', 'None', 0, 0, 0, 0, 0, 178500, 1100),
(137, 768.233, -503.483, 18.0129, 225.705, 1021.86, 1084.02, 762.38, -505.63, 17.3432, 178.698, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(138, 1535.03, -800.458, 72.8495, 225.705, 1021.86, 1084.02, 1526.65, -814.558, 71.5022, 112.834, 'Vipstar_Geo', 2000000, 7, 1, 1, 0, 4, 'Ucha_Bolqvadze', 'Beqa_Golqvadze', 0, 0, 0, 0, 0, 52800, 1100),
(139, 993.707, -1058.86, 33.6995, 83.0589, 1322.55, 1083.87, 1004.39, -1054.63, 30.9045, 359.597, 'The State', 900000, 9, 1, 0, 0, 2, 'Pikula_Pikulichi', 'None', 0, 0, 0, 0, 0, 700, 700),
(140, -683.932, 939.6, 13.6328, 83.0589, 1322.55, 1083.87, -703.909, 951.896, 12.3987, 61.8963, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 1, 97500, 700),
(141, 1442.66, -628.835, 95.7186, 83.0589, 1322.55, 1083.87, 1460.04, -635.975, 95.8825, 185.708, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 105700, 700),
(142, 745.197, -556.772, 18.0129, 225.705, 1021.86, 1084.02, 750.382, -552.345, 17.2908, 356.563, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Edward_Rodriguez', 0, 0, 0, 0, 0, 0, 1100),
(143, 252.708, -121.402, 3.53539, 234.138, 1063.9, 1084.21, 1045.29, -310.236, 73.9931, 185.189, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 900, 900),
(144, 977.494, -771.718, 112.203, 225.705, 1021.86, 1084.02, 975.709, -759.133, 112.203, 91.4115, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 130, 0, 0, 0, 0, 1100),
(145, 1094.99, -661.067, 113.648, 225.705, 1021.86, 1084.02, 1093.73, -629.611, 110.891, 18.7568, 'The State', 2000000, 7, 1, 0, 0, 4, 'Luka_Japaridze', 'None', 0, 0, 0, 0, 0, 184800, 1100),
(146, 936.426, -1612.72, 14.9375, 225.705, 1021.86, 1084.02, 951.022, -1634.86, 13.5483, 358.069, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 104800, 1100),
(147, 824.007, -1424.2, 14.4988, 2270.05, -1210.46, 1047.56, 824.136, -1400.57, 13.46, 267.262, 'The State', 700000, 10, 1, 0, 0, 1, 'Giorgi_Kevlishvili', 'None', 0, 0, 0, 0, 0, 72500, 500),
(148, 2269.53, 6.03869, 28.1535, 225.705, 1021.86, 1084.02, 2279.22, -1.73369, 27.3813, 168.117, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(149, 360.551, -1551.91, 32.9338, 225.705, 1021.86, 1084.02, 351.956, -1546.22, 33.2976, 337.128, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(150, 988.888, -1752.84, 13.5022, 83.0589, 1322.55, 1083.87, 981.74, -1759.53, 13.7545, 178.902, 'The State', 900000, 9, 1, 0, 0, 2, 'Mate_Jojua', 'None', 0, 0, 0, 0, 0, 700, 700),
(151, 510.734, -2070.75, 9.79275, 225.705, 1021.86, 1084.02, 527.686, -2069.23, 9.18436, 277.331, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Mate_Gvelesianii', 10, 0, 0, 0, 0, 0, 1100),
(152, -2521.01, -624.726, 132.784, 225.705, 1021.86, 1084.02, -2516.97, -601.378, 132.562, 180.805, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 75900, 1100),
(153, 1112.64, -742.242, 100.133, 225.705, 1021.86, 1084.02, 1102.07, -732.636, 101.597, 94.7527, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Paul_Mendezz', 0, 0, 0, 0, 0, 0, 1100),
(154, -2168.77, 1081.44, 80.0131, 83.0589, 1322.55, 1083.87, -2159.69, 1089.14, 79.8516, 102.862, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 700, 700),
(155, 1546.47, 32.2625, 24.1406, 234.138, 1063.9, 1084.21, 1558.77, 14.0027, 24.1641, 15.8995, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'Vaxtang_Rasala', 0, 0, 0, 0, 0, 71700, 900),
(156, 1017.15, -763.363, 112.563, 225.705, 1021.86, 1084.02, 1025.03, -782.385, 102.931, 216.078, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nodiko_Kekelidze', 'None', 0, 0, 0, 0, 0, 99800, 1100),
(157, 398.158, -1271.37, 50.0198, 225.705, 1021.86, 1084.02, 405.402, -1262.13, 50.9092, 18.9853, 'The State', 2000000, 7, 1, 0, 0, 4, 'Xurcilava_Dato', 'Valdes_Kevin', 0, 0, 0, 0, 0, 79900, 1100),
(158, 1535.66, -885.177, 57.6575, 225.705, 1021.86, 1084.02, 1522.45, -875.028, 61.7344, 134.156, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Nikola_Jokic', 0, 0, 0, 0, 1, 8800, 1100),
(159, 1297.63, -1423.88, 14.9531, 225.705, 1021.86, 1084.02, 1613.13, -2317.81, 13.3844, 359.036, 'The State', 2000000, 7, 1, 0, 0, 4, 'Misho_Galskii', 'Misho_Galskii', 0, 0, 0, 0, 1, 53900, 1100),
(160, 827.656, -858.037, 70.3308, 225.705, 1021.86, 1084.02, 832.482, -859.077, 69.9219, 200.105, 'The State', 2000000, 7, 1, 0, 0, 4, 'Ilia_Kochiashvili', 'Roma_Markoi', 0, 0, 0, 0, 0, 158213, 1100),
(161, 201.467, -120.235, 1.55143, 225.705, 1021.86, 1084.02, 944.111, -841.567, 94.1253, 26.8783, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nick_Tollers', 'None', 0, 0, 0, 0, 0, 0, 1100),
(162, 923.874, -853.322, 93.4565, 225.705, 1021.86, 1084.02, 931.359, -856.64, 93.4789, 30.2414, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Luik_Wilsona', 0, 0, 0, 0, 0, 100700, 1100),
(163, 305.311, -1770.78, 4.53823, 83.0589, 1322.55, 1083.87, 322.341, -1766.64, 4.62455, 180.353, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 117600, 700),
(164, 724.835, -999.444, 52.7344, 234.138, 1063.9, 1084.21, 727.787, -996.606, 52.7344, 272.87, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'Deathise_Tripplex', 0, 0, 0, 0, 0, 0, 900),
(165, 700.433, -1060.02, 49.4217, 225.705, 1021.86, 1084.02, 687.513, -1073.46, 49.4923, 59.3182, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 178900, 1100),
(166, 1286.73, -1308.38, 13.5499, 225.705, 1021.86, 1084.02, 1281.02, -1305.08, 13.3728, 175.727, 'The State', 2000000, 7, 1, 0, 0, 4, 'Gio_Kencho', 'Nick_Manson', 0, 0, 0, 0, 0, 0, 1100),
(167, 312.721, -121.382, 3.53539, 225.705, 1021.86, 1084.02, 1058.81, -326.145, 73.9851, 78.3796, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 49400, 1100),
(168, 558.606, -1161.18, 54.4297, 225.705, 1021.86, 1084.02, 548.316, -1153.66, 54.1389, 131.749, 'The State', 2000000, 7, 1, 0, 0, 4, 'Astra_Kapono', 'None', 0, 0, 0, 0, 0, 0, 1100),
(169, 312.721, -92.3476, 3.53539, 83.0589, 1322.55, 1083.87, 1056.07, -320.32, 73.9851, 355.665, 'The State', 900000, 9, 1, 0, 0, 2, 'Saba_Sanikidze', 'None', 0, 0, 0, 0, 0, 700, 700),
(170, -2625.67, -191.057, 7.20312, 2270.05, -1210.46, 1047.56, -2615.96, -194.884, 4.33594, 275.783, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'Trashx_Matterazzo', 0, 0, 0, 0, 0, 0, 500),
(171, 612.334, -1085.75, 58.8267, 225.705, 1021.86, 1084.02, 617.8, -1101.96, 46.7656, 209.653, 'The State', 2000000, 7, 1, 0, 0, 4, 'Niko_Taylor', 'Sebastian_Clowton', 0, 0, 0, 0, 0, 0, 1100),
(172, 1299.31, -795.493, 996.991, 2308.8, -1212.84, 1049.02, 281.556, -1255.77, 73.8831, 305.489, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(173, 2014.22, 775.194, 11.4609, 225.705, 1021.86, 1084.02, 2008.22, 769.082, 11.3555, 182.431, 'The State', 2000000, 7, 1, 0, 0, 4, 'Francesco_Bacaro', 'None', 0, 0, 0, 0, 0, 151100, 1100),
(174, 251.47, -1220.19, 76.1024, 225.705, 1021.86, 1084.02, 1561.02, -1693.93, 5.89062, 160.298, 'The State', 2000000, 7, 1, 0, 0, 4, 'Foxy_Costello', 'Adolf_Hitler', 0, 300, 0, 300, 0, 0, 1100),
(175, 1685.02, -2098.35, 13.8343, 225.705, 1021.86, 1084.02, 1673.39, -2111.76, 13.5469, 245.756, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Aberama_Gold', 0, 0, 0, 0, 1, 141100, 1100),
(176, 2459.31, -1691.12, 13.5475, 225.705, 1021.86, 1084.02, 2453.78, -1683.54, 13.5086, 40.171, 'The State', 2000000, 7, 1, 0, 0, 4, 'Roy_Wallker', 'Azzazel_Primeiro', 0, 0, 0, 0, 0, 145300, 1100),
(177, 1727.22, -1636.09, 20.2169, 83.0589, 1322.55, 1083.87, 1720.07, -1607.69, 13.5469, 354.733, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 34300, 700),
(178, 355.146, -1281.14, 53.7036, 225.705, 1021.86, 1084.02, 352.957, -1274.2, 53.7153, 295.443, 'The State', 2000000, 7, 1, 0, 0, 4, 'Lasha_Topuria', 'None', 0, 0, 0, 0, 0, 146000, 1100),
(179, 470.721, -1163.57, 67.2178, 234.138, 1063.9, 1084.21, 471.785, -1177.67, 63.6577, 290.053, 'The State', 1000000, 6, 1, 0, 0, 3, 'Nick_Kapono', 'Shot_Bitches', 0, 0, 0, 0, 1, 900, 900),
(180, 1930.85, 1345.2, 9.96875, 225.705, 1021.86, 1084.02, 1942.27, 1334.98, 9.25781, 179.532, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(181, -22.0526, -2529.17, 36.6484, 225.705, 1021.86, 1084.02, -22.5516, -2524.55, 36.6387, 30.4072, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(182, -17.5064, -2526.76, 36.6555, 225.705, 1021.86, 1084.02, -19.4502, -2523.04, 37.7937, 27.1453, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sebastian_Roberson', 'Alonzo_Fallen', 0, 0, 0, 0, 0, 0, 1100),
(183, -13.3188, -2524.2, 36.6555, 225.705, 1021.86, 1084.02, -16.7208, -2520.99, 36.6555, 28.6509, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(184, -8.82222, -2522.09, 36.6555, 234.138, 1063.9, 1084.21, -13.6732, -2519.45, 36.6555, 30.5055, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(185, -8.21666, -2510.47, 36.6555, 225.705, 1021.86, 1084.02, -11.2911, -2512, 37.9039, 121.694, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 3600, 1100),
(186, 280.752, -1767.25, 4.55113, 234.138, 1063.9, 1084.21, 273.232, -1775.34, 4.24397, 263.275, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 150900, 900),
(187, -13.1598, -2502.05, 36.6555, 234.138, 1063.9, 1084.21, -19.8248, -2505.69, 36.6555, 127.61, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(188, -16.2418, -2497.71, 36.6484, 234.138, 1063.9, 1084.21, -17.8783, -2500.49, 36.6484, 125.269, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(189, 1045.23, -642.551, 120.117, 225.705, 1021.86, 1084.02, 1035.2, -641.096, 120.117, 311.139, 'The State', 2000000, 7, 1, 0, 0, 4, 'Luka_Kamladze', 'Hakeem_Biyombo', 0, 0, 0, 0, 0, 163500, 1100),
(190, 1564.63, -1897.91, 13.5609, 225.705, 1021.86, 1084.02, 1565.71, -1878.38, 13.5469, 327.871, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 122500, 1100),
(191, 1093.93, -806.954, 107.419, 83.0589, 1322.55, 1083.87, 1095.3, -782.292, 107.137, 47.5218, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(192, 2307.23, -1785.73, 13.5571, 234.138, 1063.9, 1084.21, 2293.61, -1786.72, 13.5469, 358.77, 'The State', 1000000, 6, 1, 0, 0, 3, 'Jumber_Licheli', 'Brelo_Adams', 0, 0, 0, 0, 0, 132300, 900),
(193, 1658.03, -1394.45, 13.5469, 225.705, 1021.86, 1084.02, 1651.57, -1420.23, 13.5469, 181.435, 'The State', 2000000, 7, 1, 0, 0, 4, 'Michael_Desert', 'Giorgi_Bulia', 0, 0, 0, 0, 0, 36300, 1100),
(194, 376.264, -2055.9, 8.01562, 225.705, 1021.86, 1084.02, 377.583, -2053.95, 8.01562, 221.095, 'The State', 2000000, 7, 1, 0, 0, 4, 'Temuka_Gelashvili', 'Luka_Simonashvili', 0, 0, 0, 0, 0, 184600, 1100),
(195, 2486.46, -1644.53, 14.0772, 234.138, 1063.9, 1084.21, 2479.3, -1656.23, 14.4642, 91.2495, 'The State', 1000000, 6, 1, 0, 0, 3, 'Spoky_Gaviria', 'None', 26, 0, 0, 0, 0, 151200, 900),
(196, 865.117, -1634.3, 14.9297, 225.705, 1021.86, 1084.02, 859.869, -1648.64, 13.5484, 190.97, 'The State', 2000000, 7, 1, 0, 0, 4, 'Jack_Frost', 'Jgenti_Demetre', 0, 0, 0, 0, 0, 181100, 1100),
(197, 344.626, -71.1878, 2.43081, 225.705, 1021.86, 1084.02, 1056.73, -316.494, 73.9922, 141.82, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(198, -2447.37, 821.619, 35.1797, 2270.05, -1210.46, 1047.56, -2448.53, 814.876, 35.1797, 95.7812, 'The State', 700000, 10, 1, 0, 0, 1, 'Cisco_Ramonn', 'None', 0, 0, 0, 0, 0, 0, 500),
(199, -2402.42, 829.309, 36.8767, 83.0589, 1322.55, 1083.87, -2392.99, 827.937, 36.4744, 180.429, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(200, 965.116, -1612.78, 14.9441, 83.0589, 1322.55, 1083.87, 963.446, -1618.94, 13.5488, 169.942, 'The State', 900000, 9, 1, 0, 0, 2, 'Daci_Tamarasvili', 'Kaen_Monstero', 0, 0, 0, 0, 0, 700, 700),
(201, 1527.8, -772.569, 80.5781, 225.705, 1021.86, 1084.02, 1515.86, -765.767, 80.0277, 138.624, 'Guga_Gruzinski', 2000000, 7, 1, 1, 0, 4, 'None', 'Martin_Andersen', 0, 0, 0, 0, 1, 184100, 1100),
(202, 207.091, -1768.88, 4.37034, 225.705, 1021.86, 1084.02, 208.917, -1774.62, 5.0699, 270.365, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nodo_Babaiani', 'None', 0, 0, 0, 0, 0, 7700, 1100),
(203, -8.87844, -2507.69, 36.6555, 225.705, 1021.86, 1084.02, -13.0888, -2509.41, 36.6555, 121.079, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(204, 750.586, -1806.52, 13.0234, 225.705, 1021.86, 1084.02, 735.041, -1810.92, 12.5184, 350.273, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sonny_Lospencio', 'Al_Capone', 0, 0, 0, 0, 0, 182100, 1100),
(205, 295.117, -54.5434, 2.77721, 225.705, 1021.86, 1084.02, 1050.71, -323.135, 73.9851, 78.3581, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(206, 1843.99, 718.715, 11.4683, 225.705, 1021.86, 1084.02, 1850.71, 725.986, 11.3139, 271.57, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tabatadze_Saba', 'None', 0, 0, 0, 0, 0, 0, 1100),
(207, 1845.44, 741.353, 11.4609, 234.138, 1063.9, 1084.21, 1859.22, 733.72, 10.8203, 357.038, 'Falcon_Montana', 1000000, 6, 1, 1, 0, 3, 'None', 'Sabba_Boyovelii', 0, 0, 0, 0, 0, 90900, 900),
(208, -2471.82, 895.234, 63.1684, 225.705, 1021.86, 1084.02, -2464.69, 897.718, 62.9655, 359.439, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(209, -1005.28, 1848.29, 780.666, 83.0589, 1322.55, 1083.87, -2547.87, 913.964, 64.9844, 176.794, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(210, 1863.78, -1597.28, 14.3062, 83.0589, 1322.55, 1083.87, 1860.79, -1606.69, 13.5391, 80.6165, 'The State', 900000, 9, 1, 0, 0, 2, 'Nodo_Chacho', 'None', 0, 0, 0, 0, 0, 68600, 700),
(211, 1567.94, -1898.01, 13.5609, 225.705, 1021.86, 1084.02, 1567.16, -1891.68, 13.5593, 340.873, 'The State', 2000000, 7, 1, 0, 0, 4, 'Davit_Burnadze', 'Busy_Nightrider', 0, 0, 0, 0, 0, 57700, 1100),
(212, 771.127, -1510.69, 13.5469, 225.705, 1021.86, 1084.02, 781.663, -1509.28, 13.3828, 342.072, 'The State', 2000000, 7, 1, 0, 0, 4, 'Ninuci_Shonia', 'Luka_Pirtskhelava', 0, 0, 0, 0, 0, 110000, 1100),
(213, 782.798, -1464.39, 13.5469, 225.705, 1021.86, 1084.02, 790.671, -1459.95, 13.5547, 136.332, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mark_Morningstar', 'Don_Williams', 0, 0, 0, 0, 0, 6100, 1100),
(214, 1396.92, -1569.9, 14.2683, 225.705, 1021.86, 1084.02, 1396.72, -1582.8, 13.5469, 80.0688, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 96800, 1100),
(215, -1005.94, 1846.86, 788.778, 83.0589, 1322.55, 1083.87, 1403.76, -1597.8, 13.5469, 261.842, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(216, 849.596, -1519.94, 14.3482, 225.705, 1021.86, 1084.02, 852.383, -1527.95, 12.959, 261.024, 'The State', 2000000, 7, 1, 0, 0, 4, 'Lukit_Milner', 'Amiko_Durglishvili', 0, 0, 0, 0, 0, 0, 1100),
(217, 399.841, 2539.6, 16.6796, 225.705, 1021.86, 1084.02, 399.605, 2526.5, 16.5141, 244.726, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(218, 1909.71, -1597.72, 14.3062, 225.705, 1021.86, 1084.02, 1916.49, -1608.48, 13.3828, 91.2297, 'The State', 2000000, 7, 1, 0, 0, 4, 'Calvin_Clain', 'Bjorn_Ironside', 0, 0, 0, 0, 0, 0, 1100),
(219, 1274.18, 2522.49, 10.8203, 225.705, 1021.86, 1084.02, 1283.61, 2526.33, 10.8203, 177.115, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(220, 1316.47, 2524.44, 10.8203, 234.138, 1063.9, 1084.21, 1304.73, 2528.83, 10.8264, 83.664, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 900, 900),
(221, 295.289, -1764.12, 4.86897, 225.705, 1021.86, 1084.02, 294.929, -1778.23, 4.39976, 180.638, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Jake_Jakson', 0, 0, 0, 0, 0, 0, 1100),
(222, 1285.26, -1090.16, 28.2578, 225.705, 1021.86, 1084.02, 1278.81, -1099.54, 26.0216, 88.3388, 'The State', 2000000, 7, 1, 0, 0, 4, 'Zuka_Nakasha', 'Scott_Maccolii', 0, 0, 0, 0, 0, 75900, 1100),
(223, 1285.26, -1067.3, 31.6789, 225.705, 1021.86, 1084.02, 1282.46, -1076.48, 28.8726, 86.5645, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nika_Kashakashvili', 'None', 0, 0, 0, 0, 0, 121700, 1100),
(224, 1359.34, -339.612, 1474.17, 2308.8, -1212.84, 1049.02, 1368.51, -1089.51, 24.5795, 169.235, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(225, 1377.81, -1753.14, 14.1406, 225.705, 1021.86, 1084.02, 1385.57, -1754.98, 13.3828, 176.79, 'Lazer_Masson', 2000000, 7, 1, 1, 0, 4, 'Nika_Boom', 'Ricky_Venddeta', 0, 0, 0, 0, 1, 106700, 1100),
(226, 2751.5, -1914.05, 13.5469, 225.705, 1021.86, 1084.02, 2763.07, -1906.21, 11.6888, 183.795, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(227, 1242.26, -1099.42, 27.9766, 225.705, 1021.86, 1084.02, 1247.17, -1107.71, 25.495, 268.273, 'The State', 2000000, 7, 1, 0, 0, 4, 'Don_Impulse', 'None', 0, 0, 0, 0, 0, 148100, 1100),
(228, 1359.55, 2565.43, 10.8265, 234.138, 1063.9, 1084.21, 1365.2, 2575.92, 10.8203, 359.729, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(229, 1362.87, 2525.6, 10.8203, 234.138, 1063.9, 1084.21, 1365.17, 2520.26, 10.8203, 271.323, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(230, -798.726, 2263.61, 58.847, 83.0589, 1322.55, 1083.87, -802.535, 2260.88, 58.6757, 171.039, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(231, 2162.71, -1815.23, 13.5469, 234.138, 1063.9, 1084.21, 2183.99, -1804.59, 13.3702, 10.5839, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'Cacia_Kenddy', 0, 0, 0, 0, 0, 144900, 900),
(232, 2155.79, -1815.23, 13.5469, 2270.05, -1210.46, 1047.56, 2158.41, -1805.64, 13.3815, 2.17142, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'Nikusha_Yala', 0, 0, 0, 0, 0, 79700, 500),
(233, 2257.04, -1643.94, 15.8082, 225.705, 1021.86, 1084.02, 2255.73, -1653.22, 15.4761, 83.5114, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Jengiz_Montana', 0, 0, 0, 0, 0, 0, 1100),
(234, 1564.63, 2776.52, 10.8203, 225.705, 1021.86, 1084.02, 1557.75, 2767.23, 10.8274, 91.3094, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 154600, 1100),
(235, 2326.88, -1681.89, 14.9297, 225.705, 1021.86, 1084.02, 2335.3, -1676.66, 13.5441, 177.108, 'The State', 2000000, 7, 1, 0, 0, 4, 'Dato_Gambarashvilii', 'None', 0, 0, 0, 0, 0, 162300, 1100),
(236, 615.556, -2041.45, 11.5142, 225.705, 1021.86, 1084.02, 602.982, -2020.58, 3.05469, 2.62823, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 159700, 1100),
(237, 1583.03, -1274.89, 17.5687, 225.705, 1021.86, 1084.02, 1581.49, -1280.65, 17.5589, 181.276, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 42800, 1100),
(238, 1704.11, -1578.71, 13.8879, 225.705, 1021.86, 1084.02, 1710.97, -1586.33, 13.5399, 79.4906, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nikusha_Abuladze', 'Gio_Alcantara', 0, 0, 0, 0, 0, 0, 1100),
(239, 1622.81, 2845.85, 10.8265, 225.705, 1021.86, 1084.02, 1615.86, 2834.15, 10.8203, 179.901, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Flame_Player', 0, 0, 0, 0, 0, 1100, 1100),
(240, -311.293, 1303.71, 53.6643, 225.705, 1021.86, 1084.02, -290.54, 1308.26, 54.0814, 80.8274, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(241, 1326.26, -1090.56, 27.9766, 225.705, 1021.86, 1084.02, 1329.84, -1100.36, 24.8608, 238.86, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(242, 1084.85, -1158.44, 23.8281, 225.705, 1021.86, 1084.02, 1081.21, -1152.92, 23.6562, 273.589, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 95600, 1100),
(243, 821.123, -1101.77, 24.1712, 225.705, 1021.86, 1084.02, 831.986, -1104.33, 24.304, 270.039, 'The State', 2000000, 7, 1, 0, 0, 4, 'Ezey_Rapper', 'None', 0, 0, 0, 0, 0, 106700, 1100),
(244, 1637.71, 2801.58, 10.8203, 2270.05, -1210.46, 1047.56, 1628.92, 2816.67, 10.8203, 244.029, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 1, 60500, 500),
(245, 1618.43, 2800.8, 10.8203, 234.138, 1063.9, 1084.21, 1612.6, 2811.73, 10.8203, 357.687, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 84700, 900),
(246, 1325.95, -1067.87, 31.5547, 83.0589, 1322.55, 1083.87, 1332.07, -1059.49, 28.4032, 273.754, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'Teres_Night', 0, 0, 0, 0, 0, 15400, 700),
(247, 2326.73, -1716.7, 14.2379, 225.705, 1021.86, 1084.02, 2319.22, -1717.73, 13.5469, 184.826, 'The State', 2000000, 7, 1, 0, 0, 4, 'Giorgi_Samanishvili', 'None', 0, 0, 0, 0, 0, 0, 1100),
(248, -329.943, 1172.66, 20.9399, 225.705, 1021.86, 1084.02, -361.417, 1198.54, 19.7422, 181.746, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(249, 2016.54, -1641.7, 14.1129, 2308.8, -1212.84, 1049.02, 2006.73, -1642.1, 13.5469, 164.741, 'Luffy_Zoroshvili', 500000, 6, 1, 1, 0, 0, 'Max_Kalashnikov', 'None', 0, 0, 0, 0, 0, 7500, 300),
(250, 2244.57, -1637.66, 16.2379, 83.0589, 1322.55, 1083.87, 2236.73, -1637.61, 16.9402, 161.76, 'The State', 900000, 9, 1, 0, 0, 2, 'Wiko_Montana', 'Wiko_Berlinov', 0, 0, 0, 0, 0, 100700, 700),
(251, 2129.63, -1361.69, 26.1363, 234.138, 1063.9, 1084.21, 2137.33, -1366.48, 24.9969, 183.347, 'The State', 1000000, 6, 1, 0, 0, 3, 'Giorgi_Javashvili', 'Luy_Mxargdzeli', 0, 0, 0, 0, 0, 67200, 900),
(252, -1006.52, 1845.6, 799.878, 2308.8, -1212.84, 1049.02, 1525.58, -2445.4, 13.5547, 186.831, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(253, 1735.68, 2691.28, 10.8203, 225.705, 1021.86, 1084.02, 1741.21, 2722.68, 10.8203, 5.65, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nero_Redsuns', 'None', 0, 0, 0, 0, 0, 35200, 1100),
(254, 1929.52, 2774.33, 10.8203, 225.705, 1021.86, 1084.02, 1918.26, 2767.7, 10.8265, 89.8453, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(255, 2007.06, 2910.17, 47.8231, 225.705, 1021.86, 1084.02, 1997.76, 2905.86, 45.5939, 178.626, 'The State', 2000000, 7, 1, 0, 0, 4, 'Wiliam_Kobra', 'None', 0, 0, 0, 0, 0, 0, 1100),
(256, 2126.65, -1320.86, 26.624, 225.705, 1021.86, 1084.02, 2135.91, -1317.46, 24.7143, 2.29431, 'The State', 2000000, 7, 1, 0, 0, 4, 'Jame_Jameson', 'Sonny_Lospenncio', 0, 0, 0, 0, 1, 159500, 1100),
(257, 1973.8, -1654.83, 15.9688, 83.0589, 1322.55, 1083.87, 1962.95, -1657.26, 15.9688, 272.377, 'The State', 900000, 9, 1, 0, 0, 2, 'Gio_Gureshize', 'George_Master', 0, 0, 0, 0, 0, 67800, 700),
(258, 2066.25, 2722.31, 10.8203, 2308.8, -1212.84, 1049.02, 2059.03, 2732.33, 10.8203, 3.23573, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(259, 2067.56, -1643.69, 14.1363, 234.138, 1063.9, 1084.21, 2073.33, -1643.94, 13.5469, 288.483, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 76100, 900),
(260, 510.373, -2038.77, 9.79275, 225.705, 1021.86, 1084.02, 549.443, -2040.36, 5.16482, 226.163, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nika_Jachvadze', 'None', 0, 0, 0, 0, 0, 0, 1100),
(261, 926.732, -859.312, 93.4565, 234.138, 1063.9, 1084.21, 933.018, -855.033, 93.4946, 29.7489, 'The State', 1000000, 6, 1, 0, 0, 3, 'Gaba_Leva', 'Gaba_Lazare', 0, 0, 0, 0, 0, 0, 900),
(262, 1980.38, -1718.91, 17.0303, 225.705, 1021.86, 1084.02, 1968.04, -1732.54, 15.9612, 281.951, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nick_Mayson', 'Gio_Gelashvili', 0, 0, 0, 0, 0, 159500, 1100),
(263, 1950.81, 2721.95, 10.8203, 225.705, 1021.86, 1084.02, 1941.61, 2729.28, 10.8274, 269.656, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(264, 2282.35, -1641.22, 15.8898, 225.705, 1021.86, 1084.02, 2271.1, -1641.67, 15.3593, 2.30944, 'The State', 2000000, 7, 1, 0, 0, 4, 'Erekle_Saladze', 'None', 0, 0, 0, 0, 0, 0, 1100),
(265, 1921.71, 2664.22, 10.8203, 234.138, 1063.9, 1084.21, 1929.18, 2655.19, 10.8203, 4.27709, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(266, 1950.56, 2664.5, 11.2989, 2270.05, -1210.46, 1047.56, 1959.77, 2653.56, 10.8203, 181.706, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 39500, 500),
(267, 1377.71, -1794.28, 13.4956, 234.138, 1063.9, 1084.21, 1547.16, -1680.26, 13.5599, 270.151, 'Duzo_Williams', 1000000, 6, 1, 1, 0, 3, 'None', 'None', 0, 0, 0, 0, 1, 44100, 900),
(268, 1377.71, -1797.91, 13.4955, 225.705, 1021.86, 1084.02, 1371.93, -1005.06, 27.484, 173.598, 'The State', 2000000, 7, 1, 0, 0, 4, 'Dachi_Suxashvili', 'Kevin_Winstonn', 0, 0, 0, 0, 0, 145900, 1100),
(269, 618.549, -2060.01, 12.001, 225.705, 1021.86, 1084.02, 598.733, -2019.94, 2.88474, 4.13441, 'The State', 2000000, 7, 1, 0, 0, 4, 'Luka_Kantela', 'Charly_Anderson', 0, 0, 0, 0, 0, 129900, 1100),
(270, -1051.23, 1550.1, 33.4376, 225.705, 1021.86, 1084.02, -1041.01, 1546.13, 32.9973, 129.294, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 74400, 1100),
(271, 2673.18, -2020.14, 14.1682, 234.138, 1063.9, 1084.21, 2675.89, -2005.77, 13.3828, 272.168, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 122100, 900),
(272, 2368.24, 655.065, 11.4609, 225.705, 1021.86, 1084.02, 2363.3, 646.967, 11.2235, 176.164, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(273, 1095.18, -647.18, 113.648, 83.0589, 1322.55, 1083.87, 1091.26, -640.55, 112.938, 267.826, 'The State', 900000, 9, 1, 0, 0, 2, 'Ana_Princes', 'None', 0, 0, 0, 0, 0, 110430, 700);
INSERT INTO `house` (`hID`, `hEntrancex`, `hEntrancey`, `hEntrancez`, `hExitx`, `hExity`, `hExitz`, `hCarx`, `hCary`, `hCarz`, `hCarc`, `hOwner`, `hValue`, `hInt`, `hLock`, `hOwned`, `hDate`, `hKlass`, `hM1`, `hM2`, `hNarko`, `hDgl`, `hEm`, `hShot`, `hGarageStatus`, `hBalance`, `hTax`) VALUES
(274, -12.2388, 2346.32, 24.1406, 225.705, 1021.86, 1084.02, -24.0312, 2331.23, 25.0095, 86.8889, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(275, 2346.9, 691.484, 11.4609, 225.705, 1021.86, 1084.02, 2353.49, 697.811, 11.3125, 6.00469, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 167877, 1100),
(276, 2368.88, 689.8, 11.4605, 225.705, 1021.86, 1084.02, 2363.82, 699.255, 11.1305, 357.555, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(277, 2396.9, 690.344, 11.4531, 225.705, 1021.86, 1084.02, 2388.68, 693.953, 11.4531, 357.257, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(278, 1969.28, -1714.89, 17.056, 225.705, 1021.86, 1084.02, 1967.56, -1709.34, 15.9688, 269.664, 'The State', 2000000, 7, 1, 0, 0, 4, 'Failure_Malware', 'Frank_Frost', 0, 0, 0, 0, 0, 127517, 1100),
(279, 1286.8, -1329.24, 13.5549, 225.705, 1021.86, 1084.02, 1275.77, -1323.8, 13.3266, 174.376, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mutiko_Kirtadze', 'None', 0, 0, 0, 0, 0, 86800, 1100),
(280, 2239.05, 1285.71, 10.8203, 225.705, 1021.86, 1084.02, 2229.06, 1291.43, 10.6719, 355.618, 'The State', 2000000, 7, 1, 0, 0, 4, 'Neji_Hyuga', 'None', 0, 0, 0, 0, 0, 0, 1100),
(281, 2177.05, 690.802, 11.4609, 225.705, 1021.86, 1084.02, 2168.46, 712.258, 10.6719, 77.8613, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(282, 2228.7, 689.884, 11.4605, 83.0589, 1322.55, 1083.87, 2220.29, 694.679, 11.4144, 358.195, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 100, 0, 0, 0, 17500, 700),
(283, 1291.05, 1257.95, 10.8203, 225.705, 1021.86, 1084.02, 1288.7, 1270.65, 10.8203, 318.185, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(284, 1321.26, 1250.39, 14.2656, 83.0589, 1322.55, 1083.87, 1325.76, 1281.69, 10.8203, 2.11424, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(285, 387.012, -1817.85, 7.84095, 225.705, 1021.86, 1084.02, 371.754, -1819.78, 7.66951, 355.495, 'The State', 2000000, 7, 1, 0, 0, 4, 'Baka_Jekson', 'None', 0, 0, 0, 0, 1, 147400, 1100),
(286, 2120.28, 696.087, 11.4531, 225.705, 1021.86, 1084.02, 2128.65, 690.887, 11.3997, 179.627, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nikoloz_Phiphia', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(287, 2091.58, 695.032, 11.4609, 234.138, 1063.9, 1084.21, 2085.38, 688.055, 11.2889, 177.951, 'The State', 1000000, 6, 1, 0, 0, 3, 'Hisoka_Matterazzo', 'Gabo_Savage', 0, 0, 0, 0, 0, 900, 900),
(288, 1709.9, 1360.69, 10.7525, 225.705, 1021.86, 1084.02, 1722.28, 1373.34, 10.4922, 194.628, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(289, 2040.67, 696.095, 11.4531, 234.138, 1063.9, 1084.21, 2048.28, 691.664, 11.4531, 187.048, 'The State', 1000000, 6, 1, 0, 0, 3, 'Skrypx_Loxrys', 'Luka_Abes', 0, 0, 0, 0, 0, 94200, 900),
(290, 2013.87, 650.564, 11.4609, 225.705, 1021.86, 1084.02, 2005.76, 653.543, 12.6041, 359.344, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Saba_Pachkoria', 0, 0, 0, 0, 0, 114000, 1100),
(291, 2043.3, 651.744, 11.4609, 225.705, 1021.86, 1084.02, 2049.56, 657.564, 11.341, 359.278, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 163900, 1100),
(292, 2065.59, 649.918, 11.4683, 225.705, 1021.86, 1084.02, 2070.27, 669.701, 10.6719, 93.1657, 'The State', 2000000, 7, 1, 0, 0, 4, 'Norman_Reedus', 'None', 0, 0, 0, 0, 0, 82100, 1100),
(293, 1708.25, 1360.9, 10.7521, 83.0589, 1322.55, 1083.87, 1722.17, 1374.93, 10.4922, 196.15, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 114611, 700),
(294, 2122.39, 731.264, 11.4609, 225.705, 1021.86, 1084.02, 2129.48, 733.296, 11.4609, 359.16, 'The State', 2000000, 7, 1, 0, 0, 4, 'Luka_Kalandadze', 'Saba_Zhvania', 0, 0, 0, 0, 0, 0, 1100),
(295, 2093.54, 730.361, 11.4531, 225.705, 1021.86, 1084.02, 2086.01, 738.021, 11.2382, 0, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nika_Jobinashvili', 'None', 0, 0, 0, 0, 0, 0, 1100),
(296, 2064.68, 729.835, 11.4683, 225.705, 1021.86, 1084.02, 2058.58, 739.02, 11.1588, 354.66, 'The State', 2000000, 7, 1, 0, 0, 4, 'Alvin_Olinsky', 'None', 0, 0, 0, 0, 0, 134300, 1100),
(297, 848.097, -745.632, 94.9693, 225.705, 1021.86, 1084.02, 856.8, -747.568, 94.9688, 46.5723, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tiko_Chachua', 'None', 0, 0, 0, 0, 0, 66600, 1100),
(298, 2013.67, 730.36, 11.4531, 225.705, 1021.86, 1084.02, 2003.58, 737.994, 11.2106, 359.415, 'The State', 2000000, 7, 1, 0, 0, 4, 'Gio_Bibiluri', 'None', 0, 0, 0, 0, 0, 0, 1100),
(299, -36.0863, 2350.52, 24.3026, 225.705, 1021.86, 1084.02, -32.9948, 2340.51, 24.1406, 297.315, 'The State', 2000000, 7, 1, 0, 0, 4, 'Saba_Ghavtadze', 'Don_Chiliosi', 0, 0, 0, 0, 0, 0, 1100),
(300, 1034.93, -813.144, 101.852, 225.705, 1021.86, 1084.02, 1029.49, -801.344, 101.885, 25.889, 'The State', 2000000, 7, 1, 0, 0, 4, 'Kristian_Hanby', 'Tony_Bebera', 0, 300, 0, 0, 0, 0, 1100),
(301, 2093.5, 774.928, 11.4531, 225.705, 1021.86, 1084.02, 2088.67, 770.057, 11.4159, 177.899, 'The State', 2000000, 7, 1, 0, 0, 4, 'Handlix_Zechariah', 'Zuka_Azaladze', 0, 0, 0, 0, 0, 69700, 1100),
(302, -419.013, -1759.29, 6.21875, 225.705, 1021.86, 1084.02, -411.76, -1763.67, 5.39089, 342.494, 'The State', 2000000, 7, 1, 0, 0, 4, 'Niko_Hellsize', 'None', 0, 0, 0, 0, 0, 78600, 1100),
(303, 2635.83, -2013.13, 14.1443, 225.705, 1021.86, 1084.02, 2640.29, -2004.97, 13.5547, 278.678, 'The State', 2000000, 7, 1, 0, 0, 4, 'Jigen_Unstoppable', 'None', 0, 0, 0, 0, 0, 50600, 1100),
(304, 2637.1, -1991.68, 14.324, 225.705, 1021.86, 1084.02, 2645.96, -1993.81, 13.5555, 199.143, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mamada_Goldrise', 'None', 0, 0, 0, 0, 0, 152200, 1100),
(305, 2652.68, -1989.72, 13.9988, 225.705, 1021.86, 1084.02, 2646.31, -2007.51, 13.3828, 271.359, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(306, 2672.48, -1989.47, 14.324, 234.138, 1063.9, 1084.21, 2682.92, -2001.38, 13.3454, 271.344, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(307, 2696.13, -1990.36, 14.2229, 225.705, 1021.86, 1084.02, 2700.35, -1999.18, 13.2895, 229.588, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(308, 2695.49, -2020.55, 14.0223, 225.705, 1021.86, 1084.02, 2684.18, -2015.25, 14.8459, 359.379, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(309, 808.286, -759.432, 76.5314, 225.705, 1021.86, 1084.02, 820.778, -766.145, 77.8748, 193.429, 'The State', 2000000, 7, 1, 0, 0, 4, 'Motier_Ficker', 'Tonny_Moralez', 0, 0, 0, 0, 0, 175600, 1100),
(310, 1183.48, -1098.87, 28.2578, 225.705, 1021.86, 1084.02, 1177.12, -1108.22, 25.1551, 95.7373, 'The State', 2000000, 7, 1, 0, 0, 4, 'Jason_Black', 'All_Kapone', 0, 0, 0, 0, 1, 101100, 1100),
(311, 1142.12, -1092.85, 28.1875, 225.705, 1021.86, 1084.02, 1164.29, -1100.3, 24.9928, 188.576, 'The State', 2000000, 7, 1, 0, 0, 4, 'Gigi_Gingiuri', 'Tekashi_Uchiha', 0, 0, 0, 0, 0, 162200, 1100),
(312, 1183.47, -1075.97, 31.6789, 225.705, 1021.86, 1084.02, 1178.01, -1067.12, 28.9707, 96.6777, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Anstak_Kaente', 0, 0, 0, 0, 0, 0, 1100),
(313, 1141.81, -1070.01, 31.7656, 83.0589, 1322.55, 1083.87, 1157.54, -1073.83, 27.6574, 179.532, 'The State', 900000, 9, 1, 0, 0, 2, 'King_Narmania', 'Nexxon_Meliqidze', 0, 0, 0, 0, 0, 65800, 700),
(314, 153.278, -1449.5, 32.845, 225.705, 1021.86, 1084.02, 157.215, -1449.22, 36.3099, 321.223, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mishka_Maladoy', 'None', 0, 0, 0, 0, 0, 108300, 1100),
(315, -1011.99, 1899.58, 560.815, 2270.05, -1210.46, 1047.56, -358.762, 1530.17, 75.3594, 1.87116, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(316, 946.327, -710.69, 122.62, 234.138, 1063.9, 1084.21, 947.686, -703.836, 122.211, 33.4392, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 900, 900),
(317, 693.575, -1705.73, 3.81948, 225.705, 1021.86, 1084.02, 701.803, -1699.48, 3.41128, 106.858, 'The State', 2000000, 7, 1, 0, 0, 4, 'Maximus_Tompas', 'Saba_Sherozia', 0, 0, 0, 0, 0, 53900, 1100),
(318, 693.764, -1645.88, 4.09375, 225.705, 1021.86, 1084.02, 705.919, -1654.55, 3.4375, 183.182, 'The State', 2000000, 7, 1, 0, 0, 4, 'Jakoo_Morrison', 'None', 0, 0, 0, 0, 0, 53900, 1100),
(319, 769.222, -1696.66, 5.15542, 225.705, 1021.86, 1084.02, 761.914, -1696.7, 4.82953, 181.49, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Emperor_Blizzard', 0, 0, 0, 0, 0, 116600, 1100),
(320, 769.228, -1745.99, 13.0773, 225.705, 1021.86, 1084.02, 1681.09, -2321.29, 13.3828, 37.6854, 'The State', 2000000, 7, 1, 0, 0, 4, 'Andria_Escobar', 'None', 0, 0, 0, 0, 0, 55700, 1100),
(321, 768.031, -1655.59, 5.60938, 225.705, 1021.86, 1084.02, 764.633, -1660.17, 4.45494, 84.7099, 'The State', 2000000, 7, 1, 0, 0, 4, 'Hatey_Diabhail', 'Oppie_Winston', 0, 0, 0, 0, 0, 0, 1100),
(322, 656.734, -1481.07, 14.8516, 225.705, 1021.86, 1084.02, 644.158, -1477.29, 14.6528, 7.43764, 'The State', 2000000, 7, 1, 0, 0, 4, 'Iksona_Phorchkhidze', 'None', 0, 0, 0, 0, 0, 147800, 1100),
(323, 725.643, -1450.98, 17.6953, 225.705, 1021.86, 1084.02, 717.319, -1436.23, 16.4633, 53.5482, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tom_Vendetta', 'Giorgi_Tetradze', 0, 0, 0, 0, 0, 0, 1100),
(324, 822.419, -1505.52, 14.3976, 225.705, 1021.86, 1084.02, 836.888, -1503.05, 12.9155, 3.40404, 'The State', 2000000, 7, 1, 0, 0, 4, 'Luckson_Anderson', 'Andreas_Scaglietti', 0, 0, 0, 0, 1, 27500, 1100),
(325, 793.978, -1707.5, 14.0382, 225.705, 1021.86, 1084.02, 802.448, -1704.98, 13.5469, 183.069, 'The State', 2000000, 7, 1, 0, 0, 4, 'Glacier_Matterazzo', 'Bee_Clowton', 0, 0, 0, 0, 0, 181400, 1100),
(326, 791.35, -1753.22, 13.4603, 225.705, 1021.86, 1084.02, 792.909, -1761.21, 13.4195, 176.362, 'The State', 2000000, 7, 1, 0, 0, 4, 'Lasha_Sebiskveradz', 'None', 0, 0, 0, 0, 0, 0, 1100),
(327, 657.398, -1434.11, 14.8516, 225.705, 1021.86, 1084.02, 683.438, -1451.56, 14.8516, 105.446, 'The State', 2000000, 7, 1, 0, 0, 4, 'Oliver_Johnson', 'Gorila_Prezident', 0, 0, 0, 0, 0, 0, 1100),
(328, -793.193, -821.646, 149.778, 225.705, 1021.86, 1084.02, -797.197, -847.059, 148.839, 19.9309, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 175400, 1100),
(329, 479.575, -1752.11, 14.0481, 225.705, 1021.86, 1084.02, 485.412, -1777.2, 5.6636, 85.8937, 'The State', 2000000, 7, 1, 0, 0, 4, 'Viktor_Pchyolkin', 'None', 0, 0, 0, 0, 0, 154400, 1100),
(330, 903.914, -1815.57, 13.3018, 225.705, 1021.86, 1084.02, 908.354, -1823.03, 12.5762, 81.7265, 'The State', 2000000, 7, 1, 0, 0, 4, 'Ucha_Tamazashvili', 'None', 0, 0, 0, 0, 0, 128585, 1100),
(331, 927.38, -1818.33, 13.324, 234.138, 1063.9, 1084.21, 936.089, -1832.37, 12.6024, 83.1062, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'Don_Korleonne', 0, 0, 0, 0, 0, 150900, 900),
(332, 961.333, -1824.01, 13.3275, 83.0589, 1322.55, 1083.87, 962.228, -1834.46, 12.5977, 261.856, 'The State', 900000, 9, 1, 0, 0, 2, 'George_Tevzadze', 'Nika_Kurshubadze', 0, 0, 0, 0, 0, 700, 700),
(333, 973.694, -1827.07, 13.3327, 2270.05, -1210.46, 1047.56, 966.29, -1830.82, 12.605, 251.702, 'The State', 700000, 10, 1, 0, 0, 1, 'Nika_Costblack', 'None', 0, 0, 0, 0, 0, 0, 500),
(334, 813.691, -1456.64, 14.2256, 2270.05, -1210.46, 1047.56, 799.804, -1453.09, 13.3906, 359.017, 'The State', 700000, 10, 1, 0, 0, 1, 'Mastera_Kalashnikov', 'Tom_Smiths', 0, 0, 0, 0, 0, 65000, 500),
(335, 852.432, -1436.24, 15.0437, 225.705, 1021.86, 1084.02, 853.533, -1443.61, 13.5875, 46.2892, 'The State', 2000000, 7, 1, 0, 0, 4, 'Temzi_Maladoi', 'None', 0, 0, 0, 0, 0, 0, 1100),
(336, 648.838, -1536.72, 14.9372, 225.705, 1021.86, 1084.02, 646.799, -1545.01, 15.3635, 148.397, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sebastian_Jhonson', 'None', 0, 0, 0, 0, 0, 42900, 1100),
(337, 650.941, -1575.96, 15.4113, 225.705, 1021.86, 1084.02, 688.34, -1571, 15.7857, 188.804, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 121500, 1100),
(338, 891.074, -783.206, 101.314, 225.705, 1021.86, 1084.02, 892.963, -777.942, 101.281, 268.353, 'The State', 2000000, 7, 1, 0, 0, 4, 'Shako_Nikolaishvili', 'Ezdilavd_Akin', 0, 0, 0, 0, 0, 109626, 1100),
(339, 653.2, -1619.77, 15, 225.705, 1021.86, 1084.02, 646.656, -1622.43, 15.0861, 117.072, 'The State', 2000000, 7, 1, 0, 0, 4, 'Luka_Caava', 'None', 0, 0, 0, 0, 1, 1100, 1100),
(340, 657.215, -1652.61, 15.4062, 225.705, 1021.86, 1084.02, 654.05, -1657.12, 14.5862, 84.2602, 'The State', 2000000, 7, 1, 0, 0, 4, 'Narsik_Enkeyes', 'None', 0, 0, 0, 0, 0, 0, 1100),
(341, -2027.83, -40.6095, 38.8047, 83.0589, 1322.55, 1083.87, -2020.86, -60.8945, 35.3203, 206.522, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(342, 1111.51, -976.44, 42.7656, 225.705, 1021.86, 1084.02, 1109.93, -970.034, 42.7648, 4.05526, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tazo_Mazer', 'Jeck_Danielsi', 0, 0, 0, 0, 0, 168500, 1100),
(343, 352.33, -1198, 76.5156, 225.705, 1021.86, 1084.02, 1485.59, -1742.12, 13.5469, 197.917, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Buchukuri_Gio', 0, 0, 0, 0, 0, 1100, 1100),
(344, -2018.55, 865.719, 45.4453, 225.705, 1021.86, 1084.02, 229.511, -1197.42, 75.3125, 303.925, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(345, 835.922, -894.786, 68.7689, 83.0589, 1322.55, 1083.87, 829.284, -886.332, 68.7734, 235.615, 'The State', 900000, 9, 1, 0, 0, 2, 'Tiramisu_Dea', 'None', 0, 0, 0, 0, 1, 101500, 700),
(346, 2206.56, 691.325, 11.4609, 225.705, 1021.86, 1084.02, 2211.66, 697.415, 11.359, 3.11709, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nick_Johnson', 'Ann_Dellarosa', 0, 0, 0, 0, 0, 86500, 1100),
(347, -396.39, -425.081, 16.2594, 234.138, 1063.9, 1084.21, -392.669, -436.497, 16.2031, 68.9233, 'The State', 1000000, 6, 1, 0, 0, 3, 'Toma_Nikolaishvili', 'None', 0, 0, 0, 0, 0, 99700, 900),
(348, 655.986, -1635.87, 15.8617, 225.705, 1021.86, 1084.02, 644.336, -1637.38, 15.1181, 0.599704, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Gagi_Wonderstown', 0, 0, 0, 0, 0, 66300, 1100),
(349, -28.8918, 2356.83, 24.1406, 225.705, 1021.86, 1084.02, -22.9035, 2363.36, 24.1406, 266.157, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(350, 1938.54, -1911.26, 15.2568, 2270.05, -1210.46, 1047.56, 1935.23, -1930.46, 13.3828, 175.43, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 12500, 500),
(351, 1778.52, -1663.14, 14.4368, 225.705, 1021.86, 1084.02, 1769.13, -1667.14, 14.4152, 320.796, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nick_Harderson', 'Giorgi_Metreveli', 0, 0, 0, 0, 0, 77000, 1100),
(352, 648.365, -1058.66, 52.5799, 83.0589, 1322.55, 1083.87, 660.234, -1071.41, 48.5102, 290.503, 'The State', 900000, 9, 1, 0, 0, 2, 'Dato_Milon', 'None', 0, 0, 0, 0, 0, 83000, 700),
(353, 897.933, -677.099, 116.89, 225.705, 1021.86, 1084.02, 911.388, -665.046, 116.959, 237.833, 'The State', 2000000, 7, 1, 0, 0, 4, 'Rati_Ratiani', 'Davit_Kakuberi', 0, 0, 0, 0, 0, 171500, 1100),
(354, 432.328, -1253.85, 51.5809, 234.138, 1063.9, 1084.21, 420.466, -1258.69, 51.581, 21.3671, 'The State', 1000000, 6, 1, 0, 0, 3, 'Mariam_Razmadze', 'None', 0, 0, 0, 0, 0, 0, 900),
(355, 914.301, -1004.63, 37.9794, 225.705, 1021.86, 1084.02, 921.354, -998.484, 38.1223, 59.1949, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nikusha_Rivera', 'Wobezym_Undead', 0, 0, 0, 0, 0, 27500, 1100),
(356, 1280.86, -874.853, 46.8438, 225.705, 1021.86, 1084.02, 1286.05, -878.22, 42.9533, 184.523, 'The State', 2000000, 7, 1, 0, 0, 4, 'Vito_Korleon', 'None', 0, 0, 0, 0, 0, 152500, 1100),
(357, 559.249, -1076.34, 72.922, 83.0589, 1322.55, 1083.87, 565.354, -1066.91, 73.4499, 31.7571, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'Jonathan_Frost', 0, 0, 0, 0, 0, 95700, 700),
(358, 497.475, -1095.07, 82.3592, 225.705, 1021.86, 1084.02, 478.59, -1088.12, 82.4972, 358.396, 'The State', 2000000, 7, 1, 0, 0, 4, 'Saba_Blood', 'Nikala_Montana', 0, 0, 0, 0, 0, 0, 1100),
(359, 552.976, -1200.27, 44.8315, 225.705, 1021.86, 1084.02, 545.241, -1193.08, 44.4679, 106.915, 'The State', 2000000, 7, 1, 0, 0, 4, 'Giorgi_Heizeri', 'Basi_Makalyster', 0, 0, 0, 0, 0, 182800, 1100),
(360, 1468.67, -906.185, 54.8359, 225.705, 1021.86, 1084.02, 2184.24, -1807.21, 13.3727, 28.5319, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Dato_Xurcilava', 0, 0, 0, 0, 0, 1100, 1100),
(361, 2212.34, 2338.23, 10.8125, 225.705, 1021.86, 1084.02, 2202.37, 2333.82, 10.6719, 322.186, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(362, 1103.39, -1068.32, 31.8899, 225.705, 1021.86, 1084.02, 1101.32, -1078.43, 28.8803, 91.9569, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Luka_Devnos', 0, 0, 0, 0, 0, 0, 1100),
(363, 1317.56, 1250.39, 14.2656, 225.705, 1021.86, 1084.02, 1321.09, 1263.85, 10.8203, 173.248, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(364, 1319.06, 1249.39, 10.8203, 2270.05, -1210.46, 1047.56, 1315.88, 1278.39, 10.8203, 0.492974, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(365, 1347.13, 1257.74, 10.8203, 83.0589, 1322.55, 1083.87, 1353.16, 1257.17, 10.8203, 37.417, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(366, 1303.93, 1606.52, 10.8203, 2270.05, -1210.46, 1047.56, 1310.56, 1602.43, 10.8203, 269.503, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(367, 1303.93, 1614.77, 10.8203, 2270.05, -1210.46, 1047.56, 1310.53, 1627.45, 10.8203, 270.849, 'The State', 700000, 10, 1, 0, 0, 1, 'Juan_Rodrigues', 'None', 0, 0, 0, 0, 0, 0, 500),
(368, 940.575, -1085.37, 24.2962, 225.705, 1021.86, 1084.02, 932.542, -1092.42, 24.3164, 113.357, 'The State', 2000000, 7, 1, 0, 0, 4, 'Diego_Navarro', 'None', 0, 0, 0, 0, 0, 173400, 1100),
(369, 167.763, -1758.98, 6.79688, 83.0589, 1322.55, 1083.87, 157.456, -1759.76, 4.69599, 359.934, 'The State', 900000, 9, 1, 0, 0, 2, 'Saba_Siradze', 'None', 0, 0, 0, 0, 0, 100700, 700),
(370, 2161.06, -99.1524, 2.75808, 83.0589, 1322.55, 1083.87, 2150.61, -97.1772, 2.70484, 29.9416, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 101700, 700),
(371, 1497.03, -687.906, 95.5633, 225.705, 1021.86, 1084.02, 1509.8, -695.895, 94.75, 261.99, 'Jack_Miller', 2000000, 7, 1, 1, 0, 4, 'Alex_Wick', 'Giga_Bokeria', 0, 0, 0, 0, 1, 181100, 1100),
(372, 1050.99, -1059.05, 34.7966, 225.705, 1021.86, 1084.02, 1040.74, -1055.01, 31.7031, 2.38515, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(373, -1061.61, -1195.76, 129.828, 83.0589, 1322.55, 1083.87, -1053.8, -1198.44, 129.025, 179.007, 'The State', 900000, 9, 1, 0, 0, 2, 'Jora_Gabiskiria', 'None', 0, 0, 0, 0, 0, 0, 700),
(374, 2173.32, 1285.38, 24.4754, 225.705, 1021.86, 1084.02, 2163.63, 1295.21, 18.0269, 77.7072, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 1, 1100, 1100),
(375, -1009.53, 1839.07, 845.318, 2308.8, -1212.84, 1049.02, 1408.87, -1584.46, 13.5605, 242.321, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(376, 1965.05, 1623.22, 12.8621, 2270.05, -1210.46, 1047.56, 2014.46, 1623.17, 11.6016, 265.01, 'The State', 700000, 10, 1, 0, 0, 1, 'Gio_Philips', 'None', 100, 50, 0, 0, 0, 83500, 500),
(377, 1676.27, -1635.19, 14.2266, 83.0589, 1322.55, 1083.87, 1685.12, -1626.87, 13.3828, 186.343, 'The State', 900000, 9, 1, 0, 0, 2, 'Salome_Mirziashvili', 'Antoni_Morgani', 0, 0, 0, 0, 0, 0, 700),
(378, 1564.62, 2565.86, 10.8265, 225.705, 1021.86, 1084.02, 1572.94, 2573.35, 10.8203, 320.174, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 27500, 1100),
(379, 1551.49, 2568.13, 10.8203, 225.705, 1021.86, 1084.02, 1546.42, 2578.57, 10.8265, 2.1941, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(380, 771.201, -1809.4, 13.0234, 225.705, 1021.86, 1084.02, 775.822, -1813.63, 13.0234, 263.006, 'The State', 2000000, 7, 1, 0, 0, 4, 'Glock_Impulse', 'Giorgi_Farcvania', 0, 0, 0, 0, 0, 182600, 1100),
(381, 2597.66, 1900.36, 11.0312, 225.705, 1021.86, 1084.02, 2581.03, 1896.35, 10.8222, 84.7761, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(382, -1942.14, 2379.46, 49.7031, 2308.8, -1212.84, 1049.02, -1938.39, 2386.47, 49.4922, 293.965, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(383, 1188.46, -1011.54, 32.5469, 83.0589, 1322.55, 1083.87, 1193.02, -1016.82, 32.5469, 184.137, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'Ana_Morgan', 47, 0, 101, 0, 0, 3000, 700),
(384, 1328.5, -1556.79, 13.5469, 225.705, 1021.86, 1084.02, 1319.98, -1553.03, 13.5469, 357.757, 'The State', 2000000, 7, 1, 0, 0, 4, 'Bob_Anderson', 'Kevin_Morningstar', 0, 0, 0, 0, 0, 159500, 1100),
(385, -1003.45, 1901.12, 418.265, 83.0589, 1322.55, 1083.87, -313.144, 1533.45, 75.3594, 165.117, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(386, -1032.81, 1914.36, 441.482, 2308.8, -1212.84, 1049.02, 1482.02, 2790.81, 10.8203, 273.506, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(387, -23.9392, -2482.02, 36.6484, 225.705, 1021.86, 1084.02, -21.9425, -2498.81, 36.6484, 116.256, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(388, -1005.44, 1903.16, 420.872, 2308.8, -1212.84, 1049.02, 263.66, -1218.09, 75.1407, 157.762, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(389, 1048.67, 2910.17, 47.8231, 234.138, 1063.9, 1084.21, 1046.58, 2898.07, 45.759, 177.382, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(390, 298.677, -1338, 53.4416, 225.705, 1021.86, 1084.02, 294.814, -1334.31, 53.4414, 29.6918, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Pogra_Flashback', 0, 0, 0, 0, 1, 159500, 1100),
(391, 1059.18, -1105.13, 28.0451, 225.705, 1021.86, 1084.02, 1075.97, -1104.23, 24.7692, 179.314, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 1, 160700, 1100),
(392, -1465.68, 2611.99, 56.1797, 2308.8, -1212.84, 1049.02, -1467.25, 2606.04, 55.6875, 269.99, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(393, 1068.42, -1081.32, 27.5482, 225.705, 1021.86, 1084.02, 1072.18, -1058.43, 30.2271, 263.695, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 1, 180900, 1100),
(394, 694.97, -1690.54, 4.34612, 225.705, 1021.86, 1084.02, 706.121, -1687.06, 3.4399, 178.31, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 73700, 1100),
(395, -369.669, 1169.65, 20.2719, 2270.05, -1210.46, 1047.56, -360.937, 1197.97, 19.7422, 177.241, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(396, 1913.44, -1911.9, 15.2568, 225.705, 1021.86, 1084.02, 1923.45, -1926.72, 13.5469, 91.2154, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 300, 0, 0, 178900, 1100),
(397, 1456.97, -1137.19, 23.9442, 225.705, 1021.86, 1084.02, 1473.44, -1131.41, 24.0781, 336.678, 'The State', 2000000, 7, 1, 0, 0, 4, 'Barto_Ernesto', 'Dead_Hare', 0, 0, 0, 0, 0, 27500, 1100),
(398, 1524.28, -1114.53, 20.8636, 225.705, 1021.86, 1084.02, 1567.67, -1115.91, 23.5979, 3.81798, 'The State', 2000000, 7, 1, 0, 0, 4, 'Don_Sandreqsa', 'None', 0, 0, 0, 0, 0, 27500, 1100),
(399, -2034.89, 148.721, 28.8359, 225.705, 1021.86, 1084.02, -2026.12, 124.957, 29.1102, 4.04544, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 161100, 1100),
(400, -1023.32, 1912.84, 444.723, 2308.8, -1212.84, 1049.02, 1424.86, -1562.08, 13.5469, 359.047, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(401, -1009.47, 1839.2, 838.331, 2308.8, -1212.84, 1049.02, 1415.68, -1648.68, 13.3754, 267.789, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(402, 1419.45, -1623.67, 13.5469, 225.705, 1021.86, 1084.02, -66.4792, -1039.42, 21.174, 195.489, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(403, -1008.49, 1841.34, 820.081, 2308.8, -1212.84, 1049.02, 1397.49, -1596.79, 13.8063, 74.2584, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(404, 501.853, -1059.14, 1770.89, 2308.8, -1212.84, 1049.02, 684.14, -1071.26, 49.6416, 84.6426, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(405, 1903.59, -916.737, 893.981, 2308.8, -1212.84, 1049.02, 1451.33, -923.82, 37.6094, 353.908, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(406, 152.729, -1946.41, 544.836, 2308.8, -1212.84, 1049.02, 152.041, -1933.75, 3.76964, 344.799, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(407, -998.99, 1861.91, 715.323, 2308.8, -1212.84, 1049.02, 1531.89, -1842.83, 13.5469, 359.143, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(408, 1838.09, 718.889, -122.668, 2308.8, -1212.84, 1049.02, 1490.3, -1842.31, 13.5469, 89.4341, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(409, 1464.77, -1051.62, 24.0156, 225.705, 1021.86, 1084.02, 2790.03, -1617.46, 10.9219, 345.777, 'The State', 2000000, 7, 1, 0, 0, 4, 'Edward_Corleone', 'Piter_Harison', 0, 0, 0, 0, 0, 0, 1100),
(410, -968.755, 1908.11, 515.006, 2308.8, -1212.84, 1049.02, 1472.58, -1833.54, 13.5469, 181.867, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(411, 878.49, -725.765, 106.447, 225.705, 1021.86, 1084.02, 883.2, -711.414, 107.309, 242.187, 'The State', 2000000, 7, 1, 0, 0, 4, 'Lukaa_Zoidze', 'Akaki_Nanobashvili', 0, 0, 0, 0, 0, 133000, 1100),
(412, -1002.44, 1854.45, 747.403, 2308.8, -1212.84, 1049.02, 1511.96, -1847.06, 13.5469, 345.369, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(413, 155.652, -1946.58, 568.102, 2308.8, -1212.84, 1049.02, 156.706, -1934.26, 3.77344, 16.4319, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(414, -1008.51, 1889.74, 601.904, 83.0589, 1322.55, 1083.87, 1447.07, -1842.94, 13.5469, 355.694, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(415, 2284.75, -1906.6, 14.9297, 225.705, 1021.86, 1084.02, 2273.87, -1909.91, 13.5469, 359.972, 'The State', 2000000, 7, 1, 0, 0, 4, 'Ikusha_Palelashvili', 'None', 0, 0, 0, 0, 0, 41800, 1100),
(416, 287.198, -2112.86, 431.001, 2308.8, -1212.84, 1049.02, 149.401, -1939.91, 3.77344, 331.566, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(417, 1046.49, -1131.43, 712.826, 2308.8, -1212.84, 1049.02, 1042.43, -1138.13, 23.664, 268.487, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(418, 981.829, -1162.44, 25.0859, 234.138, 1063.9, 1084.21, 1004.08, -1160.26, 23.8594, 271.235, 'The State', 1000000, 6, 1, 0, 0, 3, 'John_Gringo', 'Johny_Depp', 0, 0, 0, 0, 1, 32400, 900),
(419, 290.598, -1874.98, 3.83322, 225.705, 1021.86, 1084.02, 296.515, -1878.56, 2.28186, 348.378, 'The State', 2000000, 7, 1, 0, 0, 4, 'Zura_Jugeli', 'Saba_Samsonashvili', 0, 0, 0, 0, 0, 0, 1100),
(420, 1536.74, -2431.15, 841.41, 2308.8, -1212.84, 1049.02, 0, 0, 0, 0, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(421, 541.237, -1817.85, 1062.16, 2308.8, -1212.84, 1049.02, 0, 0, 0, 0, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(422, 455.191, -1796.11, 811.178, 2308.8, -1212.84, 1049.02, 0, 0, 0, 0, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(423, 1574.15, -1274.69, 17.4884, 225.705, 1021.86, 1084.02, 1118.38, -4.71637, 1000.68, 116.101, 'The State', 2000000, 7, 1, 0, 0, 4, 'Atuka_Kuxalashvilii', 'None', 0, 0, 0, 0, 1, 30800, 1100),
(424, 387.639, -1870.67, 7.83594, 225.705, 1021.86, 1084.02, 372.596, -1859.41, 7.67188, 0, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nini_Todua', 'None', 0, 0, 1, 0, 0, 0, 1100),
(425, 2708.19, -1497.87, 30.6112, 225.705, 1021.86, 1084.02, 2702.87, -1503.21, 30.4042, 79.5305, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nia_Pircxelava', 'Sonny_Martinez', 0, 0, 0, 0, 0, 0, 1100),
(426, 387.814, -1897.26, 7.83594, 225.705, 1021.86, 1084.02, 372.486, -1899.24, 7.67188, 3.51391, 'The State', 2000000, 7, 1, 0, 0, 4, 'Vin_Diesel', 'None', 0, 300, 0, 0, 0, 90200, 1100),
(427, 142.655, -1470.39, 25.2109, 234.138, 1063.9, 1084.21, 146.691, -1466.53, 25.375, 46.5206, 'The State', 1000000, 6, 1, 0, 0, 3, 'Flash_Matterazzo', 'Dachi_Pachkoria', 0, 0, 0, 0, 0, 0, 900),
(428, 1046.98, -653.521, 120.111, 225.705, 1021.86, 1084.02, 1032.5, -639.865, 120.117, 312.13, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sandro_Uciha', 'Gio_Jobava', 0, 0, 0, 0, 0, 150300, 1100),
(429, 1505.8, -2407.12, 458.816, 2308.8, -1212.84, 1049.02, 0, 0, 0, 0, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(430, 711.306, -1080.29, 49.4219, 225.705, 1021.86, 1084.02, 684.529, -1049, 50.0964, 322.568, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sandrex_Costello', 'Nika_Shaqarishvili', 0, 0, 0, 0, 0, 138100, 1100),
(431, 672.976, -1019.76, 55.7596, 225.705, 1021.86, 1084.02, 689.367, -1016.93, 51.8545, 315.516, 'The State', 2000000, 7, 1, 0, 0, 4, 'Richy_Imprezza', 'None', 0, 0, 0, 0, 0, 162200, 1100),
(432, 379.931, -913.448, 330.387, 2308.8, -1212.84, 1049.02, 684.874, -1071.68, 49.6102, 67.4576, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(433, 92.7248, -2009.38, 404.862, 2308.8, -1212.84, 1049.02, 155.237, -1924.34, 3.77344, 13.2376, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(434, 3744.08, -673.001, 100.989, 2308.8, -1212.84, 1049.02, 1620.58, -1892.19, 13.549, 355.029, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(435, 3751.23, -667.824, 100.989, 2308.8, -1212.84, 1049.02, 1614.19, -1887.84, 13.5469, 3.2707, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(436, -1008.54, 1906.35, 423.871, 2270.05, -1210.46, 1047.56, 251.95, -1258.86, 70.5983, 299.033, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(437, -1023.77, 1918.14, 426.898, 2308.8, -1212.84, 1049.02, -317.879, 1515.72, 75.357, 0.055952, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(438, 1317.27, -1184.07, 23.5929, 225.705, 1021.86, 1084.02, 1325.83, -1171.98, 23.7591, 357.52, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 96800, 1100),
(439, -2664.39, -3.05299, 6.13281, 225.705, 1021.86, 1084.02, -2683.31, -22.3732, 4.33594, 185.233, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Joseph_Remnov', 0, 0, 0, 0, 0, 181100, 1100),
(440, 2795.54, -1619.47, 10.9219, 225.705, 1021.86, 1084.02, 2790.77, -1619.36, 10.9219, 72.0497, 'The State', 2000000, 7, 1, 0, 0, 4, 'Soxumski_Diego', 'Don_Mateus', 0, 0, 0, 0, 0, 175600, 1100),
(441, 189.639, -1308.47, 70.2491, 225.705, 1021.86, 1084.02, 197.804, -1311.37, 70.1259, 187.738, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mari_Lachashvili', 'Pako_Michelson', 0, 0, 0, 0, 0, 31900, 1100),
(442, -314.406, 1774.56, 43.6406, 225.705, 1021.86, 1084.02, -303.307, 1761.39, 42.6875, 136.962, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 6100, 1100),
(443, 910.462, -817.507, 103.126, 225.705, 1021.86, 1084.02, 913.505, -832.108, 92.5624, 221.922, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Noah_Michelson', 0, 0, 0, 0, 0, 0, 1100),
(444, 991.597, -695.266, 121.938, 2270.05, -1210.46, 1047.56, 1006.29, -662.134, 121.148, 34.5617, 'The State', 700000, 10, 1, 0, 0, 1, 'Vaxo_Kortxonjia', 'Bmanuel_Blackwood', 0, 0, 0, 0, 0, 50500, 500),
(445, -1029.92, 1918.68, 435.966, 2270.05, -1210.46, 1047.56, 1401.01, -1038.98, 24.5234, 93.9869, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(446, 1635.02, -2212.64, 2055.61, 2270.05, -1210.46, 1047.56, 1632.01, -2232.86, 2055.61, 68.7717, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(447, 1123.06, 367.83, -283.54, 83.0589, 1322.55, 1083.87, 0, 0, 0, 0, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700),
(448, 1234.93, 360.207, 19.5547, 2270.05, -1210.46, 1047.56, 1233.75, 356.43, 19.9499, 238.651, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'Keon_Hagen', 0, 0, 0, 0, 0, 66500, 500),
(449, 1123.06, 367.83, -283.54, 2308.8, -1212.84, 1049.02, 0, 0, 0, 0, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(450, 1123.06, 367.83, -283.54, 2270.05, -1210.46, 1047.56, 0, 0, 0, 0, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(451, 725.353, -1276.33, 13.6484, 225.705, 1021.86, 1084.02, 734.964, -1263, 13.5537, 320.403, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Nikita_Varancoeli', 0, 0, 0, 0, 0, 178900, 1100),
(452, 265.763, -1287.75, 74.6325, 234.138, 1063.9, 1084.21, 287.661, -1274.92, 73.9453, 42.9371, 'The State', 1000000, 6, 1, 0, 0, 3, 'Tony_Luther', 'Dark_Luther', 0, 0, 0, 0, 0, 4500, 900),
(453, 534.813, -1173.67, 58.8097, 234.138, 1063.9, 1084.21, 520.091, -1147.42, 60.5613, 75.7559, 'The State', 1000000, 6, 1, 0, 0, 3, 'Louis_Prada', 'None', 0, 0, 0, 0, 0, 123200, 900),
(454, 1127.83, -1021.56, 34.9922, 225.705, 1021.86, 1084.02, 1136.74, -1025.18, 33.0848, 348.25, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(455, -2118.67, 2677.55, 159.032, 225.705, 1021.86, 1084.02, -2110.63, 2683.32, 159.793, 278.119, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(456, 4035.26, -763.749, 62.3084, 2270.05, -1210.46, 1047.56, 1576.93, -1879.1, 13.5469, 79.8694, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(457, 4038.66, -766.212, 62.3084, 2270.05, -1210.46, 1047.56, 1584.19, -1878.14, 13.5391, 12.224, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(458, 1519.78, -1453.35, 14.2071, 225.705, 1021.86, 1084.02, 1515.64, -1461.35, 9.5, 188.581, 'The State', 2000000, 7, 1, 0, 0, 4, 'Tazo_Bekaura', 'Dato_Samsonashvili', 0, 0, 0, 0, 0, 136000, 1100),
(459, 3791.75, -638.473, 100.989, 2270.05, -1210.46, 1047.56, 1591.21, -1877.83, 13.5391, 344.43, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(460, 1571.07, -1898.01, 13.5609, 225.705, 1021.86, 1084.02, 1567.41, -1881.97, 13.5469, 2.98669, 'The State', 2000000, 7, 1, 0, 0, 4, 'Darken_Coldstyle', 'None', 0, 0, 0, 0, 0, 155700, 1100),
(461, 271.59, -48.9529, 2.77721, 83.0589, 1322.55, 1083.87, 1045.4, -310.421, 77.3729, 178.856, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 700, 700),
(462, 1118.13, -1021.62, 34.9922, 225.705, 1021.86, 1084.02, 1108.5, -1025.51, 31.8998, 178.606, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 183700, 1100),
(463, 817.317, -495.731, 18.0129, 234.138, 1063.9, 1084.21, 827.665, -497.474, 17.3281, 177.776, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 0, 900),
(464, 759.404, -592.03, 18.0133, 225.705, 1021.86, 1084.02, 744.1, -582.198, 16.9721, 70.6694, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(465, 1529.73, -1850.15, 13.5469, 225.705, 1021.86, 1084.02, 1528.76, -1848.73, 13.5469, 54.4175, 'The State', 2000000, 7, 1, 0, 0, 4, 'Mikheil_Tsagareli', 'Sebastian_Wiliams', 0, 0, 0, 0, 0, 118300, 1100),
(466, -3065.27, 3828.9, 205.326, 2308.8, -1212.84, 1049.02, 1306.01, -813.883, 77.7119, 214.955, 'The State', 500000, 6, 1, 0, 0, 0, 'None', 'None', 0, 0, 0, 0, 0, 0, 300),
(467, 1272.37, -1116.35, 24.5731, 225.705, 1021.86, 1084.02, 1268.11, -1111.08, 24.8426, 0.587171, 'The State', 2000000, 7, 1, 0, 0, 4, 'Vakho_Cercva', 'Saba_Konchoshvili', 0, 0, 0, 0, 0, 131000, 1100),
(468, 626.964, -571.638, 17.9207, 225.705, 1021.86, 1084.02, 634.139, -577.435, 16.3359, 358.329, 'The State', 2000000, 7, 1, 0, 0, 4, 'Sann_Andreass', 'None', 0, 0, 0, 0, 0, 0, 1100),
(469, 614.414, -518.545, 16.3533, 225.705, 1021.86, 1084.02, 609.225, -514.786, 16.3359, 1.47034, 'The State', 2000000, 7, 1, 0, 0, 4, 'Saba_Varsimashvili', 'None', 0, 0, 0, 0, 0, 0, 1100),
(470, 691.363, -640.523, 16.3221, 225.705, 1021.86, 1084.02, 684.441, -637.882, 16.1875, 175.121, 'The State', 2000000, 7, 1, 0, 0, 4, 'Flex_Tripplex', 'None', 0, 0, 0, 0, 0, 0, 1100),
(471, -692.316, 939.574, 13.6328, 225.705, 1021.86, 1084.02, -699.997, 965.582, 12.3516, 93.8537, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 112211, 1100),
(472, 867.67, -716.911, 105.68, 225.705, 1021.86, 1084.02, 874.282, -706.917, 106.333, 131.955, 'The State', 2000000, 7, 1, 0, 0, 4, 'Kostuma_Aleqsidze', 'None', 0, 0, 0, 0, 0, 176100, 1100),
(473, 580.199, -1149.53, 53.1801, 225.705, 1021.86, 1084.02, 570.558, -1147.74, 51.0995, 302.728, 'The State', 2000000, 7, 1, 0, 0, 4, 'Domenic_Clowton', 'Thesexy_Ardizzone', 0, 0, 0, 0, 0, 0, 1100),
(474, 154.143, -1946.62, 5.38978, 225.705, 1021.86, 1084.02, 152.974, -1932.99, 3.77344, 286.919, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nikson_Montana', 'Guja_Manson', 0, 0, 0, 0, 1, 159500, 1100),
(475, 1333.68, -1329.38, 13.5391, 225.705, 1021.86, 1084.02, 1337.1, -1334.53, 13.5391, 181.501, 'The State', 2000000, 7, 1, 0, 0, 4, 'Oliver_Mindsen', 'Nini_Tarielashvili', 0, 0, 0, 0, 0, 176900, 1100),
(476, 1081.38, -1696.78, 13.5469, 225.705, 1021.86, 1084.02, 1081.71, -1705.95, 13.5469, 275.472, 'Kavala_Nightrideri', 2000000, 7, 1, 1, 0, 4, 'Nikita_Nakashidze', 'John_Starks', 0, 0, 0, 0, 1, 178900, 1100),
(477, 1333.2, -1308.34, 13.5469, 225.705, 1021.86, 1084.02, 1338.2, -1293.01, 13.4108, 4.26076, 'The State', 2000000, 7, 1, 0, 0, 4, 'Cotne_Wurwumia', 'None', 0, 0, 0, 0, 0, 0, 1100),
(478, 1333.79, -1349.03, 13.5469, 225.705, 1021.86, 1084.02, 836.179, -2057.26, 12.8672, 2.45376, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 1100, 1100),
(479, 3054.32, -378.448, 4.89383, 225.705, 1021.86, 1084.02, 3025.07, -382.122, 3.88154, 1.22589, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 14700, 1100),
(480, 1546.39, -1269.41, 17.4062, 225.705, 1021.86, 1084.02, 1532.1, -1282.85, 15.5247, 171.195, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(481, 2561.51, 1561.99, 10.8203, 225.705, 1021.86, 1084.02, 2562.23, 1575.92, 10.8203, 96.8791, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'Ioane_Bagdavadze', 0, 0, 0, 0, 0, 0, 1100),
(482, -2871.98, 2719.89, 276.198, 225.705, 1021.86, 1084.02, -2842, 2734.9, 239.893, 297.907, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(483, 228.291, -1405.17, 51.6094, 225.705, 1021.86, 1084.02, 1539.03, -1629.65, 13.3828, 156.814, 'The State', 2000000, 7, 1, 0, 0, 4, 'Dark_Ernesto', 'None', 0, 0, 0, 0, 0, 0, 1100),
(484, 1451.32, 2565.43, 10.8265, 225.705, 1021.86, 1084.02, 1453.05, 2579.1, 10.8203, 358.3, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(485, 2423.03, -1761.26, 13.5391, 2270.05, -1210.46, 1047.56, 1677.45, -2324.05, 13.3828, 0.397619, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'Ryuk_Light', 0, 0, 0, 0, 0, 2500, 500),
(486, 1242, -1076.25, 31.5547, 225.705, 1021.86, 1084.02, 1245.92, -1067.93, 29.1736, 267, 'The State', 2000000, 7, 1, 0, 0, 4, 'Nini_Beridze', 'None', 0, 81, 0, 0, 1, 1100, 1100),
(487, -1525.94, 485.404, 7.17969, 83.0589, 1322.55, 1083.87, -1538.48, 486.492, 7.17969, 352.289, 'The State', 900000, 9, 1, 0, 0, 2, 'Skull_Trupper', 'Giorgi_Topuria', 0, 0, 0, 0, 0, 700, 700),
(488, 253.319, -1269.92, 74.4302, 83.0589, 1322.55, 1083.87, 277.764, -1249.04, 77.9156, 304.119, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 1, 87800, 700),
(489, 785.76, -828.618, 70.2896, 234.138, 1063.9, 1084.21, 780.434, -799.024, 65.3042, 277.411, 'The State', 1000000, 6, 1, 0, 0, 3, 'Notorious_Big', 'Tonny_Hernandez', 0, 0, 0, 0, 0, 85500, 900),
(490, 948.423, -915.986, 45.2266, 225.705, 1021.86, 1084.02, 958.965, -953.434, 40.0909, 272.97, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 31100, 1100),
(491, 1720.09, -1741.02, 13.5469, 234.138, 1063.9, 1084.21, 1731.91, -1750.66, 13.5162, 358.575, 'The State', 1000000, 6, 1, 0, 0, 3, 'Erekle_Kavtiash', 'Gio_Gona', 0, 0, 0, 0, 0, 133200, 900),
(492, 219.422, -1249.67, 78.3355, 225.705, 1021.86, 1084.02, 227.629, -1262.01, 67.0028, 155.426, 'The State', 2000000, 7, 1, 0, 0, 4, 'Saba_Marqarashvili', 'None', 0, 0, 0, 0, 0, 119500, 1100),
(493, 1417.92, 2567.48, 10.8203, 225.705, 1021.86, 1084.02, 1414.64, 2589.98, 10.6719, 270.13, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(494, 1441.6, 2567.69, 10.8203, 2270.05, -1210.46, 1047.56, 1440.32, 2581.91, 10.8203, 87.8015, 'The State', 700000, 10, 1, 0, 0, 1, 'None', 'None', 0, 0, 0, 0, 0, 0, 500),
(495, 167.897, -1308.55, 70.3513, 83.0589, 1322.55, 1083.87, 168.916, -1340.08, 69.7607, 173.368, 'Young_Todu', 900000, 9, 1, 1, 0, 2, 'Young_Nigga', 'Young_Nikka', 0, 0, 0, 0, 1, 90400, 700),
(496, 1738.73, 1233.67, 10.8203, 2270.05, -1210.46, 1047.56, 543.791, -2073.87, 9.43527, 299.322, 'The State', 700000, 10, 1, 0, 0, 1, 'Saba_Sautidze', 'Nick_Stiler', 0, 0, 0, 0, 0, 0, 500),
(497, -90.8653, 1229.74, 19.7422, 225.705, 1021.86, 1084.02, -80.5841, 1219.57, 19.7422, 192.16, 'The State', 2000000, 7, 1, 0, 0, 4, 'None', 'None', 0, 0, 0, 0, 0, 0, 1100),
(498, 1732.99, -1582.45, 14.1579, 225.705, 1021.86, 1084.02, 1737.54, -1589.43, 13.5444, 82.394, 'The State', 2000000, 7, 1, 0, 0, 4, 'Toma_Surmava', 'None', 0, 0, 0, 0, 1, 169100, 1100),
(499, -1873.59, 1004.38, 38.0208, 234.138, 1063.9, 1084.21, -1877.89, 1005.71, 38.2559, 20.1908, 'The State', 1000000, 6, 1, 0, 0, 3, 'None', 'None', 0, 0, 0, 0, 0, 900, 900),
(500, -2786.76, 119.919, 10.0625, 83.0589, 1322.55, 1083.87, -2796.87, 123.978, 7.1875, 97.7474, 'The State', 900000, 9, 1, 0, 0, 2, 'None', 'None', 0, 0, 0, 0, 0, 0, 700);

-- --------------------------------------------------------

--
-- Table structure for table `IPAddress`
--

CREATE TABLE `IPAddress` (
  `IPAddress` varchar(127) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `kazino`
--

CREATE TABLE `kazino` (
  `kID` int(11) NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Mafia` int(11) NOT NULL,
  `Manager` varchar(32) NOT NULL,
  `Manager2` varchar(32) NOT NULL,
  `Manager3` varchar(32) NOT NULL,
  `Manager4` varchar(32) NOT NULL,
  `Manager5` varchar(32) NOT NULL,
  `Krupie` varchar(32) NOT NULL,
  `Krupie2` varchar(32) NOT NULL,
  `Krupie3` varchar(32) NOT NULL,
  `Krupie4` varchar(32) NOT NULL,
  `Krupie5` varchar(32) NOT NULL,
  `Krupie6` varchar(32) NOT NULL,
  `Krupie7` varchar(32) NOT NULL,
  `Krupie8` varchar(32) NOT NULL,
  `Krupie9` varchar(32) NOT NULL,
  `Krupie10` varchar(32) NOT NULL,
  `Manager6` int(11) NOT NULL,
  `Manager7` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kazino`
--

INSERT INTO `kazino` (`kID`, `Name`, `Mafia`, `Manager`, `Manager2`, `Manager3`, `Manager4`, `Manager5`, `Krupie`, `Krupie2`, `Krupie3`, `Krupie4`, `Krupie5`, `Krupie6`, `Krupie7`, `Krupie8`, `Krupie9`, `Krupie10`, `Manager6`, `Manager7`) VALUES
(1, 'Casino Adjara', 0, 'Bukhra_Brown', 'Sani_Lotus', 'Bmanuel_Blackwood', 'Ucha_Tamazashvili', 'Saba_Xurcidze', 'Balu_Moralezz', 'Sani_Lotus', 'Luka_Babua', 'Luka_Babua', 'Luka_Babua', 'Giorgi_Iremashvili', 'Giorgi_Iremashvili', 'Giorgi_Iremashvili', 'Giorgi_Iremashvili', 'Giorgi_Iremashvili', 0, 0),
(2, 'Caligula', 0, 'Iliko_Revishvili', 'Iliko_Revishvili', 'Iliko_Revishvili', '', '', 'Logan_Paul', 'Zviadi_Gurgenidze', 'Gogsik_Kingston', 'Gogsik_Kingston', 'Gogsik_Kingston', '', '', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `MoneyLog`
--

CREATE TABLE `MoneyLog` (
  `ID` int(11) NOT NULL,
  `CMD` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Name` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Recipient` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Money` int(11) NOT NULL,
  `Data` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Time` varchar(32) CHARACTER SET cp1251 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Penalty`
--

CREATE TABLE `Penalty` (
  `ID` int(11) NOT NULL,
  `CarPosX` float NOT NULL,
  `CarPosY` float NOT NULL,
  `CarPoZ` float NOT NULL,
  `CarPosC` float NOT NULL,
  `CarOwner` varchar(32) NOT NULL,
  `CarBringer` varchar(32) NOT NULL,
  `CarID` int(11) NOT NULL,
  `CarPenalty` int(11) NOT NULL,
  `CarStatus` int(11) NOT NULL,
  `CarSlot` int(11) NOT NULL,
  `CarTime` int(11) NOT NULL

-- --------------------------------------------------------

) ENGINE=InnoDB DEFAULT CHARSET=utf8;
--
-- Table structure for table `mtavari_adminebi`
--

CREATE TABLE `mtavari_adminebi` (
  `name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `PromoCode`
--

CREATE TABLE `PromoCode` (
  `ID` int(11) NOT NULL,
  `Code` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Money` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  `Used` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `Radars`
--

CREATE TABLE `Radars` (
  `RadarID` int(11) NOT NULL,
  `RadarPosX` float NOT NULL,
  `RadarPosY` float NOT NULL,
  `RadarPosZ` float NOT NULL,
  `RadarPosC` float NOT NULL,
  `RadarDistance` int(11) NOT NULL,
  `RadarCash` int(11) NOT NULL,
  `RadarSpeed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Radars`
--

INSERT INTO `Radars` (`RadarID`, `RadarPosX`, `RadarPosY`, `RadarPosZ`, `RadarPosC`, `RadarDistance`, `RadarCash`, `RadarSpeed`) VALUES
(1, 1619.3, -1726.97, 12.5391, 270.342, 10, 20000, 50),
(2, 1394.6, -1791.84, 12.5469, 90.5103, 10, 20000, 50),
(3, 1317.8, -1751.28, 12.5469, 180.461, 10, 20000, 50),
(4, 1292.02, -1677.66, 12.5469, 0.918984, 10, 20000, 50),
(5, 1350.43, -1163.68, 23.4406, 85.7112, 10, 20000, 60),
(6, 1361.76, -1049.95, 25.7767, 89.7845, 10, 20000, 60),
(7, 1317.97, -1624.9, 12.5469, 4.13503, 10, 20000, 60),
(8, 1363.01, -1421.15, 12.5391, 352.855, 10, 25000, 70),
(9, 1363.08, -1287.79, 12.5469, 359.122, 10, 25000, 80),
(10, 1212.47, -1135.21, 22.9368, 87.7958, 10, 20000, 75),
(11, 1059.14, -1135.16, 22.8281, 89.6758, 10, 20000, 75),
(12, 791.768, -1166.04, 22.1861, 181.17, 10, 20000, 70),
(13, 791.25, -1384.59, 12.6996, 168.637, 10, 20000, 69),
(14, 1040.25, -1411.38, 12.4017, 271.388, 10, 20000, 70),
(15, 1247.98, -1411.51, 12.2283, 269.508, 10, 20000, 70),
(16, 1535.17, -1687.93, 12.5469, 355.988, 10, 20000, 60),
(17, 1447.87, -1586.14, 12.5469, 90.6157, 10, 20000, 60),
(18, 1460.35, -1461.57, 12.5469, 7.26828, 10, 20000, 70),
(19, 1432.14, -1435.21, 12.5547, 84.6858, 10, 25000, 50),
(20, 1536.97, -1309, 14.9673, 265.457, 10, 20000, 60),
(21, 1311.72, -2062.12, 57.1736, 92.2057, 10, 20000, 60),
(22, 1435.42, -1995.86, 49.5242, 220.047, 10, 25000, 50),
(23, 1244.95, -1920.9, 30.3919, 143.69, 10, 25000, 65),
(24, 1409.4, -1922.26, 15.4148, 88.7591, 10, 30000, 65),
(25, 1512.3, -1878.31, 12.5469, 275.797, 5, 25000, 50),
(26, 1575.14, -1807.91, 12.5167, 357.578, 10, 25000, 60),
(27, 1453.84, -1745.1, 12.5469, 1.68272, 10, 25000, 30),
(28, 1505.72, -1745.53, 12.5469, 1.65918, 10, 25000, 40),
(29, 1458.2, -1041.44, 22.8281, 357.156, 10, 25000, 60),
(30, 434.813, -1508.75, 30.0254, 285.841, 10, 20000, 60),
(31, 1024.55, -1156.03, 22.8203, 0.048457, 10, 25000, 80),
(32, 2031.1, 1028.1, 9.82031, 269.744, 10, 25000, 70),
(33, 1813.03, -1681.3, 12.5469, 265.89, 10, 25000, 60),
(34, 2419.03, -1264.07, 23.0695, 358.568, 10, 25000, 60),
(35, 2305.6, -1667.88, 13.59, 358.474, 10, 20000, 60),
(36, 999.986, 1844.67, 9.81251, 268.79, 10, 25000, 75),
(37, 1343.44, -1723.67, 12.5685, 174.382, 10, 25000, 50),
(38, 1812.85, -1843.12, 12.5781, 271.446, 10, 20000, 60),
(39, 1001.26, -977.377, 40.3967, 0.074019, 10, 25000, 60),
(40, 2485.83, -1726.12, 12.5469, 175.785, 10, 25000, 65),
(41, 1930.16, -1744.91, 12.5469, 180.125, 10, 25000, 60),
(42, 2001.29, -1473.37, 12.5576, 356.463, 10, 25000, 60),
(43, 770.815, -1328.38, 12.5469, 0.48899, 10, 25000, 70),
(44, 771.4, -1387.3, 12.6482, 183.768, 10, 25000, 90);

-- --------------------------------------------------------

--
-- Table structure for table `Trunck`
--

CREATE TABLE `Trunck` (
  `ID` int(11) NOT NULL,
  `Name` varchar(128) NOT NULL,
  `TrunckMoneyOne` int(11) NOT NULL,
  `TrunckMoneyTwo` int(11) NOT NULL,
  `TrunckMoneyThree` int(11) NOT NULL,
  `TrunckMoneyFour` int(11) NOT NULL,
  `TrunckMoneyFive` int(11) NOT NULL,
  `TrunckDrugsOne` int(11) NOT NULL,
  `TrunckDrugsTwo` int(11) NOT NULL,
  `TrunckDrugsThree` int(11) NOT NULL,
  `TrunckDrugsFour` int(11) NOT NULL,
  `TrunckDrugsFive` int(11) NOT NULL,
  `TrunckMatsOne` int(11) NOT NULL,
  `TrunckMatsTwo` int(11) NOT NULL,
  `TrunckMatsThree` int(11) NOT NULL,
  `TrunckMatsFour` int(11) NOT NULL,
  `TrunckMatsFive` int(11) NOT NULL,
  `TrunckDeagleOne` int(11) NOT NULL,
  `TrunckDeagleTwo` int(11) NOT NULL,
  `TrunckDeagleThree` int(11) NOT NULL,
  `TrunckDeagleFour` int(11) NOT NULL,
  `TrunckDeagleFive` int(11) NOT NULL,
  `TrunckShotgunOne` int(11) NOT NULL,
  `TrunckShotgunTwo` int(11) NOT NULL,
  `TrunckShotgunThree` int(11) NOT NULL,
  `TrunckShotgunFour` int(11) NOT NULL,
  `TrunckShotgunFive` int(11) NOT NULL,
  `TrunckAK47One` int(11) NOT NULL,
  `TrunckAK47Two` int(11) NOT NULL,
  `TrunckAK47Three` int(11) NOT NULL,
  `TrunckAK47Four` int(11) NOT NULL,
  `TrunckAK47Five` int(11) NOT NULL,
  `TrunckM4One` int(11) NOT NULL,
  `TrunckM4Two` int(11) NOT NULL,
  `TrunckM4Three` int(11) NOT NULL,
  `TrunckM4Four` int(11) NOT NULL,
  `TrunckM4Five` int(11) NOT NULL,
  `TrunckMP5One` int(11) NOT NULL,
  `TrunckMP5Two` int(11) NOT NULL,
  `TrunckMP5Three` int(11) NOT NULL,
  `TrunckMP5Four` int(11) NOT NULL,
  `TrunckMP5Five` int(11) NOT NULL,
  `TrunckBombOne` int(11) NOT NULL,
  `TrunckBombTwo` int(11) NOT NULL,
  `TrunckBombThree` int(11) NOT NULL,
  `TrunckBombFour` int(11) NOT NULL,
  `TrunckBombFive` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ZoneLog`
--

CREATE TABLE `ZoneLog` (
  `ID` int(11) NOT NULL,
  `CMD` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Admin` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Fraction` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Data` varchar(32) CHARACTER SET cp1251 NOT NULL,
  `Time` varchar(32) CHARACTER SET cp1251 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`pID`),
  ADD UNIQUE KEY `pID` (`pID`);

--
-- Indexes for table `anticheat_settings`
--
ALTER TABLE `anticheat_settings`
  ADD UNIQUE KEY `ac_code` (`ac_code`);

--
-- Indexes for table `AutoSalon`
--
ALTER TABLE `AutoSalon`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `banip`
--
ALTER TABLE `banip`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `banlog`
--
ALTER TABLE `banlog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bizz`
--
ALTER TABLE `bizz`
  ADD PRIMARY KEY (`bID`);

--
-- Indexes for table `carkeys`
--
ALTER TABLE `carkeys`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cj_skin`
--
ALTER TABLE `cj_skin`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `CMDLog`
--
ALTER TABLE `CMDLog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Family`
--
ALTER TABLE `Family`
  ADD PRIMARY KEY (`FamilyID`);

--
-- Indexes for table `house`
--
ALTER TABLE `house`
  ADD PRIMARY KEY (`hID`);

--
-- Indexes for table `MoneyLog`
--
ALTER TABLE `MoneyLog`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Penalty`
--
ALTER TABLE `Penalty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `PromoCode`
--
ALTER TABLE `PromoCode`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Radars`
--
ALTER TABLE `Radars`
  ADD PRIMARY KEY (`RadarID`);

--
-- Indexes for table `Trunck`
--
ALTER TABLE `Trunck`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ZoneLog`
--
ALTER TABLE `ZoneLog`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `pID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=141;
--
-- AUTO_INCREMENT for table `AutoSalon`
--
ALTER TABLE `AutoSalon`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `banip`
--
ALTER TABLE `banip`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `banlog`
--
ALTER TABLE `banlog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bizz`
--
ALTER TABLE `bizz`
  MODIFY `bID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `carkeys`
--
ALTER TABLE `carkeys`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `CMDLog`
--
ALTER TABLE `CMDLog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Family`
--
ALTER TABLE `Family`
  MODIFY `FamilyID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `house`
--
ALTER TABLE `house`
  MODIFY `hID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=501;
--
-- AUTO_INCREMENT for table `MoneyLog`
--
ALTER TABLE `MoneyLog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Penalty`
--
ALTER TABLE `Penalty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PromoCode`
--
ALTER TABLE `PromoCode`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Radars`
--
ALTER TABLE `Radars`
  MODIFY `RadarID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `Trunck`
--
ALTER TABLE `Trunck`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ZoneLog`
--
ALTER TABLE `ZoneLog`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
